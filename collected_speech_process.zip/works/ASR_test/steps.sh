#!/bin/bash
echo
echo $0 $@
set -e

bin_dir=$(cd "$(dirname $0)" && pwd)
source $bin_dir/../../bin/build/env.sh

case "$1" in
    record)
        $CSP_PRJ_ROOT/works/ASR_test/record.sh
        ;;
    predict)
        $CSP_PRJ_ROOT/bin/label/predict/lls/recg.sh Fangde_test_batch01
        $CSP_PRJ_ROOT/bin/label/predict/lls/desc.sh
        ;;
    #filter)
    #    $CSP_PRJ_ROOT/works/ASR_test/filter_lls.sh
    amend_upload)
        $CSP_PRJ_ROOT/bin/label/amend/upload_lls.sh
        ;;
    amend_download)
        $CSP_PRJ_ROOT/bin/label/amend/download_lls.sh
        ;;
    archive)
        $CSP_PRJ_ROOT/bin/label/archive/archive_lls.sh
        ;;
    record_to_amend)
        $CSP_PRJ_ROOT/works/ASR_test/record.sh
        $CSP_PRJ_ROOT/bin/label/predict/lls/recg.sh ASR_test_batch02
        $CSP_PRJ_ROOT/bin/label/predict/lls/desc.sh
        $CSP_PRJ_ROOT/bin/label/amend/upload_lls.sh
        ;;
    *)
        echo $"Usage: $0 {reocrd|predict|amend_upload|amend_download|archive|record_to_amend}"
        RETVAL=1
esac
exit $RETVAL
