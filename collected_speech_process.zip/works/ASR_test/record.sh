#!/bin/bash
echo
echo $0 $@
set -e

# init
bin_dir=$(cd "$(dirname $0)" && pwd)
recd_doc="record/doc"
recd_wav="record/wav"
desc_dir="predict/desc"

# check
if [ ! -d "$recd_wav" ]; then echo "$recd_wav isn't exist"; exit; fi
mkdir -p $recd_doc $desc_dir

# wav.lst
find $recd_wav -name "*.wav" | sort > $recd_doc/wav.lst

# wav2spk.lst
cat $recd_doc/wav.lst | sed 's;.wav;;g' | awk -F/ '{print $NF"\t"$NF}' > $recd_doc/wav2spk.lst

# speaker
$CSP_PRJ_ROOT/src/collect/desc/collect_desc_speaker.py $recd_doc/speaker.lst $recd_doc/wav2spk.lst $desc_dir/speaker.json
