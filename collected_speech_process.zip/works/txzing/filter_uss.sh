#!/bin/bash
set -x
set -e

# init 
filter_py="$CSP_PRJ_ROOT/src/label/filter"
exception_lst="record/doc/exception.lst"
predict_json="predict/desc/desc.json"
filter_dir="filter"
filter_json="$filter_dir/desc.json"

# check
if [ ! -f $predict_json ]; then echo "$predict_json isn't exist"; exit; fi

# clear
if [ -d $filter_dir ]; then rm -r $filter_dir; fi
mkdir -p $filter_dir

$filter_py/filter_desc.py $predict_json $filter_json --clipping=800 --text_repeat_max=150 --exception_list=$exception_lst
