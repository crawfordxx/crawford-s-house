#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def _merge_sentence_batch(major_snt_batch, minor_snt_batch) -> bool:
    if not major_snt_batch or not minor_snt_batch:
        logger.error(f"sentence_batch is None")
        return False
    major_snt_dict = major_snt_batch.sentence_dict
    minor_snt_dict = minor_snt_batch.sentence_dict
    if not major_snt_dict or not minor_snt_dict:
        logger.error(f"sentence_dict is empty")
        return False
    for wav_name, sentence_item_list in major_snt_dict.items():
        if len(sentence_item_list) > 1:
            logger.error(f"{wav_name} sentence is more than one")
            return False
        sentence_data = sentence_item_list[0].sentence_data
        if wav_name in minor_snt_dict:
            minor_snt_data = minor_snt_dict[wav_name][0].sentence_data
            sentence_data.text = minor_snt_data.text
            sentence_data.NLU = minor_snt_data.NLU
    return True


def predict_merge_sentence(predict_snt_path, record_snt_path, merge_snt_path):
    predict_snt_batch = read_desc_file(predict_snt_path, "sentence")
    record_snt_batch = read_desc_file(record_snt_path, "sentence")
    if not predict_snt_batch or not record_snt_batch:
        return
    if not _merge_sentence_batch(predict_snt_batch, record_snt_batch):
        return
    write_desc_file(predict_snt_batch, merge_snt_path)


def parse_args():
    parser = argparse.ArgumentParser(
            description="merge record sentence to predict sentence")
    parser.add_argument("predict_snt_path", type=str,
                        help="predict sentence path")
    parser.add_argument("record_snt_path", type=str,
                        help="record sentence path")
    parser.add_argument("merge_snt_path", type=str,
                        help="merge sentence path")
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    predict_merge_sentence(args.predict_snt_path, args.record_snt_path,
                           args.merge_snt_path)
