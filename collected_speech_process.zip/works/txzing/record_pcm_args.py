#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from datetime import datetime
from utils.io.stdio import read_list_file
from utils.io.stdio import write_dict_file
from utils.io.stdio import write_json_file
from utils.comm.log import logger


def _parse_wav2dev(pcm_args):
    wav_name = pcm_args.split('/')[-1][:-4]
    device_id = pcm_args.split('_')[-1].split('.')[0]
    return wav_name, device_id


def _parse_scene(pcm_args):
    wav_name = pcm_args.split('/')[-1][:-4]
    location = pcm_args.split(',')[-1].split('_')[0]
    try:
        date, time = pcm_args.split('_')[-3].split()
        strptime = str(datetime.strptime(f'{date} {time}', '%Y%m%d %H%M%S'))
    except Exception as e:
        logger.error(e)
        return
    scene_json = {
        "basic": {"wav_name": wav_name},
        "scene": {
            "scid": "0",
            "domain": "car",
            "attrs": {
                "location": location,
                "datetime": strptime
            }
        }
    }
    return scene_json


def _parse_sentence(pcm_args):
    wav_name = pcm_args.split('/')[-1][:-4]
    text = pcm_args.split('/')[-3].split('_')[0]
    try:
        domain = pcm_args.split('/')[-4]
    except Exception as e:
        logger.error(e)
        return
    sentence_json = {
        "basic": {"wav_name": wav_name},
        "sentence": [{
            "text": text,
            "NLU": {"domain": domain}
        }]
    }
    return sentence_json


def record_pcm_args(args):
    pcm_args_list = read_list_file(args.pcm_args_lst)
    if not pcm_args_list:
        return

    wav2dev_dict, scene_json_list, sentence_json_list = {}, [], []
    for pcm_args in pcm_args_list:
        wav_name, device_id = _parse_wav2dev(pcm_args)
        wav2dev_dict[wav_name] = device_id
        scene_json = _parse_scene(pcm_args)
        if scene_json:
            scene_json_list.append(scene_json)
        sentence_json = _parse_sentence(pcm_args)
        if not sentence_json:
            continue
        sentence_json_list.append(sentence_json)

    write_dict_file(wav2dev_dict, args.wav2dev_lst)
    write_json_file(scene_json_list, args.scene_json)
    write_json_file(sentence_json_list, args.sentence_json)
    return


def parse_args():
    parser = argparse.ArgumentParser(description="parse pcm args")
    parser.add_argument("pcm_args_lst", help="input pcm_args list", type=str)
    parser.add_argument("wav2dev_lst", help="output wav2dev lst", type=str)
    parser.add_argument("scene_json", help="output scene json", type=str)
    parser.add_argument("sentence_json", help="output sentence json", type=str)
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    record_pcm_args(args)
