#!/bin/bash
echo
echo $0 $@
set -e
set -x

# init 
ark_py="$CSP_PRJ_ROOT/src/label/archive"

amend_dir="amend/download/desc"

ark_dir="archive"
wav_dir="$ark_dir/wav"
desc_dir="$ark_dir/desc"

# check
if [ ! -d $amend_dir ]; then echo "$amend_dir isn't exist"; exit; fi

# clear
if [ -d $ark_dir ]; then rm -r $ark_dir; fi
mkdir -p $wav_dir $desc_dir

# desc
ls $amend_dir | xargs -P30 -i $ark_py/concat_wav_split.py $amend_dir/{} $wav_dir $desc_dir/{} --spread_sec=1
cat $desc_dir/* | sort -u > $ark_dir/desc.json

# stat
$ark_py/archive_desc_stat.py $ark_dir/desc.json $ark_dir/stat.json
