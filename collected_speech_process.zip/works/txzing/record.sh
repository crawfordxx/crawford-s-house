#!/bin/bash
echo
echo $0 $@
set -e
set -x

# init
bin_dir=$(cd "$(dirname $0)" && pwd)
filter_scp="$CSP_PRJ_ROOT/bin/utils/filter_scp.pl"

recd_src="record/source"
recd_doc="record/doc"

hdfs_dir="hdfs://hobot-bigdata/user/jie.wang/project_2019/Txzing"
hdfs_test_dev_lst="${hdfs_dir}/source_data/doc/Txzing_test_speech_batch01_devices.lst"
hdfs_exception_lst="${hdfs_dir}/source_data/doc/chj_cmd.lst"
test_dev_lst=${recd_doc}/Txzing_test_speech_batch01_devices.lst
exception_lst="$recd_doc/exception.lst"

# check
if [ ! -d $recd_src ]; then echo "$recd_src isn't exist"; exit; fi
mkdir -p $recd_doc record/wav 

# pcm list
find $recd_src -name "*.pcm" -size +0c | grep -Ev "/null|/empty" > $recd_doc/pcm.lst

# exclude test
hdfs dfs -get $hdfs_test_dev_lst $test_dev_lst
awk -F'[_.]' '{print $(NF-1)"\t\""$0"\""}' $recd_doc/pcm.lst > $recd_doc/dev2pcm.lst
$filter_scp --exclude $test_dev_lst $recd_doc/dev2pcm.lst | awk -F'\t' 'BEGIN{idx=1}{printf("%s record/wav/%07d.wav\n",$2,idx); idx++}' > $recd_doc/pcm_args.lst

# pcm args
hdfs dfs -get $hdfs_exception_lst $exception_lst
${bin_dir}/record_pcm_args.py $recd_doc/pcm_args.lst $recd_doc/wav2dev.lst $recd_doc/scene.json $recd_doc/sentence.json

# pcm to wav
xargs -a $recd_doc/pcm_args.lst -P30 -n2 sox -V1 -t raw -e signed-integer -r 16k -b 16 -c 1
find record/wav -iname "*.wav" | sort > $recd_doc/wav.lst
