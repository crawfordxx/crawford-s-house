#!/bin/bash
echo
echo $0 $@
set -e

bin_dir=$(cd "$(dirname $0)" && pwd)
source $bin_dir/../../bin/build/env.sh

case "$1" in
    record)
        $CSP_PRJ_ROOT/works/txzing/record.sh
        ;;
    predict_put)
        $CSP_PRJ_ROOT/bin/label/predict/uss/hdfs_put.sh
        $CSP_PRJ_ROOT/bin/label/predict/uss/hadoop_submit.sh
        ;;
    predict_get)
        $CSP_PRJ_ROOT/bin/label/predict/uss/hdfs_get.sh
        $CSP_PRJ_ROOT/works/txzing/predict_uss_desc.sh
        ;;
    filter)
        $CSP_PRJ_ROOT/works/txzing/filter_uss.sh
        ;;
    amend_upload)
        $CSP_PRJ_ROOT/bin/label/amend/upload_uss.sh
        ;;
    amend_download)
        $CSP_PRJ_ROOT/bin/label/amend/download_uss.sh
        ;;
    archive)
        $CSP_PRJ_ROOT/bin/label/archive/archive_uss.sh
        ;;
    record_to_amend)
        $CSP_PRJ_ROOT/works/txzing/record.sh
        $CSP_PRJ_ROOT/bin/label/predict/uss/hdfs_put.sh
        $CSP_PRJ_ROOT/bin/label/predict/uss/hadoop_submit.sh
        $CSP_PRJ_ROOT/bin/label/predict/uss/hdfs_get.sh
        $CSP_PRJ_ROOT/works/txzing/predict_uss_desc.sh
        $CSP_PRJ_ROOT/works/txzing/filter_uss.sh
        $CSP_PRJ_ROOT/bin/label/amend/upload_uss.sh
        ;;
    *)
        echo $"Usage: $0 {record|predict_put|predict_get|filter|amend_upload|amend_download|archive|record_to_amend}"
        RETVAL=1
esac
exit $RETVAL
