#!/bin/bash
echo
echo $0 $@
set -e
set -x

# init
bin_dir=$(cd "$(dirname $0)" && pwd)
desc_py="$CSP_PRJ_ROOT/src/collect/desc"
pred_py="$CSP_PRJ_ROOT/src/label/predict"

record_wav2dev="record/doc/wav2dev.lst"
record_scene="record/doc/scene.json"
record_sentence="record/doc/sentence.json"

hadoop_lst="predict/hdfs_put/hadoop.lst"
wav_lst_dir="predict/hdfs_put/wav_lst"
dec_json_dir="predict/hdfs_get/decode"
dec_snt_dir="predict/hdfs_get/sentence"

desc_dir="predict/desc"
audio_dir="$desc_dir/audio"
speaker_dir="$desc_dir/speaker"
sentence_dir="$desc_dir/sentence"
batch_dir="$desc_dir/batch"

# clear
if [ -d $desc_dir ]; then rm -r $desc_dir; fi
mkdir -p $audio_dir $speaker_dir $dec_snt_dir $sentence_dir $batch_dir

# desc
xargs -a $hadoop_lst -P20 -i $desc_py/collect_desc_audio.py $CSP_BATCH_NAME $wav_lst_dir/{} $audio_dir/{}.json --wav2dev=$record_wav2dev --detect_signal
xargs -a $hadoop_lst -P20 -i $pred_py/predict_uss_spk_snt.py $dec_json_dir/{}.json $speaker_dir/{}.json $dec_snt_dir/{}.json
xargs -a $hadoop_lst -P20 -i $bin_dir/predict_merge_sentence.py $dec_snt_dir/{}.json $record_sentence $sentence_dir/{}.json
xargs -a $hadoop_lst -P20 -i $desc_py/collect_desc_batch.py $audio_dir/{}.json $batch_dir/{}.json --scene_json=$record_scene --speaker_json=$speaker_dir/{}.json --sentence_json=$sentence_dir/{}.json
cat $batch_dir/*.json > $desc_dir/desc.json
