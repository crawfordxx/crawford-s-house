## Dependency

### System




### Software
	ffmpeg
	sox
	adb
	python3.6

### Python
	numpy
	scipy
	logzero
	pydantic
	pandas
	pydub
	cv2
	playsound
	sounddevice
	IPy