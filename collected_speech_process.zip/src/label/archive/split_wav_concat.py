#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.wav.concat import concat_wav_with_desc


def parse_args():
    parser = argparse.ArgumentParser(description="concat wav with desc")
    parser.add_argument("--tip_desc_path", type=str, help="tip desc path")
    parser.add_argument("--tip_interval", type=float, default=1,
                        help="interval between tip and ends")
    parser.add_argument("--wkp_desc_path", type=str, help="wkp desc path")
    parser.add_argument("--wkp_interval", type=float, default=1,
                        help="interval between wakeup and split")
    parser.add_argument("split_desc_path", type=str, help="split desc path")
    parser.add_argument("--split_interval", type=float, default=1,
                        help="interval between splits")
    parser.add_argument("--max_duration", type=float, default=10800,
                        help="max duration for concat wav")
    parser.add_argument("concat_batch", type=str, help="concat batch")
    parser.add_argument("concat_wav_dir", type=str, help="concat wav dir")
    parser.add_argument("concat_desc_path", type=str, help="concat desc path")
    args = parser.parse_args()
    return args


def split_wav_concat(args):
    tip_desc_batch = None
    if args.tip_desc_path:
        tip_desc_batch = read_desc_file(args.tip_desc_path)
    tip_interval = args.tip_interval

    wkp_desc_batch = None
    if args.wkp_desc_path:
        wkp_desc_batch = read_desc_file(args.wkp_desc_path)
    wkp_interval = args.wkp_interval

    query_desc_batch = read_desc_file(args.split_desc_path)
    query_interval = args.split_interval
    max_duration = args.max_duration

    concat_batch = args.concat_batch
    concat_wav_dir = args.concat_wav_dir.rstrip('/')
    concat_desc_path = args.concat_desc_path

    concat_desc_batch = concat_wav_with_desc(query_desc_batch,
                                             concat_batch, concat_wav_dir,
                                             query_interval, max_duration,
                                             tip_desc_batch, tip_interval,
                                             wkp_desc_batch, wkp_interval)
    write_desc_file(concat_desc_batch, concat_desc_path)


if __name__ == '__main__':
    args = parse_args()
    split_wav_concat(args)
