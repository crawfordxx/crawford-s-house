#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.stat.stat_batch import StatBatch
from utils.io.stdio import read_json_file
from utils.io.stdio import write_json_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="dest batch stat")
    parser.add_argument("desc_json", help="input desc json", type=str)
    parser.add_argument("stat_json", help="output stat json", type=str)
    args = parser.parse_args()
    return args


def desc_to_stat(input_desc_json, output_stat_json):
    desc_json_list = read_json_file(input_desc_json)
    if not desc_json_list:
        logger.error(f"read desc json file failed")
        return
    stat_batch = StatBatch()
    if not stat_batch.set_stat_data(desc_json_list):
        logger.error(f"set stat data failed")
        return
    stat_json = stat_batch.get_stat_json()
    if not stat_json:
        logger.error(f"get stat json failed")
        return
    write_json_file([stat_json], output_stat_json)


if __name__ == '__main__':
    args = parse_args()
    desc_to_stat(args.desc_json, args.stat_json)
