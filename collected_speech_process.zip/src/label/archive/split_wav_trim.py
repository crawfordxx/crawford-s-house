#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.wav.trim import trim_wav_with_desc


def parse_arg():
    parser = argparse.ArgumentParser(description="trim wav with desc")
    parser.add_argument("split_desc_path", help='split desc path', type=str)
    parser.add_argument("trim_wav_dir", help='trim wav dir', type=str)
    parser.add_argument("trim_desc_path", help='trim desc path', type=str)
    return parser.parse_args()


def split_wav_trim(split_desc_path, trim_wav_dir, trim_desc_path):
    split_desc_batch = read_desc_file(split_desc_path)
    if not split_desc_batch:
        return
    trim_desc_batch = trim_wav_with_desc(split_desc_batch, trim_wav_dir)
    write_desc_file(trim_desc_batch, trim_desc_path)


if __name__ == "__main__":
    args = parse_arg()
    split_wav_trim(args.split_desc_path, args.trim_wav_dir.rstrip('/'),
                   args.trim_desc_path)
