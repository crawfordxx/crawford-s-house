#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.io.stdio import write_list_file
from utils.wav.split import split_wav_with_desc


def parse_arg():
    parser = argparse.ArgumentParser(description="split wav with desc")
    parser.add_argument("concat_desc_path", help='concat desc path', type=str)
    parser.add_argument("split_wav_dir", help='split wav dir', type=str)
    parser.add_argument("split_desc_path", help='split desc path', type=str)
    parser.add_argument("--spread_sec", help='spread vad duraiton', type=int)
    parser.add_argument("--split_args_path", help='split args path', type=str)
    return parser.parse_args()


def concat_wav_split(concat_desc_path, split_wav_dir,
                     split_desc_path, split_args_path,
                     spread_sec):
    concat_desc_batch = read_desc_file(concat_desc_path)
    if not concat_desc_batch:
        return
    split_desc_batch, split_args_lines \
        = split_wav_with_desc(concat_desc_batch, split_wav_dir, spread_sec)
    write_desc_file(split_desc_batch, split_desc_path)
    if split_args_path:
        write_list_file(split_args_lines, split_args_path)


if __name__ == "__main__":
    args = parse_arg()
    concat_wav_split(args.concat_desc_path, args.split_wav_dir.rstrip('/'),
                     args.split_desc_path, args.split_args_path,
                     args.spread_sec)
