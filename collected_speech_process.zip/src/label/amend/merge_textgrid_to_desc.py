#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.textgrid import read_textgrid_files
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="merge textgrid to desc")
    parser.add_argument("input_desc_json", type=str,
                        help="input desc json file")
    parser.add_argument("input_textgrid_lst", type=str,
                        help="input textgrid path list")
    parser.add_argument("output_desc_json", type=str,
                        help="output desc json file")
    args = parser.parse_args()
    return args


def merge_textgrid_to_desc(input_desc_json, input_textgrid_lst,
                           output_desc_json):
    desc_batch = read_desc_file(input_desc_json)
    if not desc_batch:
        return
    sentence_batch = read_textgrid_files(input_textgrid_lst)
    if not sentence_batch:
        return
    if not desc_batch.update_sentence(sentence_batch):
        return
    write_desc_file(desc_batch, output_desc_json)


if __name__ == '__main__':
    args = parse_args()
    merge_textgrid_to_desc(args.input_desc_json, args.input_textgrid_lst,
                           args.output_desc_json)
