#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import argparse
from utils.io.stdio import read_desc_file
from utils.io.textgrid import write_textgrid_files
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(
            description="extract desc file to TextGrid")
    parser.add_argument("desc_path", type=str, help="input desc file path")
    parser.add_argument("textgrid_dir", type=str, help="output TextGrid dir")
    args = parser.parse_args()
    return args


def extract_desc_to_textgrid(desc_path, textgrid_dir):
    desc_batch = read_desc_file(desc_path)
    if not desc_batch:
        return
    if not os.path.isdir(textgrid_dir):
        os.makedirs(textgrid_dir)
    write_textgrid_files(desc_batch, textgrid_dir)


if __name__ == "__main__":
    args = parse_args()
    extract_desc_to_textgrid(args.desc_path, args.textgrid_dir)
