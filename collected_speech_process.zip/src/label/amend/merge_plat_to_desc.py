#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.plat import read_plat_file
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="merge plat to desc")
    parser.add_argument("input_desc_json", type=str,
                        help="input desc json file")
    parser.add_argument("input_plat_json", type=str,
                        help="input plat json file")
    parser.add_argument("output_desc_json", type=str,
                        help="output desc json file")
    args = parser.parse_args()
    return args


def merge_plat_to_desc(input_desc_json, input_plat_json, output_desc_json):
    desc_batch = read_desc_file(input_desc_json)
    if not desc_batch:
        return
    speaker_batch, sentence_batch = read_plat_file(input_plat_json)
    if speaker_batch and not desc_batch.update_speaker(speaker_batch):
        return
    if sentence_batch and not desc_batch.update_sentence(sentence_batch):
        return
    write_desc_file(desc_batch, output_desc_json)


if __name__ == '__main__':
    args = parse_args()
    merge_plat_to_desc(args.input_desc_json, args.input_plat_json,
                       args.output_desc_json)
