#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.io.plat import write_plat_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(
            description="extract desc file to plat file")
    parser.add_argument("desc_path", type=str, help="input desc file path")
    parser.add_argument("plat_path", type=str, help="output plat file path")
    args = parser.parse_args()
    return args


def extract_desc_to_plat(desc_path, plat_path):
    desc_batch = read_desc_file(desc_path)
    if not desc_batch:
        return
    write_plat_file(desc_batch, plat_path)


if __name__ == '__main__':
    args = parse_args()
    extract_desc_to_plat(args.desc_path, args.plat_path)
