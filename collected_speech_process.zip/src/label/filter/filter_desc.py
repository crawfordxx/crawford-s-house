#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import random
import argparse
from utils.io.stdio import read_list_file
from utils.io.stdio import read_json_file
from utils.io.stdio import write_json_file
from utils.comm.log import logger


def parse_args():
    argparser = argparse.ArgumentParser(
        usage="%(prog)s --spread_vad=0.2 --duration_min=0.4 "
              "--duration_max=50 --text_len_min=3 "
              "--text_len_max=50  input_desc.json output_desc.json")
    argparser.add_argument("input_desc_json", help="input desc json")
    argparser.add_argument("output_desc_json", help="output desc json")
    argparser.add_argument("--clipping", help="signal clipping number",
                           type=int)
    argparser.add_argument("--spread_vad", help="spread vad",
                           type=float, default=0.2)
    argparser.add_argument("--duration_min", help="duration min second",
                           type=float, default=0.4)
    argparser.add_argument("--duration_max", help="duration max second",
                           type=float, default=50)
    argparser.add_argument("--text_len_min",
                           help="min count of text char, including english",
                           type=int, default=3)
    argparser.add_argument("--text_len_max",
                           help="max count of text char, including english",
                           type=int, default=50)
    argparser.add_argument("--text_repeat_max",
                           help="max count of repeat text",
                           type=int)
    argparser.add_argument("--exception_list",
                           help="the wav list don't need to filter",
                           type=str)
    return argparser.parse_args()


def _vad_filter(sentence_json, duration, args):
    spread_second = args.spread_vad
    vad_beg = sentence_json.get("vad_beg")
    vad_end = sentence_json.get("vad_end")
    if spread_second >= 0:
        if vad_beg - spread_second > 0:
            sentence_json['vad_beg'] = "%.3f" % (vad_beg - spread_second)
        else:
            sentence_json['vad_beg'] = 0.05
        if vad_end + spread_second < duration:
            sentence_json['vad_end'] = "%.3f" % (vad_end + spread_second)
        else:
            sentence_json['vad_end'] = "%.3f" % (duration - 0.05)
        return True


def _text_len_filter(text, args):
    text_len = len(text)
    text_len_min = args.text_len_min
    text_len_max = args.text_len_max
    if text_len_min <= text_len <= text_len_max:
        return True


def _text_repeat_filter(text, exception_list, text_num_dict, args):
    if not args.text_repeat_max:
        return True
    if text in exception_list:
        return True
    number = text_num_dict.get(text)
    if not number:
        text_num_dict[text] = 1
    elif number >= args.text_repeat_max:
        return
    else:
        text_num_dict[text] = number + 1
    return True


def _signal_filter(signal_json, args):
    if not signal_json:
        return True
    if not args.clipping:
        return True
    if int(signal_json["clipping"]) < args.clipping:
        return True


def _duration_filter(duration, args):
    duration_min = args.duration_min
    duration_max = args.duration_max
    if duration_min < duration < duration_max:
        return True


def _audio_filter(audio_json, args):
    signal_json = audio_json.pop("signal_")
    duration = audio_json.get("duration")
    signal_result = _signal_filter(signal_json, args)
    duration_result = _duration_filter(duration, args)
    if signal_result and duration_result:
        return True


def _sentence_filter(sentence_list, text_num_dict,
                     exception_list, duration, args):
    for index, sentence_json in enumerate(sentence_list, start=1):
        sentence_json.pop("phones")
        text = sentence_json.get("text")
        text_len_result = _text_len_filter(text, args)
        text_repeat_result = _text_repeat_filter(text, exception_list,
                                                 text_num_dict, args)
        vad_result = _vad_filter(sentence_json, duration, args)
        if not (text_len_result and text_repeat_result and vad_result):
            return
    return sentence_list


def desc_filter(args):
    desc_json_list = read_json_file(args.input_desc_json)
    random.shuffle(desc_json_list)
    if args.exception_list:
        exception_list = read_list_file(args.exception_list)
    else:
        exception_list = None

    # filter
    text_num_dict = {}
    out_desc_json_list = []
    for desc_json in desc_json_list:
        audio_json = desc_json.get("audio")
        wav_name = desc_json["basic"].get("wav_name")
        sentence_list = desc_json.get("sentence")
        duration = desc_json["audio"].get("duration")

        audio_filter_result = _audio_filter(audio_json, args)
        sentence_filter_list = _sentence_filter(sentence_list, text_num_dict,
                                                exception_list, duration, args)
        if audio_filter_result and sentence_filter_list:
            desc_json["sentence"] = sentence_filter_list
            out_desc_json_list.append(desc_json)

    write_json_file(out_desc_json_list, args.output_desc_json)


if __name__ == '__main__':
    args = parse_args()
    desc_filter(args)
