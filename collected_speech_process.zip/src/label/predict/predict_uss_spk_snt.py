#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.predict import read_uss_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make predict desc json")
    parser.add_argument("uss_json_path", type=str, help="input uss json path")
    parser.add_argument("speaker_path", type=str, help="output speaker path")
    parser.add_argument("sentence_path", type=str, help="output sentence path")
    args = parser.parse_args()
    return args


def predict_uss_spk_snt(uss_json_path, speaker_path, sentence_path):
    speaker_batch, sentence_batch = read_uss_file(uss_json_path)
    if not speaker_batch or not sentence_batch:
        return
    write_desc_file(speaker_batch, speaker_path)
    write_desc_file(sentence_batch, sentence_path)


if __name__ == '__main__':
    args = parse_args()
    predict_uss_spk_snt(args.uss_json_path,
                        args.speaker_path, args.sentence_path)
