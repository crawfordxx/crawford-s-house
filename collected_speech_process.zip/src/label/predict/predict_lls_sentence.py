#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.predict import read_lls_files
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="lls list to desc json")
    parser.add_argument("lls_lst_path", type=str,
                        help="input lls list path")
    parser.add_argument("sentence_path", type=str,
                        help="output sentence path")
    args = parser.parse_args()
    return args


def predict_lls_sentence(lls_lst_path, sentence_path):
    sentence_batch = read_lls_files(lls_lst_path)
    if not sentence_batch:
        return
    write_desc_file(sentence_batch, sentence_path)


if __name__ == '__main__':
    args = parse_args()
    predict_lls_sentence(args.lls_lst_path, args.sentence_path)
