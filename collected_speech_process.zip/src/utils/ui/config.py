#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import filedialog


class UIConfig:

    def __init__(self, root):
        self.label = None
        self.entry = None
        self.button = None
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root, pady=10)
        self.label = tk.Label(frame, text="配置文件路径： ")
        self.entry = tk.Entry(frame)
        self.button = tk.Button(frame, text="...", command=self.select_path)
        frame.pack()

    def layout(self):
        self.label.grid(row=0, column=0)
        self.entry.grid(row=0, column=1)
        self.button.grid(row=0, column=2)

    def select_path(self):
        filename = filedialog.askopenfilename()
        self.entry.delete(0, "end")
        self.entry.insert(0, filename)

    def check_data(self):
        config_path = self.entry.get()
        if not config_path:
            return False
        return True

    def get_data(self):
        config_path = self.entry.get()
        return config_path

    def disable(self):
        self.entry.config(state=tk.DISABLED)
        self.button.config(state=tk.DISABLED)

    def enable(self):
        self.entry.config(state='normal')
        self.button.config(state=tk.ACTIVE)
