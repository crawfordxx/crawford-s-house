#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showerror

age_list = [i for i in range(1, 100)]
region_list = ['北京', '上海', '重庆', '广东', '天津', '广西', '江苏',
               '浙江', '四川', '江西', '福建', '青海', '吉林', '贵州',
               '陕西', '山西', '河北', '湖北', '辽宁', '湖南', '山东',
               '云南', '河南', '安徽', '甘肃', '海南', '黑龙江', '内蒙古',
               '新疆', '宁夏', '西藏', '香港', '澳门', '台湾']
accent_list = ['普通话', '口音', '方言']


class UISpeaker:

    def __init__(self, root):
        # label
        self.spkid_label = None
        self.name_label = None
        self.gender_label = None
        self.age_label = None
        self.region_label = None
        self.accent_label = None
        # entry
        self.spkid_entry = None
        self.name_entry = None
        self.gender = None
        self.male_radiobutton = None
        self.female_radiobutton = None
        self.age_combobox = None
        self.region_combobox = None
        self.accent_combobox = None
        # init
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root, pady=10)
        self.label_pack(frame)
        self.entry_pack(frame)
        frame.pack()

    def label_pack(self, frame):
        self.spkid_label = tk.Label(frame, text="说话人编号： ")
        self.name_label = tk.Label(frame, text="说话人姓名： ")
        self.gender_label = tk.Label(frame, text="说话人性别： ")
        self.age_label = tk.Label(frame, text="说话人年龄： ")
        self.region_label = tk.Label(frame, text="说话人籍贯： ")
        self.accent_label = tk.Label(frame, text="说话人口音： ")

    def entry_pack(self, frame):
        self.spkid_entry = tk.Entry(frame)
        self.name_entry = tk.Entry(frame)
        self.gender = tk.StringVar()
        self.male_radiobutton = tk.Radiobutton(frame, text="男", value="男",
                                               variable=self.gender)
        self.female_radiobutton = tk.Radiobutton(frame, text="女", value="女",
                                                 variable=self.gender)
        self.male_radiobutton.select()
        self.age_combobox = ttk.Combobox(frame, state='readonly')
        self.age_combobox['value'] = age_list
        self.age_combobox.current(19)
        self.region_combobox = ttk.Combobox(frame, state='readonly')
        self.region_combobox['value'] = region_list
        self.region_combobox.current(0)
        self.accent_combobox = ttk.Combobox(frame, state='readonly')
        self.accent_combobox['value'] = accent_list
        self.accent_combobox.current(0)

    def layout(self):
        self.label_layout()
        self.entry_layout()

    def label_layout(self):
        self.spkid_label.grid(row=0, column=0, sticky="E")
        self.name_label.grid(row=1, column=0, sticky="E")
        self.gender_label.grid(row=2, column=0, sticky="E")
        self.age_label.grid(row=3, column=0, sticky="E")
        self.region_label.grid(row=4, column=0, sticky="E")
        self.accent_label.grid(row=5, column=0, sticky="E")

    def entry_layout(self):
        self.spkid_entry.grid(row=0, column=1, columnspan=3)
        self.name_entry.grid(row=1, column=1, columnspan=3)
        self.male_radiobutton.grid(row=2, column=2)
        self.female_radiobutton.grid(row=2, column=3)
        self.age_combobox.grid(row=3, column=2)
        self.region_combobox.grid(row=4, column=2)
        self.accent_combobox.grid(row=5, column=2)

    def check_data(self, basic_info):
        spkid_len = basic_info.get("spkid_len")
        spkid_min = basic_info.get("spkid_min")
        spkid_max = basic_info.get("spkid_max")
        spkid = self.spkid_entry.get().strip()
        if len(spkid) != spkid_len:
            showerror("错误", f"说话人编号必须是{spkid_len}位")
            return False
        if spkid.find(" ") >= 0:
            showerror("错误", "说话人编号存在空格")
            return False
        if int(spkid) < int(spkid_min) or int(spkid) > int(spkid_max):
            showerror("错误", f"说话人编号必须在{spkid_min}和{spkid_max}之间")
            return False
        name = self.name_entry.get().strip()
        if not name:
            showerror("错误", "说话人名字不能为空")
            return False
        if name.find(" ") >= 0:
            showerror("错误", "说话人名字存在空格")
            return False
        return True

    def get_data(self):
        speaker_json = {"spkid": self.spkid_entry.get().strip(),
                        "name": self.name_entry.get().strip(),
                        "gender": self.gender.get(),
                        "age": self.age_combobox.get(),
                        "region": self.region_combobox.get(),
                        "accent": self.accent_combobox.get()}
        return speaker_json

    def disable(self):
        self.spkid_entry.config(state=tk.DISABLED)
        self.name_entry.config(state=tk.DISABLED)
        self.male_radiobutton.config(state=tk.DISABLED)
        self.female_radiobutton.config(state=tk.DISABLED)
        self.age_combobox.config(state=tk.DISABLED)
        self.accent_combobox.config(state=tk.DISABLED)
        self.region_combobox.config(state=tk.DISABLED)

    def enable(self):
        self.spkid_entry.config(state='normal')
        self.name_entry.config(state='normal')
        self.male_radiobutton.config(state='normal')
        self.female_radiobutton.config(state='normal')
        self.age_combobox.config(state='readonly')
        self.accent_combobox.config(state='readonly')
        self.region_combobox.config(state='readonly')
