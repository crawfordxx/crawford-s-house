#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pyaudio
import numpy as np
import tkinter as tk
from tkinter import ttk


class UIDevItem:

    def __init__(self, root, dev_info):
        self.dev_info = dev_info
        self.mic_combobox = None
        self.dev_idx_entry = None
        self.dev_name_entry = None
        self.dev_volume_bar = None
        self.stream = None
        self.update_ms = 20
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root)
        self.mic_combobox = ttk.Combobox(frame, width=10)
        self.dev_idx_entry = tk.Entry(frame, width=10)
        self.dev_idx_entry.insert(0, self.dev_info.get("index"))
        self.dev_idx_entry.config(state=tk.DISABLED)
        self.dev_name_entry = tk.Entry(frame, width=35)
        self.dev_name_entry.insert(0, self.dev_info.get("name"))
        self.dev_name_entry.config(state=tk.DISABLED)
        self.dev_volume_bar = ttk.Progressbar(frame, orient="horizontal",
                                              length=200, mode="determinate")
        self.dev_volume_bar["maximum"] = np.iinfo(np.int16).max
        self.dev_volume_bar['value'] = 0
        frame.pack()

    def layout(self):
        self.mic_combobox.grid(row=0, column=0)
        self.dev_idx_entry.grid(row=0, column=1)
        self.dev_name_entry.grid(row=0, column=2)
        self.dev_volume_bar.grid(row=0, column=3)

    def set_mic_list(self, mic_list):
        self.mic_combobox.config(value=mic_list)

    def set_mic_idx(self, mic_list_idx):
        self.mic_combobox.current(mic_list_idx)

    def get_mic_idx(self):
        return self.mic_combobox.get()

    def open_stream(self):
        pa = pyaudio.PyAudio()
        rate = int(self.dev_info.get("defaultSampleRate"))
        chls = self.dev_info.get("maxInputChannels")
        bits = pyaudio.paInt16
        frames = self.update_ms * rate // 1000
        self.stream = pa.open(rate=rate, channels=chls,
                              format=bits, input=True,
                              input_device_index=self.dev_info.get("index"),
                              frames_per_buffer=frames, start=False,
                              stream_callback=self.stream_callback)
        self.stream.start_stream()
        return

    def stream_callback(self, in_data, frame_count, time_info, status):
        wav_chls = self.dev_info.get("maxInputChannels")
        wav_np = np.fromstring(in_data, dtype=np.int16)
        wav_data = np.reshape(wav_np, [frame_count, wav_chls])
        wav_mean = np.max(np.abs(wav_data[:, 0]))
        if wav_mean:
            self.dev_volume_bar.after(self.update_ms, self.progress(wav_mean))
            self.dev_volume_bar.update()
        else:
            self.dev_volume_bar['value'] = 0
            self.stream.stop_stream()
        return None, pyaudio.paContinue

    def progress(self, current_value):
        self.dev_volume_bar['value'] = current_value
