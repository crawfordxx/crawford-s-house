#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showerror
from tkinter import filedialog
from utils.io.stdio import read_list_file


class UISentence:

    def __init__(self, root):
        self.text_dict = {}
        self.text_label = None
        self.text_entry = None
        self.text_button = None
        self.index_label = None
        self.index_combobox = None
        self.content_label = None
        self.content_entry = None
        self.sntid = None
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root, pady=10)
        self.text_label = tk.Label(frame, text="句子文本： ")
        self.text_entry = tk.Entry(frame)
        self.text_button = tk.Button(frame, text='...',
                                     command=self.select_text)
        self.index_label = tk.Label(frame, text="句子编号： ")
        self.index_combobox = ttk.Combobox(frame)
        self.index_combobox.bind("<<ComboboxSelected>>", self.select_content)
        self.content_label = tk.Label(frame, text="句子内容： ")
        self.content_entry = tk.Entry(frame)
        frame.pack()

    def layout(self):
        self.text_label.grid(row=0, column=0)
        self.text_entry.grid(row=0, column=1, columnspan=3)
        self.text_button.grid(row=0, column=4)
        self.index_label.grid(row=1, column=0)
        self.index_combobox.grid(row=1, column=1, columnspan=2)
        self.content_label.grid(row=2, column=0)
        self.content_entry.grid(row=2, column=1, columnspan=3)

    def select_text(self):
        text_dict = {}
        file_path = filedialog.askopenfilename()
        self.text_entry.delete(0, "end")
        self.text_entry.insert(0, file_path)
        text_list = read_list_file(file_path)
        for index in range(1, len(text_list)+1):
            text_dict[str(index)] = text_list[index-1]
        self.index_combobox.config(value=list(text_dict.keys()))
        self.text_dict = text_dict

    def select_content(self, event):
        index = self.index_combobox.get()
        self.content_entry.delete(0, "end")
        self.content_entry.insert(0, self.text_dict[index])

    def check_data(self, basic_info):
        sntid_len = basic_info.get("sntid_len")
        text_num_len = len(str(len(self.text_dict)))
        index = self.index_combobox.get()
        if text_num_len > sntid_len:
            showerror("错误", f"句子编号配置长度不够")
            return False
        self.sntid = index.rjust(sntid_len, '0')
        return True

    def get_data(self):
        sentence_json = {"sntid": self.sntid,
                         "text": self.content_entry.get()}
        return sentence_json

    def disable(self):
        self.text_entry.config(state=tk.DISABLED)
        self.text_button.config(state=tk.DISABLED)
        self.index_combobox.config(state=tk.DISABLED)
        self.content_entry.config(state=tk.DISABLED)

    def enable(self):
        self.text_entry.config(state='normal')
        self.text_button.config(state=tk.ACTIVE)
        self.index_combobox.config(state='normal')
        self.content_entry.config(state='normal')
