#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from utils.ui.dev_item import UIDevItem
from utils.device.usb import get_wasapi_input_devs


class UIDevList:

    def __init__(self, root):
        self.dev_list = []
        self.pack_label(root)
        self.pack_dev_list(root)

    @staticmethod
    def pack_label(root):
        frame = tk.Frame(root)
        mic_idx_label = tk.Label(frame, text="麦克风编号", width=10)
        dev_idx_label = tk.Label(frame, text="设备编号", width=10)
        dev_name_label = tk.Label(frame, text="设备名称", width=35)
        dev_vol_label = tk.Label(frame, text="设备音量", width=30)
        mic_idx_label.grid(row=0, column=0)
        dev_idx_label.grid(row=0, column=1)
        dev_name_label.grid(row=0, column=2)
        dev_vol_label.grid(row=0, column=3)
        frame.pack()

    def pack_dev_list(self, root):
        dev_dict = get_wasapi_input_devs()
        for dev_info in dev_dict.values():
            dev_item = UIDevItem(root, dev_info)
            dev_item.open_stream()
            self.dev_list.append(dev_item)

    def set_idx_dict(self, dev_mic_dict):
        mic_list = list(dev_mic_dict.values())
        for dev_item in self.dev_list:
            dev_item.set_mic_list(mic_list)
            dev_idx = dev_item.dev_info.get("index")
            if dev_idx not in dev_mic_dict:
                continue
            mic_idx = dev_mic_dict[dev_idx]
            mic_list_idx = mic_list.index(mic_idx)
            dev_item.set_mic_idx(mic_list_idx)

    def get_idx_dict(self):
        mic_dev_dict = {}
        for dev_item in self.dev_list:
            mic_idx = dev_item.get_mic_idx()
            if not mic_idx:
                continue
            if mic_idx in mic_dev_dict:
                return
            dev_idx = dev_item.dev_info.get("index")
            mic_dev_dict[mic_idx] = dev_idx
        return mic_dev_dict
