#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk


class UILine:

    def __init__(self, root, width=350, height=5):
        self.canvas = tk.Canvas(root, width=width, height=height)
        self.canvas.create_line(0, 3, width, 3, fill='DarkGray')
        self.canvas.pack()
