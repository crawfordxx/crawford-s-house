#!/usr/bin/env python3
# -*- coding: UTF-8 -*-


from operator import attrgetter
from utils.comm.log import ts_logger
from utils.ts.mic import TsMic
from utils.ts.cam import TsCam


class TsSync():

    @staticmethod
    # delete media with async beginning ts
    # return: file_list input list with async objs deleted
    def _del_async_beg(file_list, sync_thres):
        file_list.sort(key=attrgetter('ts_beg'))
        while file_list:
            beg_max = file_list[-1].ts_beg
            beg_min = file_list[0].ts_beg
            if beg_max - beg_min > sync_thres:
                beg_med = file_list[len(file_list)//2].ts_beg
                if (beg_max - beg_med) > (beg_med - beg_min):
                    del file_list[-1]
                else:
                    del file_list[0]
            else:
                break
        return file_list

    @staticmethod
    # delete media with async ending ts
    # return: file_list input list with async objs deleted
    def _del_async_end(file_list, sync_thres):
        file_list.sort(key=attrgetter('ts_end'))
        while file_list:
            end_max = file_list[-1].ts_end
            end_min = file_list[0].ts_end
            if end_max - end_min > sync_thres:
                end_med = file_list[len(file_list)//2].ts_end
                if (end_max - end_med) > (end_med - end_min):
                    del file_list[-1]
                else:
                    del file_list[0]
            else:
                break
        return file_list

    @staticmethod
    # synchronize starting and ending timestamps of input obj list
    # return sync_list: list of objs that have been synchronized
    def get_sync_ts(file_list):
        ts_logger.info("\n======================")
        beg_dict = {}
        end_dict = {}
        for item in file_list:
            if isinstance(item, TsCam):
                beg_dict[item.cam_name] = item.ts_beg
                end_dict[item.cam_name] = item.ts_end
            else:
                beg_dict[item.mic_name] = item.ts_beg
                end_dict[item.mic_name] = item.ts_end
        ts_logger.info("")
        ts_logger.info(f"ts_beg: {beg_dict}")
        ts_logger.info(f"ts_end: {end_dict}")

        sync_thres = 10000

        sync_list = TsSync._del_async_beg(file_list, sync_thres)
        sync_list = TsSync._del_async_end(sync_list, sync_thres)

        if sync_list:
            ts_beg = max(sync_list, key=attrgetter('ts_beg')).ts_beg
            ts_end = min(sync_list, key=attrgetter('ts_end')).ts_end

            for media in sync_list:
                media.sync_beg = ts_beg
                media.sync_end = ts_end
            return sync_list
        else:
            return []
