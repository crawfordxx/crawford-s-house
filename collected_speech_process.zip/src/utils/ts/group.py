#!/usr/bin/env python3
# -*- coding: UTF-8 -*-


from itertools import product
from utils.ts.cam import TsCam
from utils.ts.mic import TsMic
from utils.ts.sync import TsSync
from utils.comm.os import OSFile
from utils.comm.os import OSCmd
from utils.comm.log import ts_logger


class TsGroup():

    def __init__(self, pack_list, wav_list, flipped_cams, out_dir):
        # list of .pack files
        self.pack_list = pack_list
        # list of .wav files
        self.wav_list = wav_list
        self.flipped_cams = flipped_cams
        self.cam_img_dir = OSFile.join_path(out_dir, "cam_img")
        self.cam_mp4_dir = OSFile.join_path(out_dir, "cam_mp4")
        self.cam_tar_dir = OSFile.join_path(out_dir, "cam_tar")
        self.mic_wav_dir = OSFile.join_path(out_dir, "mic_wav")
        self.mix_mp4_dir = OSFile.join_path(out_dir, "mix_mp4")
        self.mic_list = []
        self.cam_list = []
        self.img_cams = []
        self.inter_cams = []

    # prepare camera data
    def cam_prep_data(self):
        # create and add cam object to cam_list
        ts_logger.info("\n======================")
        for pack_path in self.pack_list:
            cam = TsCam(pack_path)
            cam.prep_data(self.cam_img_dir, self.flipped_cams)
            self.cam_list.append(cam)
            image_num = cam.pack_to_image()
            if image_num > 0:
                self.img_cams.append(cam)
        if not self.img_cams:
            ts_logger.error(f"No image folders in {self.cam_img_dir}")

    # interpolate missing frames
    def cam_inter_frm(self):
        ts_logger.info("\n======================")
        missing_rate_max = 0.05
        for cam in self.img_cams:
            missing_rate = cam.inter_frames()
            if missing_rate < missing_rate_max:
                self.inter_cams.append(cam)
            else:
                ts_logger.error(f"Cam {cam.cam_name} missing too many images")
        if not self.inter_cams:
            ts_logger.error(f"Interpolate frames failed")

    # syncrhonize ts by deleting unwanted imgs
    def cam_sync_img(self):
        ts_logger.info("\n======================")
        for cam in self.inter_cams:
            ts_logger.info("")
            cam.sync_img()
            cam.img_to_tar(self.cam_img_dir, self.cam_tar_dir)
            cam.img_to_mp4(self.cam_mp4_dir)

    # prepare mic data
    def mic_prep_data(self):
        ts_logger.info("\n======================")
        for wav_path in self.wav_list:
            mic = TsMic(wav_path)
            mic.prep_data()
            self.mic_list.append(mic)

    # sync mic ts
    def mic_sync_wav(self):
        ts_logger.info("\n======================")
        for mic in self.sync_mics:
            mic.sync_wav(self.mic_wav_dir)

    # merge input .wav and .pack files into mp4
    def mm_merge_mp4(self):
        ts_logger.info("\n======================")
        ts_logger.info("")
        ts_logger.info("MM merge cam and mic into mp4")

        for cam, mic in product(self.sync_cams, self.sync_mics):
            cam_snt = "_".join(cam.cam_name.split('_')[:-1])
            mic_snt = "_".join(mic.mic_name.split('_')[:-1])
            if cam_snt != mic_snt:
                ts_logger.info(f"SNT diff in {cam.cam_name} and" +
                               f" {mic.mic_name}")
                continue
            cam_id = cam.cam_name.split("_")[-1]
            mic_id = mic.mic_name.split("_")[-1]
            cam_path = OSFile.join_path(self.cam_mp4_dir,
                                        f"{cam.cam_name}.mp4")
            mic_path = OSFile.join_path(self.mic_wav_dir,
                                        f"{mic.mic_name}.wav")
            mp4_path = OSFile.join_path(self.mix_mp4_dir,
                                        f"{cam_snt}_{cam_id}_{mic_id}.mp4")
            mp4_cmd = f"ffmpeg -loglevel error -i {cam_path} -i " + \
                f"{mic_path} -c:v copy -c:a libmp3lame -map" + \
                f" 0:v:0 -map 1:a:0 {mp4_path} </dev/null"
            ts_logger.info(f"{mp4_cmd}")
            OSCmd.sys_exec(mp4_cmd)
