#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
import cv2
import numpy
from utils.comm.os import OSCmd
from utils.comm.os import OSFile
from utils.comm.os import OSDir
from utils.comm.log import ts_logger


class TsCam:
    def __init__(self, pack_path):
        self.pack_path = pack_path
        # self.flipped
        # self.cam_name
        # self.img_path
        # self.fps
        # self.ts_beg
        # self.ts_end

    # set fields
    def prep_data(self, cam_img_dir, flipped_cams):
        self.cam_name = OSFile.file_name(self.pack_path)
        self.img_path = OSFile.join_path(cam_img_dir, self.cam_name)
        cam_id = self.cam_name.split("_")[-1]
        if cam_id in flipped_cams:
            self.flipped = True
        else:
            self.flipped = False

    # unpack pack in pack_path into images and save at img_path
    # return: image_num # of images unpacked
    def pack_to_image(self):
        ts_logger.info("")
        if self.flipped:
            ts_logger.info(f"File {self.cam_name} is flipped")
        OSDir.init_dir(self.img_path)
        image_num = 0
        with open(self.pack_path, 'rb') as pack_file:
            ts_logger.info(f"Open {self.pack_path}")
            while True:
                image_head_buf = pack_file.read(16)
                if not image_head_buf:
                    ts_logger.info(f"Read EOF of {self.pack_path}")
                    break
                image_head = numpy.frombuffer(image_head_buf,
                                              dtype=numpy.uint64)
                image_ts, image_size = image_head[0], image_head[1]
                image_name = str(image_ts) + '.jpg'
                image_data_buf = pack_file.read(image_size)
                if not image_data_buf:
                    ts_logger.info(f"Read EOF of {self.pack_path} abnormal")
                    break
                if self.flipped:
                    image_data_wrt = flip_image_buf(image_data_buf)
                    ts_logger.debug(f"Image {image_name} is flipped")
                else:
                    image_data_wrt = image_data_buf
                image_path = OSFile.join_path(self.img_path, image_name)
                with open(image_path, 'wb') as image_file:
                    image_file.write(image_data_wrt)
                    ts_logger.debug(f"Image {image_name} is saved")
                image_num += 1
        if image_num > 0:
            ts_logger.info(f"Save {image_num} images to {self.img_path}")
        else:
            OSFile.remove_dir(self.img_path)
        return image_num

    # calculate camera fps = ts gap sum/ts count
    def set_fps(self):
        img_files = OSDir.sub_files(self.img_path)
        ts_gap_list = []
        for i in range(3, min(100, len(img_files) - 2)):
            beg = self.get_image_ts(img_files[i])
            end = self.get_image_ts(img_files[i+1])
            ts_gap_list.append(end - beg)
        ts_gap_avg = sum(ts_gap_list) / len(ts_gap_list)

        if abs(ts_gap_avg - 40) < 1:
            self.fps = 25
        elif abs(ts_gap_avg - 33) < 1:
            self.fps = 30
        else:
            self.fps = 1000.0 / ts_gap_avg

    # interpolate missing frames
    # return missing rate = missing #/frame #
    def inter_frames(self):
        # set gap threshold based on fps
        ts_logger.info(f"")
        self.set_fps()
        if self.fps not in [25, 30]:
            ts_logger.warning(f"Cam {self.cam_name} fps {self.fps} is invalid")
            return 1

        ts_logger.info(f"CAM {self.cam_name} interpolate missing frames")

        if self.fps == 25:
            gap_thres = 45
        elif self.fps == 30:
            gap_thres = 37
        else:
            ts_logger.error(f"Cam fps {self.fps} is not supported")
            return 1

        missing_num = 0
        frame_gap = 1000 // self.fps
        img_files = [img for img in OSDir.sub_files(self.img_path)]

        self.ts_beg = self.get_image_ts(img_files[0])
        self.ts_end = self.get_image_ts(img_files[-1])
        frame_num = (self.ts_end - self.ts_beg)

        prev_image_ts = self.get_image_ts(img_files[0])
        for image_name in img_files:
            image_ts = self.get_image_ts(image_name)
            ts_gap = image_ts - prev_image_ts
            # interpolate frames
            if ts_gap > gap_thres:
                # unit is 100ms
                gap_unit = 100
                gap_unit_count = ts_gap // gap_unit
                gap_unit_remain = ts_gap % gap_unit
                unit_frm_cnt = gap_unit // self.fps
                if self.fps == 30:
                    if gap_unit_remain <= 1:
                        remain_frm_cnt = 0
                    elif gap_unit_remain > 1 and gap_unit_remain < 37:
                        remain_frm_cnt = 1
                    elif gap_unit_remain >= 37 and gap_unit_remain < 70:
                        remain_frm_cnt = 2
                    else:
                        ts_logger.error("Invalid camera fps")
                        return -1
                else:
                    remain_frm_cnt = (gap_unit_remain + 1) // frame_gap

                missing_cnt = gap_unit_count * unit_frm_cnt + \
                    remain_frm_cnt - 1
                # ts_logger.info(f"Missing {missing_cnt} frames")
                missing_num += missing_cnt

                # copy existed img to fill in place of missing img
                for i in range(missing_cnt):
                    new_ts = prev_image_ts + (i + 1) * frame_gap
                    new_name = str(new_ts) + '.jpg'
                    old_file = OSFile.join_path(self.img_path, image_name)
                    new_file = OSFile.join_path(self.img_path, new_name)
                    cp_cmd = f"cp {old_file} {new_file}"
                    OSCmd.sys_exec(cp_cmd)
            prev_image_ts = image_ts

        missing_rate = round(missing_num / frame_num, 6)
        ts_logger.info(f"Interpolate {missing_num} missing images with " +
                       f"{missing_rate} missing rate")
        return missing_rate

    # syncrhonize ts by deleting unwanted imgs
    def sync_img(self):
        ts_logger.info(f"CAM {self.cam_name} synchronize images")
        head_cnt, tail_cnt = 0, 0
        img_files = OSDir.sub_files(self.img_path)
        head_ts = self.get_image_ts(img_files[0])
        tail_ts = self.get_image_ts(img_files[-1])
        for image_name in img_files:
            image_path = OSFile.join_path(self.img_path, image_name)
            image_ts = self.get_image_ts(image_name)
            if image_ts < self.sync_beg:
                head_cnt += 1
                OSFile.remove_file(image_path)
            elif image_ts > self.sync_end:
                tail_cnt += 1
                OSFile.remove_file(image_path)
            else:
                pass
        ts_logger.info(f"Cam {self.cam_name} fps {self.fps}")
        if head_cnt > 0:
            ts_logger.info(f"From [{head_ts}, {self.sync_beg}] removes" +
                           f"{head_cnt} head images")
        if tail_cnt > 0:
            ts_logger.info(f"From [{self.sync_end}, {tail_ts}] removes" +
                           f"{tail_cnt} tail images")

    # merge image to tar
    def img_to_tar(self, cam_img_dir, out_data_dir):
        tar_path = OSFile.join_path(out_data_dir, f"{self.cam_name}.tar")
        tar_cmd = f"tar -cf {tar_path} -C {cam_img_dir} {self.cam_name}"
        ts_logger.info(tar_cmd)
        OSCmd.sys_exec(tar_cmd)

    # merge image to mp4
    def img_to_mp4(self, cam_mp4_dir):
        mp4_path = OSFile.join_path(cam_mp4_dir, f"{self.cam_name}.mp4")
        mp4_cmd = f"ffmpeg -loglevel error -framerate {self.fps} " + \
            f"-pattern_type glob -i '{self.img_path}/*.jpg' -y" + \
            f" {mp4_path} </dev/null"
        ts_logger.info(mp4_cmd)
        OSCmd.sys_exec(mp4_cmd)

    # return: img timestamp
    def get_image_ts(self, image_name):
        return int(OSFile.name_prefix(image_name))

    # use cv2 to flip flipped image
    # return: flipped image in byte array
    def flip_image_buf(self, image_buf):
        image_array = numpy.frombuffer(image_buf, dtype=numpy.uint8)
        image_data = cv2.imdecode(image_array, 0)
        flip_data = cv2.flip(image_data, 1)
        flip_array = cv2.imencode('.jpg', flip_data)[1]
        return flip_array.tobytes()

    # merge image to tgz
    def img_to_tgz(self, cam_img_dir, out_data_dir):
        tgz_path = OSFile.join_path(out_data_dir, f"{self.cam_name}.tgz")
        tgz_cmd = f"tar -cf {tgz_path} -C {cam_img_dir} {self.cam_name}"
        ts_logger.info(tgz_cmd)
        OSCmd.sys_exec(tgz_cmd)
