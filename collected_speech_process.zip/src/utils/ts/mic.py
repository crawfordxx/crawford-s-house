#!/usr/bin/env python3
# -*- coding: UTF-8 -*-


import io
import wave
from utils.io.stdio import read_list_file
from utils.io.stdio import get_wav_len
from utils.comm.log import ts_logger
from utils.comm.os import OSFile
from utils.comm.os import OSCmd


class TsMic():
    def __init__(self, wav_path):
        self.wav_path = wav_path

    # read file and set fields
    def prep_data(self):
        self.mic_name = OSFile.file_name(self.wav_path)
        ts_path = self.wav_path[:-4] + ".ts"
        ts_str_list = read_list_file(ts_path)
        ts_data = sorted([int(ts) for ts in ts_str_list])

        if ts_data == 0:
            return
        self.ts_beg = ts_data[0]
        self.ts_end = ts_data[-1]

        ts_len_ms = ts_data[-1] - ts_data[0]
        wav_len_ms = get_wav_len(self.wav_path)
        self.wav_tempo = wav_len_ms / ts_len_ms

        ts_logger.info(f"")
        ts_logger.info(f"MIC {self.mic_name} wav_len_ms: {wav_len_ms}")
        ts_logger.info(f"MIC {self.mic_name} ts_len_ms:  {ts_len_ms}")
        ts_logger.info(f"MIC {self.mic_name} wav_tempo:  {self.wav_tempo}")

    # trim wav files based on synced ts data
    def sync_wav(self, out_fdr_path):
        ts_logger.info("")
        ts_logger.info(f"MIC {self.mic_name} synchronize wav and ts")

        out_wav_path = OSFile.join_path(out_fdr_path, f"{self.mic_name}.wav")

        ts_logger.info(f"From [{self.ts_beg}, {self.sync_beg}] cut " +
                       f"{self.sync_beg-self.ts_beg} ms head wav")
        ts_logger.info(f"From [{self.sync_end}, {self.ts_end}] cut " +
                       f"{self.ts_end-self.sync_end} ms tail wav")

        trim_beg = (self.sync_beg - self.ts_beg) / 1000
        trim_dur = (self.sync_end - self.sync_beg) / 1000
        wav_cmd = f"sox {self.wav_path} -t raw - tempo {self.wav_tempo} " + \
            f"trim {trim_beg} {trim_dur}"
        wav_proc = OSCmd.sub_exec(wav_cmd)
        raw_data = io.BytesIO(wav_proc.stdout).read()

        with wave.open(self.wav_path, 'rb') as wave_file:
            wav_params = wave_file.getparams()
        with wave.open(out_wav_path, 'wb') as wave_file:
            wave_file.setparams(wav_params)
            wave_file.writeframesraw(raw_data)
        ts_logger.info(f"Save {out_wav_path}")
