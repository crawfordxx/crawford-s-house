#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
from typing import Any, Dict, List, Optional
from utils.io.stdio import read_list_file
from utils.io.stdio import read_json_file
from utils.desc.desc_speaker_batch import DescSpeakerBatch
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.comm.log import logger


# limit long sentence
def read_lls_file(lls_path) -> Optional[List]:
    if not lls_path:
        return
    try:
        wav_name = os.path.basename(lls_path).split('.')[0]
        with open(lls_path, 'rt', encoding='gbk') as lls_file:
            lls_json_list = json.loads(lls_file.read())
            if not lls_json_list:
                logger.error(f"{lls_path} is empty")
                return
    except Exception as excp:
        logger.error(excp)
        return

    sentence_list = []
    for lls_json in lls_json_list:
        text = lls_json.get('result')
        vad_beg_str = lls_json.get('vad_begin')
        vad_end_str = lls_json.get('vad_end')
        if not (text and vad_beg_str and vad_end_str):
            logger.error(f"{lls_json} is invalid")
            continue
        if text == 'reject':
            continue
        vad_beg = round(float(vad_beg_str) / 100, 3)
        vad_end = round(float(vad_end_str) / 100, 3)
        sentence_json = {
            "wav_name": wav_name,
            "sentence": {
                "text": text,
                "vad_beg": vad_beg,
                "vad_end": vad_end
            }
        }
        sentence_list.append(sentence_json)
    return sentence_list


def read_lls_files(lls_lst_path) -> Optional[Any]:
    lls_path_list = read_list_file(lls_lst_path)
    if not lls_path_list:
        return
    sentence_list = []
    for lls_path in lls_path_list:
        snt_list = read_lls_file(lls_path)
        if snt_list:
            sentence_list.extend(snt_list)
    if not sentence_list:
        logger.error(f"{lls_lst_path} read all empty")
        return
    sentence_batch = DescSentenceBatch()
    if not sentence_batch.set_sentence_batch(sentence_list):
        logger.error(f"{lls_lst_path} set sentence failed")
        return
    return sentence_batch


# unlimit short sentence
def _get_uss_vad(phones):
    frame_length = 0.01
    vad_beg_num, vad_end_num = 0, 0

    # vad_beg
    seq = phones.split()
    for idx in range(len(seq)):
        if idx == 0 and seq[idx] != "1":
            vad_beg_num = 0
            break
        if idx != 0 and seq[idx-1] == "1" and seq[idx] != "1":
            vad_beg_num = idx
            break

    # vad_end
    seq = phones.split()[::-1]
    for idx in range(len(seq)):
        if idx == 0 and seq[idx] != "1":
            vad_end_num = len(seq)
            break
        if idx != 0 and seq[idx-1] == "1" and seq[idx] != "1":
            vad_end_num = len(seq) - idx
            break

    if vad_beg_num >= vad_end_num:
        logger.error(f"{vad_beg_num} and {vad_end_num} is invalid")
        return

    vad_beg = round(frame_length * vad_beg_num, 3)
    vad_end = round(frame_length * vad_end_num, 3)
    return vad_beg, vad_end


def read_uss_file(uss_json_path):
    uss_json_list = read_json_file(uss_json_path)
    if not uss_json_list:
        return None, None

    speaker_json_list = []
    sentence_json_list = []
    for uss_json in uss_json_list:
        # speaker
        wav_name = uss_json.get("wav_name")
        spkid = uss_json.get("wav_name")
        gender = uss_json.get("gender")
        age = uss_json.get("age")
        if not (spkid and gender and age):
            logger.error(f"{wav_name} spkid, gender or age is None")
            continue
        speaker_json = {
            "basic": {"wav_name": wav_name},
            "speaker": {"spkid": spkid, "gender": gender, "age": age}
        }
        speaker_json_list.append(speaker_json)

        # sentence
        text = uss_json.get("text")
        phones = uss_json.get("phone_seq")
        if not (text and phones):
            logger.error(f"{wav_name} text or phones is None")
            continue
        vad_beg, vad_end = _get_uss_vad(phones)
        if not (vad_beg and vad_end):
            logger.error(f"{wav_name} vad_beg or vad_end is None")
            continue
        sentence_json = {
            "basic": {"wav_name": wav_name},
            "sentence": [{"text": text, "vad_beg": vad_beg,
                          "vad_end": vad_end, "phones": phones}]
        }
        sentence_json_list.append(sentence_json)

    speaker_batch = DescSpeakerBatch()
    if not speaker_batch.set_batch_json_list(speaker_json_list):
        logger.error(f"set speaker batch failed")
        return None, None
    sentence_batch = DescSentenceBatch()
    if not sentence_batch.set_batch_json_list(sentence_json_list):
        logger.error(f"set sentence batch failed")
        return speaker_batch, None
    return speaker_batch, sentence_batch
