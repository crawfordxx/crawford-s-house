#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from typing import Dict, Optional
from utils.device.mic import DeviceMic
from utils.comm.log import logger


def read_config_file(config_path) -> Optional[Dict]:
    config_info = {}

    # read
    try:
        with open(config_path, "rt", encoding='utf-8') as config_file:
            config_json = json.load(config_file)
    except Exception as exp:
        logger.error(exp)
        return

    # basic
    basic_json = config_json.get("basic")
    if not basic_json:
        logger.error(f"{config_path} basic is None")
        return
    config_info["basic"] = basic_json

    # mics
    mic_list = []
    mic_json_dict = config_json.get("mics")
    if not mic_json_dict:
        logger.error(f"{config_path} mics is None")
        return
    for mic_index, mic_json in mic_json_dict.items():
        mic = DeviceMic(mic_index)
        if not mic.set_json(mic_json):
            return
        mic_list.append(mic)
        logger.warning(f"read {mic_index}")
    config_info["mics"] = mic_list

    return config_info


def write_config_file(config_info, config_path):
    config_json = {}
    if not config_info or not config_path:
        logger.error(f"config_info or config_path is None")
        return

    # basic
    basic_info = config_info.get("basic")
    if not basic_info:
        logger.error(f"config_info basic is None")
        return
    config_json["basic"] = basic_info

    # mics
    mic_json_dict = {}
    mic_list = config_info.get("mics")
    if not mic_list:
        logger.error(f"config_info mics is None")
        return
    for mic in mic_list:
        mic_index = mic.index
        if mic_index in mic_json_dict:
            logger.error(f"config_info mics is None")
            return
        mic_json = mic.get_json()
        if not mic_json:
            return
        mic_json_dict[mic_index] = mic_json
        logger.warning(f"write {mic_index}")
    config_json["mics"] = mic_json_dict

    # write
    try:
        with open(config_path, "wt", encoding='utf-8') as config_file:
            json.dump(config_json, config_file, ensure_ascii=False, indent=4)
    except Exception as exp:
        logger.error(exp)
        return
