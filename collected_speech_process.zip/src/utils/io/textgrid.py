#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from typing import Any, Dict, List, Optional
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.io.stdio import read_list_file
from utils.comm.log import logger


# read
def _parse_textgrid_lines(textgrid_lines) -> Optional[Dict]:
    head_num = 0
    for line in textgrid_lines:
        head_num += 1
        line = line.strip()
        if line.startswith("name"):
            textgrid_name = line.split()[-1].strip('"')
        if line.startswith("xmax"):
            textgrid_xmax = float(line.split()[-1])
        if line.startswith("intervals: size"):
            textgrid_size = int(line.split()[-1])
            break
    if not (textgrid_name and textgrid_xmax and textgrid_size and
            head_num != len(textgrid_lines)):
        logger.error(f"textgrid head is invalid")
        return

    try:
        interval_list = []
        for i in range(head_num, len(textgrid_lines), 4):
            index = int(textgrid_lines[i].split('[')[-1].split(']')[0])
            xmin = round(float(textgrid_lines[i+1].split()[-1]), 3)
            xmax = round(float(textgrid_lines[i+2].split()[-1]), 3)
            text = textgrid_lines[i+3].split('"')[-2].strip()
            interval_list.append([index, xmin, xmax, text])
    except Exception as excp:
        logger.error(excp)
        return

    textgrid_info = {
             "name": textgrid_name,
             "xmax": textgrid_xmax,
             "size": textgrid_size,
             "intervals": interval_list
             }
    return textgrid_info


def _check_textgrid_format(textgrid_info) -> bool:
    textgrid_name = textgrid_info["name"]
    interval_list = textgrid_info["intervals"]

    # xmax
    textgrid_xmax = textgrid_info["xmax"]
    interval_xmax = interval_list[-1][2]
    if textgrid_xmax != interval_xmax:
        logger.error(f"{textgrid_name} textgrid xmax is invalid")
        return False

    # index
    textgrid_size = textgrid_info["size"]
    interval_size = len(interval_list)
    if textgrid_size != interval_size:
        logger.error(f"{textgrid_name} textgrid size is invalid")
        return False

    # list
    interval_result = True
    interval_idx, last_xmax, last_text = 1, 0, "text"
    for interval in interval_list:
        index, xmin, xmax, text = tuple(interval)
        if index != interval_idx:
            logger.error(f"{textgrid_name} interval {index} index is invalid")
            interval_result = False
        if xmin != last_xmax:
            logger.error(f"{textgrid_name} interval {index} xmin is invalid")
            interval_result = False
        if xmax <= xmin:
            logger.error(f"{textgrid_name} interval {index} xmax is invalid")
            interval_result = False
        if text == last_text:
            logger.error(f"{textgrid_name} interval {index} text is invalid")
            interval_result = False
        if (text != '') and (last_text != ''):
            logger.error(f"{textgrid_name} interval {index} text is invalid")
            interval_result = False
        interval_idx += 1
        last_xmax = xmax
        last_text = text

    return interval_result


def _get_sentence_list(textgrid_info) -> Optional[List]:
    if not textgrid_info:
        return
    sentence_list = []
    wav_name = textgrid_info["name"]
    interval_list = textgrid_info["intervals"]
    for interval in interval_list:
        index, xmin, xmax, text = tuple(interval)
        if not text:
            continue
        sentence_json = {
            "wav_name": wav_name,
            "sentence": {
                "text": text,
                "vad_beg": xmin,
                "vad_end": xmax
            }
        }
        sentence_list.append(sentence_json)
    return sentence_list


def read_textgrid_file(textgrid_path) -> Optional[Dict]:
    textgrid_lines = read_list_file(textgrid_path)
    if not textgrid_lines:
        return
    textgrid_info = _parse_textgrid_lines(textgrid_lines)
    if not textgrid_info:
        logger.error(f"{textgrid_path} parse lines failed")
        return
    if not _check_textgrid_format(textgrid_info):
        logger.error(f"{textgrid_path} check format failed")
        return
    return textgrid_info


def read_textgrid_files(textgrid_lst_path) -> Optional[Any]:
    textgrid_path_list = read_list_file(textgrid_lst_path)
    if not textgrid_path_list:
        return
    sentence_list = []
    for textgrid_path in textgrid_path_list:
        textgrid_info = read_textgrid_file(textgrid_path)
        if textgrid_info:
            snt_list = _get_sentence_list(textgrid_info)
            if snt_list:
                sentence_list.extend(snt_list)
    if not sentence_list:
        logger.error(f"{textgrid_lst_path} read all empty")
        return
    sentence_batch = DescSentenceBatch()
    if not sentence_batch.set_sentence_batch(sentence_list):
        logger.error(f"{textgrid_lst_path} set sentence failed")
        return
    return sentence_batch


# write
def _get_textgrid_info(desc_item) -> Optional[Dict]:
    wav_name = desc_item.basic_item.basic_data.wav_name
    duration = desc_item.audio_item.audio_data.duration
    snt_list = desc_item.sentence_item_list
    if not snt_list or len(snt_list) < 2:
        logger.error(f"{wav_name} get textgrid info failed")
        return

    last_xmax, index, interval_list = 0, 1, []
    for snt_item in snt_list:
        xmin = snt_item.sentence_data.vad_beg
        xmax = snt_item.sentence_data.vad_end
        text = snt_item.sentence_data.text
        interval_list.append([2*index-1, last_xmax, xmin, ''])
        interval_list.append([2*index, xmin, xmax, text])
        last_xmax = xmax
        index += 1
    interval_list.append([2*index-1, last_xmax, duration, ''])

    textgrid_info = {
        "name": wav_name,
        "xmax": duration,
        "size": len(interval_list),
        "intervals": interval_list
    }
    return textgrid_info


def _concat_textgrid_head(textgrid_info) -> str:
    head = []
    name = textgrid_info["name"]
    xmax = textgrid_info["xmax"]
    size = textgrid_info["size"]
    head.append(f'File type = "ooTextFile"\n')
    head.append(f'Object class = "TextGrid"\n\n')
    head.append(f'xmin = 0\n')
    head.append(f'xmax = {xmax}\n')
    head.append(f'tiers? <exists>\n')
    head.append(f'size = 1\n')
    head.append(f'item []:\n')
    head.append(f'\titem [1]:\n')
    head.append(f'\t\tclass = "IntervalTier"\n')
    head.append(f'\t\tname = "{name}"\n')
    head.append(f'\t\txmin = 0\n')
    head.append(f'\t\txmax = {xmax}\n')
    head.append(f'\t\tintervals: size = {size}\n')
    return ''.join(head)


def _interval_to_str(interval) -> str:
    index, xmin, xmax, text = tuple(interval)
    interval_str = f'\t\tintervals [{index}]:\n' \
        f'\t\t\txmin = {xmin}\n' \
        f'\t\t\txmax = {xmax}\n' \
        f'\t\t\ttext = "{text}"\n'
    return interval_str


def write_textgrid_file(textgrid_info, textgrid_path) -> None:
    textgrid_head = _concat_textgrid_head(textgrid_info)
    interval_str_list = [_interval_to_str(interval) for interval
                         in textgrid_info["intervals"]]
    textgrid_intervals = ''.join(interval_str_list)
    with open(textgrid_path, 'wt', encoding='utf-8') as textgrid_file:
        textgrid_file.write(textgrid_head)
        textgrid_file.write(textgrid_intervals)
    return


def write_textgrid_files(desc_batch, textgrid_dir) -> None:
    desc_item_list = desc_batch.batch_dict.values()
    for desc_item in desc_item_list:
        textgrid_info = _get_textgrid_info(desc_item)
        if not textgrid_info:
            continue
        wav_name = desc_item.basic_item.basic_data.wav_name
        textgrid_path = os.path.join(textgrid_dir, f"{wav_name}.TextGrid")
        write_textgrid_file(textgrid_info, textgrid_path)
    return
