#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Dict, List, Optional
from utils.io.stdio import read_list_file
from utils.io.stdio import read_dict_file
from utils.comm.log import logger


# scene
def _parse_scene_line(scene_line) -> Optional[Dict]:
    if not scene_line:
        logger.error(f"scene_line is None")
        return None
    line_splits = [attr.strip() for attr in scene_line.split('\t')]
    if len(line_splits) <= 2:
        logger.error(f"{scene_line} length error")
        return None
    scid = line_splits[0]
    domain = line_splits[1].replace('家居', 'home').replace('车载', 'car')
    attrs = line_splits[2:]

    if domain == 'home':
        if len(attrs) != 7:
            logger.error(f"{scene_line} home attrs length error")
            return None
        attrs_json = {
            "location": attrs[0],
            "direction": attrs[1],
            "distance": attrs[2],
            "noise": attrs[3],
            "snr": attrs[4],
            "echo": attrs[5],
            "ser": attrs[6]
        }
    elif domain == 'car':
        if len(attrs) != 7:
            logger.error(f"{scene_line} car attrs length error")
            return None
        attrs_json = {
            "model": attrs[0],
            "dev_pos": attrs[1],
            "spk_pos": attrs[2],
            "speed": attrs[3],
            "window": attrs[4],
            "air_con": attrs[5],
            "FM": attrs[6]
        }
    else:
        logger.error(f"{scene_line} domain is invalid")
        return None

    attrs_keys = list(attrs_json.keys())
    for key in attrs_keys:
        if not attrs_json[key]:
            del attrs_json[key]
    if not attrs_json:
        logger.error(f"{scene_line} attrs is empty")
        return None

    scene_json = {
        "scid": scid,
        "domain": domain,
        "attrs": attrs_json
    }
    return scene_json


def read_scene_lst(scene_lst) -> Optional[List]:
    scene_lines = read_list_file(scene_lst)
    if not scene_lines:
        return None
    scene_list = []
    for scene_line in scene_lines:
        scene_json = _parse_scene_line(scene_line)
        if not scene_json:
            logger.error(f"{scene_line} is invalid")
            continue
        scene_list.append(scene_json)
    return scene_list


# speaker
def _parse_speaker_line(speaker_line) -> Optional[Dict]:
    if not speaker_line:
        logger.error(f"speaker_line is None")
        return None
    attrs = [attr.strip() for attr in speaker_line.split('\t')]
    if len(attrs) != 5:
        logger.error(f"{speaker_line} length error")
        return None

    speaker_json = {
        "spkid": attrs[0],
        "gender": attrs[1].replace('男', 'male')
                          .replace('女', 'female'),
        "age": attrs[2],
        "region": attrs[3],
        "accent": attrs[4].replace('普通话', 'mandarin')
                          .replace('口音', 'accent')
                          .replace('方言', 'dialect')
    }

    speaker_keys = list(speaker_json.keys())
    for key in speaker_keys:
        if not speaker_json[key]:
            del speaker_json[key]
    if not speaker_json:
        logger.error(f"{speaker_line} is empty")
        return None

    return speaker_json


def read_speaker_lst(speaker_lst) -> Optional[List]:
    speaker_lines = read_list_file(speaker_lst)
    if not speaker_lines:
        return None
    speaker_list = []
    for speaker_line in speaker_lines:
        speaker_json = _parse_speaker_line(speaker_line)
        if not speaker_json:
            logger.error(f"{speaker_line} is invalid")
            continue
        speaker_list.append(speaker_json)
    return speaker_list


# sentence
def read_sentence_lst(wav2txt_lst, wav2emt_lst, wav2NLU_lst) -> Optional[List]:
    if not wav2txt_lst and not wav2emt_lst:
        logger.error(f"wav2txt_lst and wav2emt_lst is None")
        return

    wav2txt_dict = read_dict_file(wav2txt_lst)
    wav2emt_dict = read_dict_file(wav2emt_lst)
    wav2NLU_dict = read_dict_file(wav2NLU_lst)
    if not wav2txt_dict and not wav2emt_dict:
        logger.error(f"{wav2txt_lst} and {wav2emt_lst} is empty")
        return
    if not wav2txt_dict:
        wav2txt_dict = {}
    if not wav2emt_dict:
        wav2emt_dict = {}
    if not wav2NLU_dict:
        wav2NLU_dict = {}

    sentence_list = []
    wav_set = set(list(wav2txt_dict.keys()) + list(wav2emt_dict.keys()))
    for wav_name in wav_set:
        sentence_json = {
            "wav_name": wav_name,
            "sentence": {
                "text": wav2txt_dict.get(wav_name),
                "emotion": wav2emt_dict.get(wav_name),
                "NLU": {
                    "domain": wav2NLU_dict.get(wav_name)
                }
            }
        }
        sentence_list.append(sentence_json)

    return sentence_list
