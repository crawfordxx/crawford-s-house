#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Any, Dict, List, Optional
from utils.desc.desc_speaker_batch import DescSpeakerBatch
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.io.stdio import read_json_file
from utils.io.stdio import write_json_file
from utils.comm.text import process_one_text
from utils.comm.log import logger


# read
def _get_plat_header(plat_json):
    if not plat_json:
        logger.error(f"plat_json is None")
        return None, None
    image_key = plat_json.get("image_key")
    if not image_key:
        logger.error(f"image_key is None")
        return None, None
    wav_name = image_key.split(".")[0]
    voice_list = plat_json.get("voice")
    if not voice_list:
        logger.error(f"{wav_name} voice is None")
        return wav_name, None
    if len(voice_list) == 0:
        logger.error(f"{wav_name} voice is empty")
        return wav_name, None
    return wav_name, voice_list


def _get_plat_speaker(plat_json) -> Optional[Dict]:
    wav_name, voice_list = _get_plat_header(plat_json)
    if not wav_name or not voice_list:
        return

    speaker_json = {}
    for voice_item in voice_list:
        sections = voice_item.get("sections")
        if not sections:
            logger.error(f"{wav_name} sections is None")
            return

        gender = sections.get("gender")
        age = sections.get("age")
        accent_type = sections.get("accent_type")
        if accent_type == "putonghua":
            region = None
            accent = "mandarin"
        elif accent_type == "nanfanghua":
            region = "south"
            accent = "accent"
        elif accent_type == "beifanghua":
            region = "north"
            accent = "accent"
        else:
            region = None
            accent = None

        if gender or age or region or accent:
            current_json = {
                "spkid": wav_name,
                "gender": gender,
                "age": age,
                "region": region,
                "accent": accent
            }
            if speaker_json and speaker_json != current_json:
                logger.error(f"{wav_name} speaker conflict")
                return
            speaker_json = current_json
    return speaker_json


def _get_plat_sentence(plat_json) -> Optional[List]:
    wav_name, voice_list = _get_plat_header(plat_json)
    if not wav_name or not voice_list:
        return
    sentence_list = []
    for voice_item in voice_list:
        sections = voice_item.get("sections")
        vad_ends = voice_item.get("r")
        if not sections or not vad_ends:
            logger.error(f"{wav_name} sections or vad_ends is None")
            return
        text = process_one_text(sections.get("content"))
        emotion = sections.get("emotion")
        if not text and not emotion:
            continue
        sentence_json = {
            "wav_name": wav_name,
            "sentence": {
                "text": text,
                "emotion": emotion,
                "vad_beg": vad_ends[0] / 1000,
                "vad_end": vad_ends[1] / 1000
            }
        }
        sentence_list.append(sentence_json)
    return sentence_list


def _plat_to_speaker(plat_json_list) -> Optional[Any]:
    speaker_list, wav2spk_dict = [], {}
    for plat_json in plat_json_list:
        speaker_json = _get_plat_speaker(plat_json)
        if speaker_json:
            speaker_list.append(speaker_json)
            spkid = speaker_json['spkid']
            wav2spk_dict[spkid] = spkid
    if not speaker_list or not wav2spk_dict:
        return
    speaker_batch = DescSpeakerBatch()
    if not speaker_batch.set_speaker_batch(speaker_list, wav2spk_dict):
        logger.error(f"set speaker batch failed")
        return
    return speaker_batch


def _plat_to_sentence(plat_json_list) -> Optional[Any]:
    sentence_list = []
    for plat_json in plat_json_list:
        snt_json_list = _get_plat_sentence(plat_json)
        if snt_json_list:
            sentence_list.extend(snt_json_list)
    if not sentence_list:
        logger.error(f"get plat sentence failed")
        return
    sentence_batch = DescSentenceBatch()
    if not sentence_batch.set_sentence_batch(sentence_list):
        logger.error(f"set sentence batch failed")
        return
    return sentence_batch


def read_plat_file(plat_path):
    plat_json_list = read_json_file(plat_path)
    if not plat_json_list:
        return
    speaker_batch = _plat_to_speaker(plat_json_list)
    sentence_batch = _plat_to_sentence(plat_json_list)
    return speaker_batch, sentence_batch


# write
def _desc_to_plat(desc_item) -> Optional[Dict]:
    # image_key
    wav_name = desc_item.basic_item.basic_data.wav_name
    image_key = wav_name + ".wav"
    voice_list = []

    # speaker
    if desc_item.speaker_item:
        speaker_data = desc_item.speaker_item.speaker_data
        # gender
        gender = speaker_data.gender
        # age
        age = speaker_data.age
        if age and age.isdecimal():
            age_int = int(age)
            if age_int <= 12:
                age = "child"
            elif age_int <= 55:
                age = "adult"
            else:
                age = "older"
        # accent_type
        accent = speaker_data.accent
        if accent and accent in ["accent", "dialect"]:
            accent_type = "beifanghua"
        else:
            accent_type = "putonghua"
    else:
        gender = None
        age = None
        accent_type = None

    # sentence
    sentence_item_list = desc_item.sentence_item_list
    if not sentence_item_list:
        logger.error(f"{wav_name} sentence_item_list is empty")
        return
    for index, sentences_item in enumerate(sentence_item_list, start=1):
        sentences_data = sentences_item.sentence_data
        content = sentences_data.text
        emotion = sentences_data.emotion
        vad_beg = int(sentences_data.vad_beg * 1000)
        vad_end = int(sentences_data.vad_end * 1000)
        snt_id = wav_name + "_" + str(index)

        sections = {
            "content": content,
            "emotion": emotion,
            "gender": gender,
            "age": age,
            "accent_type": accent_type
        }
        sections_keys = list(sections.keys())
        for key in sections_keys:
            if not sections[key]:
                del sections[key]
        if not sections:
            logger.warning(f"{wav_name} sentence {index} is empty")
            continue

        plat_voice = {
            "struct_type": "voice",
            "label_type": "sections",
            "sections": sections,
            "id": snt_id,
            "r": [vad_beg, vad_end]
        }
        voice_list.append(plat_voice)

    # plat
    plat_json = {
        "image_key": image_key,
        "voice": voice_list
    }
    return plat_json


def write_plat_file(desc_batch, plat_path) -> None:
    plat_json_list = []
    for desc_item in desc_batch.batch_dict.values():
        plat_json = _desc_to_plat(desc_item)
        if plat_json:
            plat_json_list.append(plat_json)
    if not plat_json_list:
        logger.error(f"plat_json_list is empty")
        return
    write_json_file(plat_json_list, plat_path)
    return
