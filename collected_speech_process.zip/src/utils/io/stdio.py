#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import json
import wave
from typing import Any, Dict, List, Optional
from utils.desc.desc_batch import DescBatch
from utils.desc.desc_audio_batch import DescAudioBatch
from utils.desc.desc_scene_batch import DescSceneBatch
from utils.desc.desc_speaker_batch import DescSpeakerBatch
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.comm.log import logger


def _open_file(file_name, mode):
    try:
        if file_name == "-" and mode == "rt":
            text_file = sys.stdin
        elif file_name == "-" and mode == "wt":
            text_file = sys.stdout
        else:
            text_file = open(file_name, mode, encoding="utf-8")
        return text_file
    except Exception as excp:
        logger.error(excp)
        return


def _close_file(text_file):
    try:
        text_file.close()
    except Exception as excp:
        logger.error(excp)


def _line_to_json(json_line):
    try:
        line_json = json.loads(json_line)
        return line_json
    except Exception as excp:
        logger.error(f"{json_line}")
        return


def _json_to_line(line_json):
    try:
        json_line = json.dumps(line_json, ensure_ascii=False)
        return json_line
    except Exception as excp:
        logger.error(f"{line_json}")
        return


# read in a file as list
# return: list of lines from the file (if it exists)
def read_list_file(list_path) -> Optional[List]:
    if not list_path:
        return
    list_file = _open_file(list_path, 'rt')
    if not list_file:
        logger.error(f"{list_path} open failed")
        return
    list_lines = list(filter(None, list_file.read().splitlines()))
    if not list_lines:
        logger.error(f"{list_path} is empty")
        return
    _close_file(list_file)
    return list_lines


# write input list into list file at given path
# return: none
def write_list_file(list_lines, list_path) -> None:
    if not list_lines:
        logger.error(f"list_lines is None")
        return
    list_file = _open_file(list_path, 'wt')
    if not list_file:
        logger.error(f"{list_path} open failed")
        return
    write_lines = [f"{line}\n" for line in list_lines if line]
    list_file.writelines(write_lines)
    _close_file(list_file)
    return


def append_list_file(list_lines, list_path) -> None:
    if not list_lines:
        logger.error(f"list_lines is None")
        return
    list_file = _open_file(list_path, 'at')
    if not list_file:
        logger.error(f"{list_path} open failed")
        return
    write_lines = [f"{line}\n" for line in list_lines if line]
    list_file.writelines(write_lines)
    _close_file(list_file)
    return


# read in a file as dict, in which each line is: key val
# return: a dict
def read_dict_file(dict_path, delimiter='\t') -> Optional[Dict]:
    dict_lines = read_list_file(dict_path)
    if not dict_lines:
        return
    read_dict = {}
    for dict_line in dict_lines:
        line_split = dict_line.split(delimiter)
        if len(line_split) != 2:
            logger.error(f"{dict_line} is invalid")
            return
        key = line_split[0].strip()
        val = line_split[1].strip()
        if key in read_dict:
            logger.error(f"{key} already exist")
            return
        read_dict[key] = val
    return read_dict


# write input dict into file at input path in the format of 'key val'
# return: none
def write_dict_file(write_dict, dict_path, delimiter='\t') -> None:
    if not write_dict:
        logger.error(f"write_dict is None")
        return
    dict_lines = [f"{key}{delimiter}{val}" for key, val in write_dict.items()]
    write_list_file(dict_lines, dict_path)
    return


def read_json_file(json_path) -> Optional[List]:
    json_lines = read_list_file(json_path)
    if not json_lines:
        return
    json_list = [_line_to_json(line) for line in json_lines]
    json_list = list(filter(None, json_list))
    return json_list


def write_json_file(json_list, json_path) -> None:
    if not json_list:
        logger.error(f"json_list is None")
        return
    json_lines = [_json_to_line(json) for json in json_list]
    json_lines = list(filter(None, json_lines))
    write_list_file(json_lines, json_path)
    return


def read_desc_file(desc_path, desc_type="batch") -> Optional[Any]:
    if "batch" == desc_type:
        desc_obj = DescBatch()
    elif "audio" == desc_type:
        desc_obj = DescAudioBatch()
    elif "scene" == desc_type:
        desc_obj = DescSceneBatch()
    elif "speaker" == desc_type:
        desc_obj = DescSpeakerBatch()
    elif "sentence" == desc_type:
        desc_obj = DescSentenceBatch()
    else:
        logger.error(f"desc_type is invalid")
        return

    json_list = read_json_file(desc_path)
    if not json_list:
        return
    if not desc_obj.set_batch_json_list(json_list):
        logger.error(f"{desc_path} set desc failed")
        return
    return desc_obj


def write_desc_file(desc_obj, desc_path) -> None:
    if not desc_obj:
        logger.error(f"desc_obj is None")
        return
    json_list = desc_obj.get_batch_json_list()
    if not json_list:
        logger.error(f"get json failed")
        return
    write_json_file(json_list, desc_path)


def get_wav_len(wav_path) -> None:
    wav_len_ms = 0
    with wave.open(wav_path, 'rb') as wave_file:
        wav_chls, wav_width, wav_rate, wav_nfrm, _, _ = wave_file.getparams()
        wav_len_ms = int(wav_nfrm / wav_rate * 1000)
        if not wav_len_ms:
            logger.error(f"{wav_path} is empty.")
        return wav_len_ms
