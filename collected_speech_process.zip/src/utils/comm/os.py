#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import os
import shutil
import subprocess
from utils.comm.log import logger


class OSCmd:

    @staticmethod
    def sys_exec(cmd):
        logger.info(f"Exec [{cmd}]")
        os.system(cmd)

    @staticmethod
    def sub_exec(cmd):
        logger.info(f"Exec [{cmd}]")
        process = subprocess.run(cmd, stdout=subprocess.PIPE,
                                 shell=True, env=os.environ)
        return process


class OSFile:

    @staticmethod
    def check_file(path):
        if not os.path.isfile(path):
            return False
        if os.path.getsize(path) == 0:
            return False
        return True

    @staticmethod
    def base_name(path):
        return os.path.basename(path)

    @staticmethod
    def name_prefix(path):
        return os.path.splitext(os.path.basename(path))[0]

    @staticmethod
    def name_suffix(path):
        return os.path.splitext(os.path.basename(path))[1]

    @staticmethod
    def join_path(pfx_dir, sfx_name):
        return os.path.join(pfx_dir, sfx_name)

    @staticmethod
    def remove_file(path):
        if os.path.isfile(path):
            os.remove(path)

    @staticmethod
    def isabs(path):
        return os.path.isabs(path)

    @staticmethod
    def file_name(path):
        return os.path.splitext(os.path.basename(path))[0].split('/')[-1]

    @staticmethod
    def rename(src_path, dst_path):
        os.rename(src_path, dst_path)


class OSDir:

    @staticmethod
    def check_dir(path):
        return os.path.isdir(path)

    @staticmethod
    def dir_name(path):
        return os.path.dirname(path)

    @staticmethod
    def remove_dir(path):
        if os.path.isdir(path):
            shutil.rmtree(path)

    @staticmethod
    def init_dir(path):
        if os.path.isdir(path):
            shutil.rmtree(path)
        os.makedirs(path)

    @staticmethod
    def sub_dirs(path):
        if not os.path.isdir(path):
            logger.error(f"{path} does not exist.")
            return
        return sorted([fdr for fdr in os.listdir(path)
                       if os.path.isdir(os.path.join(path, fdr))])

    @staticmethod
    def sub_files(path):
        if not os.path.isdir(path):
            logger.error(f"{path} does not exist.")
            return
        return sorted([fn for fn in os.listdir(path)
                       if os.path.isfile(os.path.join(path, fn))])
