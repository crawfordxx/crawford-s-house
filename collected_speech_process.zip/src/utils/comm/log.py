#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
import logzero

# logger for process
fmt_msg = '[%(asctime)s %(filename)s,%(lineno)d,%(funcName)s ' \
    '%(levelname)s]: %(message)s'
date_msg = '%m-%d %H:%M:%S'
formatter = logging.Formatter(fmt=fmt_msg, datefmt=date_msg)
logger = logzero.setup_logger(name='logger', formatter=formatter,
                              level=logging.WARNING)

# ts_logger for data
ts_fmt_msg = '[%(asctime)s %(levelname)s]: %(message)s'
ts_formatter = logging.Formatter(fmt=ts_fmt_msg, datefmt=date_msg)
ts_logger = logzero.setup_logger(name='ts_logger', formatter=ts_formatter,
                                 level=logging.INFO)
