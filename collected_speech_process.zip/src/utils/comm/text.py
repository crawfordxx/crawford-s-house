#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import re

non_stops = (
    # Fullwidth ASCII variants
    '\uFF02\uFF03\uFF04\uFF05\uFF06\uFF07\uFF08\uFF09\uFF0A\uFF0B\uFF0C\uFF0D'
    '\uFF0F\uFF1A\uFF1B\uFF1C\uFF1D\uFF1E\uFF20\uFF3B\uFF3C\uFF3D\uFF3E\uFF3F'
    '\uFF40\uFF5B\uFF5C\uFF5D\uFF5E\uFF5F\uFF60'
    # Halfwidth CJK punctuation
    '\uFF62\uFF63\uFF64'
    # CJK symbols and punctuation
    '\u3000\u3001\u3003'
    # CJK angle and corner brackets
    '\u3008\u3009\u300A\u300B\u300C\u300D\u300E\u300F\u3010\u3011'
    # CJK brackets and symbols/punctuation
    '\u3014\u3015\u3016\u3017\u3018\u3019\u301A\u301B\u301C\u301D\u301E\u301F'
    # Other CJK symbols
    '\u3030'
    # Special CJK indicators
    '\u303E\u303F'
    # Dashes
    '\u2013\u2014'
    # Quotation marks and apostrophe
    '\u2018\u2019\u201B\u201C\u201D\u201E\u201F'
    # General punctuation
    '\u2026\u2027'
    # Overscores and underscores
    '\uFE4F'
    # Small form variants
    '\uFE51\uFE54'
    # Latin punctuation
    '\u00B7'
)

#: A string of Chinese stops.
stops = (
    '\uFF01'  # Fullwidth exclamation mark
    '\uFF1F'  # Fullwidth question mark
    '\uFF61'  # Halfwidth ideographic full stop
    '\u3002'  # Ideographic full stop
)


def str2single_byte(text):
    """字符串转半角"""
    new_text = ""
    for s in text:
        s_code = ord(s)
        if s_code == 12288:
            s_code = 32
        elif (s_code >= 65281 and s_code <= 65374):
            s_code -= 65248
        new_text += chr(s_code)
    return new_text


def str2double_byte(text):
    """字符串转全角"""
    new_text = ""
    for s in text:
        s_code = ord(s)
        if s_code == 32:
            s_code = 12288
        elif s_code >= 32 and s_code <= 126:
            s_code += 65248
        new_text += chr(s_code)
    return new_text


def remove_punctuation(text):
    if not text:
        return
    # A string containing all Chinese punctuation.
    punctuation = non_stops + stops
    new_text = re.sub(f"[{punctuation}]", "", text)
    return new_text


def has_digital(text: str):
    """check digital"""
    return re.search('[0-9]', text)


def text_lower(text):
    if not text:
        return
    new_text = ""
    for i, char in enumerate(text):
        if i != 0 and text[i - 1] == "[" and text[i + 1] == "]":
            new_text += char.upper()
        else:
            new_text += char.lower()
    return new_text


# flag: [.]
# B: 背景人声
# T： TTS
# M：背景音乐声
# N： 非人声噪声
# V： 人声非语言噪声
# S:  静音S
# G: 半音

def fix_error_flag(text):
    flags = list("BTMNVSG")
    index, new_text = 0, ""
    while index < len(text):
        char = text[index]
        if char == "[" or char == "【":
            cur_flag = text[index + 1].upper()
            if index + 3 <= len(text):
                flag_right = text[index + 2].replace("】", "]")
            else:
                flag_right = ""
            if cur_flag in flags and flag_right == "]":
                new_text += char.replace("【", "[") + cur_flag + flag_right
                index += 3
                continue
            elif cur_flag in flags and flag_right != "]":
                new_text += char.replace("【", "[") + cur_flag + "]"
                index += 2
                continue
            else:
                index += 1
                continue
        elif char == "]" or char == "】":
            cur_flag = text[index - 1].upper()
            if cur_flag in flags:
                new_text += "[" + cur_flag + char.replace("】", "]")
                index += 2
                continue
            else:
                index += 1
                continue
        else:
            index += 1
            new_text += char
    return new_text


def fix_space_character_loop(text):
    new_text = text
    for index, char in enumerate(new_text):
        char = char.encode('utf-8')
        if index == len(text) - 1:
            return new_text

        # 1、英文+ [
        if char.isalpha() and text[index + 1] == "[":
            new_text = new_text[:index + 1] + " " + new_text[index + 1:]
            return new_text
        # 2、英文 + 中文
        elif char.isalpha() and re.search(u"[\u4e00-\u9fa5]",
                                          text[index + 1]):
            new_text = new_text[:index + 1] + " " + new_text[index + 1:]
            return new_text

        # 3、] + 英文
        if index != 0 and char.isalpha() and text[index - 1] == "]":
            new_text = new_text[:index] + " " + new_text[index:]
            return new_text
        # 4、中文 + 英文
        elif index != 0 and char.isalpha() and re.search(u"[\u4e00-\u9fa5]",
                                                         text[index - 1]):
            new_text = new_text[:index] + " " + new_text[index:]
            return new_text


def fix_space_character(text):
    if not text:
        return
    new_text = text
    while True:
        tmp_text = fix_space_character_loop(new_text)
        if tmp_text == new_text:
            return new_text
        new_text = tmp_text


def preprocess(text):
    text = text.strip()
    if not text:
        return
    if has_digital(text):
        return
    text = fix_error_flag(text)
    text = text_lower(text)
    text = remove_punctuation(text)
    text = str2single_byte(text)
    text = fix_space_character(text)
    return text


def process_one_text(text):
    try:
        return preprocess(text)
    except:
        return


# def process_text_list(text_list: List[str]) -> List:
#     output_text_list = []
#     for text in text_list:
#         new_text = preprocess(text)
#         output_text_list.append(new_text)
#     return output_text_list


def test_1():
    text = "sa[N][s][a第三款【N】nihao[M【M】\n"
    print(f"source_name: {text}")
    print(f"fix_name: {preprocess(text)}")


def test_2():
    text = "s小米K[n]a[S]b[n"
    print(f"source_name: {text}")
    print(f"fix_name: {preprocess(text)}")


def test_3():
    text = "\n"
    print(f"source_name: {text}")
    print(f"fix_name: {preprocess(text)}")


if __name__ == '__main__':
    print("test_1")
    test_1()
    print("test_2")
    test_2()
    print("test_3")
    test_3()
