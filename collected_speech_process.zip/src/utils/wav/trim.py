#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import copy
from pydub import AudioSegment
from utils.desc.desc_batch import DescBatch
from utils.comm.log import logger


def _trim_wav_with_item(split_desc_item, trim_wav_dir):
    if not split_desc_item.sentence_item_list:
        logger.error(f"sentence_item_list is None")
        return
    desc_item = copy.deepcopy(split_desc_item)

    split_wav_path = split_desc_item.basic_item.basic_data.wav_path
    split_wav_data = AudioSegment.from_wav(split_wav_path)
    trim_wav_data = AudioSegment.empty()

    snt_text, duration = "", 0
    for snt_idx in range(len(desc_item.sentence_item_list)):
        snt_data = desc_item.sentence_item_list[snt_idx].sentence_data
        snt_text += snt_data.text
        duration += round(snt_data.vad_end - snt_data.vad_beg, 3)
        vad_beg_ms = int(snt_data.vad_beg * 1000)
        vad_end_ms = int(snt_data.vad_end * 1000)
        trim_wav_data += split_wav_data[vad_beg_ms:vad_end_ms]

    wav_name = desc_item.basic_item.basic_data.wav_name
    wav_path = f"{trim_wav_dir}/{wav_name}.wav"
    trim_wav_data.export(wav_path, format="wav")

    snt_item = desc_item.sentence_item_list[0]
    snt_data = snt_item.sentence_data
    snt_data.text, snt_data.vad_beg, snt_data.vad_end = snt_text, None, None
    desc_item.sentence_item_list = [snt_item]
    desc_item.basic_item.basic_data.wav_path = wav_path
    desc_item.audio_item.audio_data.duration = duration

    return desc_item


def trim_wav_with_desc(split_desc_batch, trim_wav_dir):
    if not split_desc_batch or not trim_wav_dir:
        logger.error(f"split_desc_batch or trim_wav_dir is None")
        return

    split_desc_dict = split_desc_batch.batch_dict
    if not split_desc_dict:
        logger.error(f"split_desc_dict is None")
        return

    trim_desc_dict = {}
    for split_wav_name, split_desc_item in split_desc_dict.items():
        trim_desc_item = _trim_wav_with_item(split_desc_item, trim_wav_dir)
        if not trim_desc_item:
            logger.error(f"{split_wav_name} trim failed")
            continue
        trim_desc_dict[split_wav_name] = trim_desc_item

    if not trim_desc_dict:
        logger.error(f"trim_desc_dict is empty")
        return

    trim_desc_batch = DescBatch()
    trim_desc_batch.batch_dict = trim_desc_dict

    return trim_desc_batch
