#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import copy
from pydub import AudioSegment
from utils.desc.desc_batch import DescBatch
from utils.comm.log import logger


def _get_border(desc_item, snt_idx):
    snt_item_list = desc_item.sentence_item_list
    sentence_num = len(desc_item.sentence_item_list)
    wav_duration = desc_item.audio_item.audio_data.duration

    if snt_idx == 0:
        left_border = 0
    else:
        left_border = snt_item_list[snt_idx - 1].sentence_data.vad_end
    if snt_idx == sentence_num - 1:
        right_border = wav_duration
    else:
        right_border = snt_item_list[snt_idx + 1].sentence_data.vad_beg

    return left_border, right_border


def _get_split_pos(desc_item, snt_idx, spread_sec):
    snt_data = desc_item.sentence_item_list[snt_idx].sentence_data
    vad_beg, vad_end = snt_data.vad_beg, snt_data.vad_end
    left_border, right_border = _get_border(desc_item, snt_idx)

    if vad_beg - spread_sec > left_border:
        split_beg = round(vad_beg - spread_sec, 3)
    else:
        split_beg = left_border

    if vad_end + spread_sec < right_border:
        split_end = round(vad_end + spread_sec, 3)
    else:
        split_end = right_border

    return split_beg, split_end


def _split_snt_desc_item(concat_desc_item, split_wav_dir, snt_idx, spread_sec):
    desc_item = copy.deepcopy(concat_desc_item)

    # sentence
    snt_item = desc_item.sentence_item_list[snt_idx]
    snt_data = snt_item.sentence_data
    desc_item.sentence_item_list = [snt_item]

    # other
    basic_data = desc_item.basic_item.basic_data
    if snt_data.source:
        wav_mic = basic_data.wav_name.split('_')[-1]
        if "mic" != wav_mic[:3]:
            logger.error(f"{basic_data.wav_name} wav_name is invalid")
            return
        wav_name = f"{snt_data.source}_{wav_mic}"
    else:
        wav_name = f"{basic_data.wav_name}_{snt_idx+1:03d}"
    basic_data.wav_name = wav_name
    basic_data.wav_path = f"{split_wav_dir}/{wav_name}.wav"
    basic_data.uttid = f"{basic_data.batch}-{wav_name}"
    if not spread_sec:
        split_beg, split_end = snt_data.vad_beg, snt_data.vad_end
        snt_data.vad_beg, snt_data.vad_end = None, None
    else:
        split_beg, split_end = _get_split_pos(concat_desc_item,
                                              snt_idx, spread_sec)
        snt_data.vad_beg = round(snt_data.vad_beg - split_beg, 3)
        snt_data.vad_end = round(snt_data.vad_end - split_beg, 3)
    desc_item.audio_item.audio_data.duration = round(split_end - split_beg, 3)

    # args
    concat_wav_path = concat_desc_item.basic_item.basic_data.wav_path
    args_item = [basic_data.wav_path, concat_wav_path, split_beg, split_end]

    return desc_item, args_item


def _split_snt_with_desc(concat_desc_dict, split_wav_dir, spread_sec):
    if not concat_desc_dict:
        logger.error(f"concat_desc_dict is None")
        return

    split_desc_dict, split_args_list = {}, []
    for concat_wav_name, concat_desc_item in concat_desc_dict.items():
        sentence_item_list = concat_desc_item.sentence_item_list
        if not sentence_item_list:
            logger.error(f"{wav_name} sentence is None")
            continue
        snt_num = len(sentence_item_list)
        for snt_idx in range(snt_num):
            split_desc_item, split_args_item = _split_snt_desc_item(
                concat_desc_item, split_wav_dir, snt_idx, spread_sec)
            split_wav_name = split_desc_item.basic_item.basic_data.wav_name
            split_desc_dict[split_wav_name] = split_desc_item
            split_args_list.append(split_args_item)

    return split_desc_dict, split_args_list


def _split_wav_with_args(split_args_list):
    split_args_lines = []
    for split_args in split_args_list:
        if len(split_args) != 4:
            logger.error(f"{split_args} length is invalid")
            continue
        split_wav_path, concat_wav_path, \
            vad_beg_sec, vad_end_sec = tuple(split_args)
        vad_beg_ms = int(vad_beg_sec * 1000)
        vad_end_ms = int(vad_end_sec * 1000)
        concat_wav_data = AudioSegment.from_wav(concat_wav_path)
        split_wav_data = concat_wav_data[vad_beg_ms:vad_end_ms]
        split_wav_data.export(split_wav_path, format="wav")
        split_args_line = f"{split_wav_path} {concat_wav_path} " \
            f"{vad_beg_sec} {vad_end_sec}"
        split_args_lines.append(split_args_line)
    return split_args_lines


def split_wav_with_desc(concat_desc_batch, split_wav_dir, spread_sec):
    if not concat_desc_batch or not split_wav_dir:
        logger.error(f"concat_desc_batch or split_wav_dir is None")
        return

    concat_desc_dict = concat_desc_batch.batch_dict
    split_desc_dict, split_args_list = \
        _split_snt_with_desc(concat_desc_dict, split_wav_dir, spread_sec)
    if not split_desc_dict or not split_args_list:
        logger.error(f"split_desc_dict or split_args_list is empty")
        return

    split_desc_batch = DescBatch()
    split_desc_batch.batch_dict = split_desc_dict
    split_args_lines = _split_wav_with_args(split_args_list)

    return split_desc_batch, split_args_lines
