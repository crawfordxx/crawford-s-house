#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pydub import AudioSegment
from utils.desc.desc_audio_batch import DescAudioBatch
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.desc.desc_batch import DescBatch
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


class WavItem():

    def __init__(self, wav_name, duration, wav_path=None):
        self.wav_name = wav_name
        self.duration = int(1000*duration)
        self.wav_path = wav_path
        self.wav_data = None

    def set_wav_data(self) -> bool:
        if self.wav_data:
            logger.info(f"{self.wav_name} wav_data already exist")
            return True
        if self.wav_path:
            wav_data = AudioSegment.from_wav(self.wav_path)
            self.wav_data = wav_data[0:self.duration]
            return True
        else:
            logger.error(f"{self.wav_name} wav_path is None")
            return False

    def get_wav_data(self):
        if self.wav_data:
            return self.wav_data
        elif self.wav_path:
            wav_data = AudioSegment.from_wav(self.wav_path)
            return wav_data[0:self.duration]
        else:
            logger.error(f"{self.wav_name} wav_data is None")
            return


class WavSil(WavItem):

    def set_wav_data(self, fmt) -> bool:
        rate, bits, chls = fmt.rate, fmt.bits, fmt.chls
        if self.wav_data:
            logger.info(f"{self.wav_name} wav_data already exist")
            return True
        if bits not in [16, 32]:
            logger.error(f"{self.wav_name} bits {bits} is invalid")
            return False
        if chls not in [1, 2]:
            logger.error(f"{self.wav_name} chls {chls} is invalid")
            return False
        wav_data = AudioSegment.silent(self.duration, rate)
        if bits == 32:
            wav_16bit = wav_data
            wav_data = wav_16bit.set_sample_width(bits//8)
        if chls == 2:
            wav_mono = wav_data
            wav_data = wav_mono.set_channels(chls)
        self.wav_data = wav_data


class WavConcat():

    """
    ## concat head ##
    [tip_sil - tip_wav] - [head_sil]

    ## concat body and max duration ##
    [[wkp_wav - [wkp_sil]] - [qry_wav - [qry_sil]]] -
    [[wkp_wav - [wkp_sil]] - [qry_wav - [qry_sil]]] -
    ......

    ## concat tail ##
    [tail_sil] - [tip_wav - tip_sil]
    """

    def __init__(self):

        # check
        self.wav_format_ = None
        self.src_desc_dict = None

        # strategy
        self.head_wav_list = []
        self.tail_wav_list = []
        self.body_wav_list = []
        self.min_duration = 10000
        self.max_duration = float('inf')
        self.wav_chunk_list = []

        # wav
        self.wav_chunk_dict = {}
        self.wav_path_list = []

        # desc
        self.sil_name_list = ["head_sil", "tail_sil",
                              "tip_sil", "wkp_sil", "qry_sil"]
        self.snt_json_list = []
        self.wav_desc_batch = {}

    """
    CONCAT CHECK
    1. check_wav_format
    2. merge_src_desc
    """

    # merge src desc item
    def merge_src_desc(self, tip_desc_item, wkp_desc_item, qry_desc_dict):
        src_desc_dict = {}
        src_desc_dict.update(qry_desc_dict)
        if tip_desc_item:
            wav_name = tip_desc_item.basic_item.basic_data.wav_name
            src_desc_dict[wav_name] = tip_desc_item
        if wkp_desc_item:
            wav_name = wkp_desc_item.basic_item.basic_data.wav_name
            src_desc_dict[wav_name] = wkp_desc_item
        self.src_desc_dict = src_desc_dict
        return True

    def check_wav_format(self) -> bool:
        wav_fmt = None
        for wav_name, desc_item in self.src_desc_dict.items():
            cur_fmt = desc_item.audio_item.audio_data.format_
            if not wav_fmt:
                wav_fmt = cur_fmt
                continue
            if cur_fmt.rate != wav_fmt.rate:
                logger.error(f"{wav_name} audio rate {cur_fmt.rate}")
                return False
            if cur_fmt.bits != wav_fmt.bits:
                logger.error(f"{wav_name} audio bits {cur_fmt.bits}")
                return False
            if cur_fmt.chls != wav_fmt.chls:
                logger.error(f"{wav_name} audio chls {cur_fmt.chls}")
                return False
        self.wav_format_ = wav_fmt
        return True

    """
    CONCAT STRATEGY
    1. set head and tail wav list
    2. set body wav list
    3. set body max duration
    4. cut body wav list to chunks
    5. pad head and tail to chunks
    """

    def _get_desc_wav(self, desc_item):
        if not desc_item:
            return None
        wav_name = desc_item.basic_item.basic_data.wav_name
        wav_path = desc_item.basic_item.basic_data.wav_path
        duration = desc_item.audio_item.audio_data.duration
        return WavItem(wav_name, duration, wav_path)

    def _get_sil_wav(self, wav_name, wav_sec):
        if not wav_sec:
            return None
        wav_sil = WavSil(wav_name, wav_sec)
        wav_sil.set_wav_data(self.wav_format_)
        return wav_sil

    # set head and tail wav list
    def set_head_tail(self, tip_desc_item, tip_sec=0,
                      head_sec=0, tail_sec=0):
        if not tip_desc_item:
            tip_sec = 0

        tip_wav = self._get_desc_wav(tip_desc_item)
        tip_sil = self._get_sil_wav("tip_sil", tip_sec)
        head_sil = self._get_sil_wav("head_sil", head_sec)
        tail_sil = self._get_sil_wav("tail_sil", tail_sec)

        wav_list = [tip_sil, tip_wav, head_sil]
        head_list = list(filter(None, wav_list))
        wav_list = [tail_sil, tip_wav, tip_sil]
        tail_list = list(filter(None, wav_list))

        self.head_wav_list = head_list
        self.tail_wav_list = tail_list
        return

    # set body wav list
    def set_body_list(self, qry_desc_dict, qry_sec=0,
                      wkp_desc_item=None, wkp_sec=0):
        if not wkp_desc_item:
            wkp_sec = 0

        wkp_wav = self._get_desc_wav(wkp_desc_item)
        wkp_sil = self._get_sil_wav("wkp_sil", wkp_sec)
        qry_sil = self._get_sil_wav("qry_sil", qry_sec)

        body_list = []
        for qry_desc_item in qry_desc_dict.values():
            qry_wav = self._get_desc_wav(qry_desc_item)
            wav_list = [wkp_wav, wkp_sil, qry_wav, qry_sil]
            body_wavs = list(filter(None, wav_list))
            body_list.append(body_wavs)

        self.body_wav_list = body_list
        return

    # set body wav with wkp sil distribution
    def set_body_with_wkp_sil_dist(self, qry_desc_dict, qry_sec,
                                   wkp_desc_item, wkp_sec_dist):
        if not (qry_desc_dict and qry_sec and
                wkp_desc_item and wkp_sec_dist):
            logger.error(f"arguments is None")
            return

        wkp_wav = self._get_desc_wav(wkp_desc_item)
        qry_sil = self._get_sil_wav("qry_sil", qry_sec)

        # wkp sil
        wkp_sec_list, wkp_sil_dict = [], {}
        for wkp_sec, dist_rate in wkp_sec_dist:
            wkp_sec_num = round(len(qry_desc_dict) * dist_rate / 100)
            wkp_sec_list.extend([wkp_sec] * wkp_sec_num)
            wkp_sil_dict[wkp_sec] = self._get_sil_wav("wkp_sil", wkp_sec)
        if len(wkp_sec_list) != len(qry_desc_dict):
            logger.error(f"{len(wkp_sec_list)} and {len(qry_desc_dict)}")
            return
        tuple_list = zip(wkp_sec_list, qry_desc_dict.values())

        # body list
        body_list = []
        for wkp_sec, qry_desc_item in tuple_list:
            wkp_sil = wkp_sil_dict[wkp_sec]
            qry_wav = self._get_desc_wav(qry_desc_item)
            wav_list = [wkp_wav, wkp_sil, qry_wav, qry_sil]
            body_wavs = list(filter(None, wav_list))
            body_list.append(body_wavs)

        self.body_wav_list = body_list
        return

    # set body max_duration
    def set_max_duration(self, max_duration) -> bool:
        if not max_duration:
            return True
        max_duration = int(max_duration * 1000)
        wav_list = self.head_wav_list + self.tail_wav_list
        duration = sum([item.duration for item in wav_list])
        max_duration -= duration
        if max_duration < self.min_duration:
            logger.error(f"max_duration {max_duration} is too small")
            return False
        else:
            self.max_duration = max_duration
            return True

    # cut body wav list to chunks
    def _cut_body_to_chunks(self):
        chunk_list = []
        chunk_item = []
        chunk_duration = 0
        for body_wavs in self.body_wav_list:
            duration = sum([item.duration for item in body_wavs])
            if chunk_duration + duration <= self.max_duration:
                chunk_item.extend(body_wavs)
                chunk_duration += duration
            else:
                chunk_list.append(chunk_item)
                chunk_item = body_wavs
                chunk_duration = duration
        chunk_list.append(chunk_item)
        self.wav_chunk_list = chunk_list
        return

    # pad head and tail to chunks
    def _pad_ends_to_chunks(self):
        for wav_chunk in self.wav_chunk_list:
            wav_chunk[0:0] = self.head_wav_list
            wav_chunk.extend(self.tail_wav_list)
        return

    def set_wav_chunk(self):
        self._cut_body_to_chunks()
        self._pad_ends_to_chunks()
        return

    """
    CONCAT WAV
    1. set concat name to wav chunk dict
    2. concat wav data to specific directory
    """

    def set_concat_name(self, name_pfx="", sfx_len=0):
        wav_chunk_list = self.wav_chunk_list
        chunk_num = len(wav_chunk_list)
        num_len = len(str(chunk_num))
        if num_len > sfx_len:
            sfx_len = num_len
        wav_chunk_dict = {}
        if chunk_num == 1 and name_pfx:
            wav_chunk_dict[name_pfx] = wav_chunk_list[0]
        else:
            if name_pfx:
                name_pfx += "_"
            for wav_index in range(len(wav_chunk_list)):
                name_sfx = f"{wav_index+1:0{sfx_len}d}"
                wav_name = f"{name_pfx}{name_sfx}"
                wav_chunk_dict[wav_name] = wav_chunk_list[wav_index]
        self.wav_chunk_dict = wav_chunk_dict
        return

    def concat_wav_data(self, wav_dir):
        wav_path_list = []
        for wav_name, wav_chunk in self.wav_chunk_dict.items():
            wav_path = f"{wav_dir}/{wav_name}.wav"
            wav_data = AudioSegment.empty()
            for wav_item in wav_chunk:
                wav_data += wav_item.get_wav_data()
            wav_data.export(wav_path, format='wav')
            wav_path_list.append(wav_path)
        self.wav_path_list = wav_path_list
        return

    """
    CONCAT DESC
    1. concat sentence json list from wav chunk dict
    2. concat desc batch from audio and sentence
    """

    def _wav_item_snt(self, wav_item, concat_name, concat_duration):
        wav_name = wav_item.wav_name
        duration = wav_item.duration
        if wav_name in self.sil_name_list:
            return duration, None
        src_item = self.src_desc_dict[wav_name]
        source = src_item.basic_item.basic_data.wav_name
        vad_beg = round(concat_duration/1000, 3)
        vad_end = round((concat_duration+duration)/1000, 3)
        src_snt_list = src_item.sentence_item_list
        if not src_snt_list or len(src_snt_list) != 1:
            text = None
        else:
            text = src_snt_list[0].sentence_data.text
        snt_json = {
            "wav_name": concat_name,
            "sentence": {
                "source": source,
                "vad_beg": vad_beg,
                "vad_end": vad_end,
                "text": text
            }
        }
        return duration, snt_json

    def concat_wav_snt(self):
        snt_json_list = []
        for concat_name, wav_chunk in self.wav_chunk_dict.items():
            concat_duration = 0
            for wav_item in wav_chunk:
                duration, snt_json = self._wav_item_snt(wav_item, concat_name,
                                                        concat_duration)
                concat_duration += duration
                if snt_json:
                    snt_json_list.append(snt_json)
        self.snt_json_list = snt_json_list
        return

    def concat_wav_desc(self, concat_batch, concat_desc_path) -> bool:
        audio_batch = DescAudioBatch()
        audio_batch.set_audio_batch(concat_batch, self.wav_path_list,
                                    None, None, False)
        sentence_batch = DescSentenceBatch()
        sentence_batch.set_sentence_batch(self.snt_json_list)
        desc_batch = DescBatch()
        desc_batch.set_batch(audio_batch, None, None, sentence_batch)
        write_desc_file(desc_batch, concat_desc_path)
        return

    """
    CONCAT STATIONARY NOISE
    """

    """
    CONCAT NONSTATIONARY NOISE
    """
