#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pydub import AudioSegment
from utils.comm.os import OSCmd
from utils.comm.os import OSFile
from utils.desc.desc_batch_item import DescBatchItem
from utils.desc.desc_basic_item import DescBasicItem
from utils.desc.desc_audio_item import DescAudioItem
from utils.comm.log import logger


class WavSync:

    def __init__(self, desc_item, dev_mic, record_wav_dir,
                 record_mono_dir, sync_wav_dir, sync_thres, tip_sil_sec):
        self.desc_item = desc_item
        self.dev_mic = dev_mic
        self.record_wav_dir = record_wav_dir
        self.record_mono_dir = record_mono_dir
        self.sync_wav_dir = sync_wav_dir
        self.record_wav_path = None
        self.record_mono_path = None
        self.sync_wav_path = None
        self.audio_beg = None
        self.audio_end = None
        self.sync_thres = sync_thres
        self.tip_sil_sec = tip_sil_sec

    def check_exist(self) -> bool:
        scid = ""
        if self.dev_mic.scene:
            scid = self.dev_mic.scene.scene_data.scid + "_"
        concat_wav_name = self.desc_item.basic_item.basic_data.wav_name
        record_wav_name = f"{concat_wav_name}_{scid}{self.dev_mic.index}"
        self.record_wav_path = f"{self.record_wav_dir}/{record_wav_name}.wav"
        self.record_mono_path = f"{self.record_mono_dir}/{record_wav_name}.wav"
        self.sync_wav_path = f"{self.sync_wav_dir}/{record_wav_name}.wav"
        if not OSFile.check_file(self.record_wav_path):
            logger.error(f"{self.record_wav_path} isn't exist")
            return False
        return True

    def detect_tips(self):
        # sox mono
        sox_cmd = f"sox {self.record_wav_path} {self.record_mono_path}" \
                  f" remix 1 highpass 500 norm -3"
        OSCmd.sub_exec(sox_cmd)
        # detect_tips
        detect_dir = "$CSP_PRJ_ROOT/tools/detect_tips"
        detect_cmd = f"{detect_dir}/detect_tips {detect_dir}/tip.wav " \
            f"{self.record_mono_path}"
        detect_res = OSCmd.sub_exec(detect_cmd).stdout
        # check result
        if not detect_res:
            logger.error(f"{self.record_wav_path} detect tips failed")
            return False
        detect_res = detect_res.decode('utf-8').strip().split('\t')
        if len(detect_res) != 3:
            logger.error(f"{self.record_wav_path} detect more or less tips")
            return False
        self.audio_beg = float(detect_res[1])
        self.audio_end = float(detect_res[2]) + 1
        return True

    def check_sync(self) -> bool:
        concat_duration = self.desc_item.audio_item.audio_data.duration
        concat_wav_path = self.desc_item.basic_item.basic_data.wav_path
        sync_duration = self.audio_end - self.audio_beg + 2*self.tip_sil_sec
        duration_diff = sync_duration - concat_duration
        if abs(duration_diff) > self.sync_thres:
            logger.error(f"{self.record_wav_path} is different from "
                         f"{concat_wav_path} with {duration_diff} second "
                         f"while duration threshold is {self.sync_thres}")
            return False
        return True

    def trim_wav_data(self):
        wav_data = AudioSegment.from_wav(self.record_wav_path)
        trim_beg = int(1000 * (self.audio_beg - self.tip_sil_sec))
        trim_end = int(1000 * (self.audio_end + self.tip_sil_sec))
        sync_wav_data = wav_data[trim_beg:trim_end]
        sync_wav_data.export(self.sync_wav_path, format='wav')

    def get_desc_item(self):
        # basic
        batch_name = self.desc_item.basic_item.basic_data.batch
        basic_item = DescBasicItem()
        basic_item.set_basic_item(batch_name, self.sync_wav_path)
        # audio
        hardware = self.dev_mic.audio.audio_data.hardware
        device = self.dev_mic.audio.audio_data.device
        audio_item = DescAudioItem()
        audio_item.set_audio_item(self.sync_wav_path, hardware, device)
        # desc
        sync_desc_item = DescBatchItem()
        sync_desc_item.set_batch_item(basic_item, audio_item,
                                      self.dev_mic.scene, None,
                                      self.desc_item.sentence_item_list)
        return sync_desc_item
