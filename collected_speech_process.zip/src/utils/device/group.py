#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from utils.comm.log import logger


class DeviceGroup:

    def __init__(self, mic_list):
        if not mic_list:
            logger.error(f"mic_list is None")
            return
        self.mic_list = mic_list

    def prepare_record(self) -> bool:
        for mic in self.mic_list:
            if not mic.device.prepare_record():
                logger.error(f"{mic.index} prepare record failed")
                return False
        return True

    def start_record(self) -> bool:
        for mic in self.mic_list:
            if not mic.device.start_record():
                logger.error(f"{mic.index} start record failed")
                return False
        return True

    def check_data(self) -> bool:
        for mic in self.mic_list:
            if not mic.device.check_data():
                logger.error(f"{mic.index} check data failed")
                return False
        return True

    def stop_record(self):
        for mic in self.mic_list:
            mic.device.stop_record()

    def pull_data(self, data_dir, spkid="", sntid=""):
        if spkid:
            spkid = spkid + "_"
        if sntid:
            sntid = sntid + "_"
        for mic in self.mic_list:
            scid = ""
            if mic.scene:
                scid = mic.scene.scene_data.scid + "_"
            wav_name = f"{spkid}{scid}{sntid}{mic.index}"
            pcm_path = f"{data_dir}/{wav_name}.pcm"
            wav_path = f"{data_dir}/{wav_name}.wav"
            mic.device.pull_data(pcm_path)
            mic.pcm_to_wav(pcm_path, wav_path)
