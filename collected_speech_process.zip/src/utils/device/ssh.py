#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
# import IPy
from utils.device.base import DeviceBase
from utils.comm.log import logger


class DeviceSsh(DeviceBase):

    def _check_device_json(self, device_json) -> bool:
        connect_index = device_json.get("connect_index")
        if not connect_index:
            logger.error(f"connect_index is None")
            return False
        connect_index_list = connect_index.split("@")
        if len(connect_index_list) != 2:
            logger.error(f"connect_index is invalid")
            return False
        # connect_index_ip = connect_index_list[1]
        # try:
        #     IPy.IP(connect_index_ip)
        # except Exception as e:
        #     logger.error(f"connect_index is invalid")
        #     return False
        save_flag = device_json.get("save_flag")
        if not (save_flag and os.path.isabs(save_flag)):
            logger.error(f"save_flag is invalid")
            return False
        save_path = device_json.get("save_path")
        if not (save_path and os.path.isabs(save_path)):
            logger.error(f"save_path is invalid")
            return False
        return True
