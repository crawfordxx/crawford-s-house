#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from utils.device.base import DeviceBase
from utils.comm.os import OSFile
from utils.comm.os import OSCmd
from utils.comm.log import logger


class DeviceAdb(DeviceBase):

    def _check_device_json(self, device_json) -> bool:
        connect_index = device_json.get("connect_index")
        if not connect_index:
            logger.error("connect_index is None")
            return False
        save_flag = device_json.get("save_flag")
        if not (save_flag and OSFile.isabs(save_flag)):
            logger.error("save_flag is invalid")
            return False
        save_path = device_json.get("save_path")
        if not (save_path and OSFile.isabs(save_path)):
            logger.error("save_path is invalid")
            return False
        return True

    def prepare_record(self) -> bool:
        device = self.device_data.connect_index
        device_cmd = "adb devices"
        device_out = OSCmd.sub_exec(device_cmd).stdout
        if not device_out:
            logger.error(f"adb devices failed")
            return False
        if device not in device_out.decode('utf-8'):
            logger.error(f"detect {device} reboot failed")
            return False
        root_cmd = f"adb -s {device} root"
        OSCmd.sub_exec(root_cmd)
        remount_cmd = f"adb -s {device} remount"
        OSCmd.sub_exec(remount_cmd)
        return True

    def start_record(self) -> bool:
        device = self.device_data.connect_index
        save_flag = self.device_data.save_flag
        touch_cmd = f"adb -s {device} shell touch {save_flag}"
        OSCmd.sub_exec(touch_cmd)
        ls_cmd = f"adb -s {device} shell ls -l {save_flag}"
        ls_out = OSCmd.sub_exec(ls_cmd).stdout
        if not ls_out:
            logger.error(f"touch {save_flag} failed")
            return False
        return True

    def check_data(self) -> bool:
        device = self.device_data.connect_index
        save_path = self.device_data.save_path
        ls_cmd = f"adb -s {device} shell ls -l {save_path}"
        ls_out = OSCmd.sub_exec(ls_cmd).stdout
        if not ls_out:
            logger.error(f"save {save_path} failed")
            return False
        file_size = ls_out.decode('utf-8').split(" ")[4]
        if not (file_size.isdigit() and int(file_size) > 0):
            logger.error(f"{save_path} size is invalid")
            return False
        return True

    def stop_record(self):
        device = self.device_data.connect_index
        save_flag = self.device_data.save_flag
        rm_cmd = f"adb -s {device} shell rm {save_flag}"
        OSCmd.sub_exec(rm_cmd)

    def pull_data(self, local_path):
        device = self.device_data.connect_index
        save_path = self.device_data.save_path
        pull_cmd = f"adb -s {device} pull {save_path} {local_path}"
        OSCmd.sub_exec(pull_cmd)
