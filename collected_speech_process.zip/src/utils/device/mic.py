#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pydub import AudioSegment
from typing import Dict, Optional
from utils.device.adb import DeviceAdb
from utils.device.ssh import DeviceSsh
from utils.device.usb import DeviceUsb
from utils.desc.desc_audio_item import DescAudioItem
from utils.desc.desc_scene_item import DescSceneItem
from utils.comm.log import logger


class DeviceMic:

    def __init__(self, mic_index):
        self.index = mic_index
        self.device = None
        self.audio = None
        self.scene = None

    def _set_audio(self, mic_json) -> bool:
        audio_json = mic_json.get("audio")
        if not audio_json:
            logger.error(f"{self.index} audio is None")
            return False
        audio_json["duration"] = 300
        audio_item = DescAudioItem()
        if not audio_item.set_audio_json(audio_json):
            logger.error(f"{self.index} set audio failed")
            return False
        self.audio = audio_item
        return True

    def _set_scene(self, mic_json) -> bool:
        scene_json = mic_json.get("scene")
        if not scene_json:
            return True
        scene = DescSceneItem()
        if not scene.set_scene_json(scene_json):
            logger.error(f"{self.index} set scene failed")
            return False
        self.scene = scene
        return True

    def _set_device(self, mic_json) -> bool:
        device_json = mic_json.get("device")
        if not device_json:
            logger.error(f"{self.index} device is None")
            return False
        connect_type = device_json.get("connect_type")
        if not connect_type:
            logger.error(f"{self.index} connect_type is None")
            return False
        if "adb" == connect_type:
            device = DeviceAdb()
        elif "usb" == connect_type:
            if not self.audio:
                logger.error(f"{self.index} must set audio first")
                return False
            device = DeviceUsb(self.audio.audio_data.format_)
        elif "ssh" == connect_type:
            device = DeviceSsh()
        else:
            logger.error(f"{self.index} connect_type is invalid")
            return False
        if not device.set_device_json(device_json):
            logger.error(f"{self.index} set device failed")
            return False
        self.device = device
        return True

    def set_json(self, mic_json) -> bool:
        if self.index[:3] != "mic":
            logger.error(f"{self.index} index is invalid")
            return False
        if not self._set_audio(mic_json):
            return False
        if not self._set_scene(mic_json):
            return False
        if not self._set_device(mic_json):
            return False
        return True

    def get_json(self) -> Optional[Dict]:
        mic_json = {}
        # device
        device_json = self.device.get_device_json()
        if not device_json:
            logger.error(f"{self.index} get_device_json failed")
            return
        mic_json["device"] = device_json
        # audio
        audio_json = self.audio.get_audio_json()
        if not audio_json:
            logger.error(f"{self.index} get_audio_json failed")
            return
        mic_json["audio"] = audio_json
        # scene
        if self.scene:
            scene_json = self.scene.get_scene_json()
            if not scene_json:
                logger.error(f"{self.index} get_scene_json failed")
                return
            mic_json["scene"] = scene_json
        # mic_json
        return mic_json

    def pcm_to_wav(self, pcm_path, wav_path):
        format_ = self.audio.audio_data.format_
        try:
            pcm_data = AudioSegment.from_file(pcm_path, format="pcm",
                                              frame_rate=format_.rate,
                                              channels=format_.chls,
                                              sample_width=format_.bits // 8)
            pcm_data.export(wav_path, format='wav')
        except Exception as exp:
            logger.error(exp)
            return
