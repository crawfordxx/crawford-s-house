## DeviceData
描述设备数据的类
### Field
- connect_type: str 
设备连接类型，adb就是嵌入式设备使用的安卓系统。目前支持的其他类型有 ssh usb

- connect_index: str
设备连接索引，配合连接类型需要的设备访问参数。adb就是设备号。

- save_flag: str
设备保存录音的标识文件，文件存在则保存音频，不存在则不保存音频

- save_path: str
设备保存录音的文件的绝对路径


## DeviceBase
处理设备数据的基本类
### Field
- device\_data: DeviceData
储存设备数据的对象

### \_check\_device\_json
检查设备配置文件的方法，会被其子类覆写
### set\_device\_json
使用输入的配置文件初始化device_data对象
### get\_device\_json
将设备数据输出为dict文件


## DeviceAdb
处理adb接口的音频输入
### \_check\_device\_json
检查设备对应的配置文件是否正确
检查配置文件中是否包含连接序号、录音标识文件和保存路径
### prepare_record
检查系统初始化是否成功
运行”adb devices”并检查返回结果是否正常，是则给与设备根权限，并进入写入模式；否则退出程序。
### start_record
开始录音
通过touch save\_flag (hrsc\_debug)文件（录音标识文件）确认录音开始，如果文件不存在则退出程序，存在则开始录音。
### check_data
检查录音是否成功
通过ls命令检查录音是否已被保存在指定路径。
### stop_record
停止录音
通过删除save\_flag (hrsc\_debug)录音标识文件停止录音。
### pull_data
拉取数据
用adb pull命令将数据存到本地文件夹


## DeviceSsh
处理ssh接口的音频输入
### \_check\_device\_json
检查设备对应的配置文件是否正确
检查配置文件中是否包含连接序号列表、连接IP是否正确、是否包含录音标识文件和保存路径


## DeviceUsb
处理usb接口的音频输入
### \_check\_device\_json
检查设备对应的配置文件是否正确
检查连接序号是否正确


## DeviceMic
### Field
- index 
麦克风序号
- device
设备对象，根据输入类型不同有DeviceAdb, DeviceUsb和DeviceSsh三类
- audio
文件音频信息
- scene
场景信息


## DeviceGroup
管理所有麦克风的类
### Field
- mic_list
麦克风列表

### prepare_record
检查所有麦克风系统初始化是否成功
### start_record
开始录音
### check_data
检查录音是否成功
### stop_record
停止录音
### pull_data
拉取数据


