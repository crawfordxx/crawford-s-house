#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio
pyaudio must to get from above url
other version maybe can't get Windows WASAPI from Host APIs
pyaudio can't get data in mac os because of system privacy control
"""

import pyaudio
from utils.device.base import DeviceBase
from utils.comm.os import OSFile
from utils.comm.log import logger


def get_wasapi_input_devs():
    pa = pyaudio.PyAudio()
    wasapi_idx = -1
    dev_dict = {}
    for idx in range(pa.get_host_api_count()):
        api_info = pa.get_host_api_info_by_index(idx)
        if api_info.get("name") == "Windows WASAPI":
            wasapi_idx = api_info.get("index")
            break
    if wasapi_idx < 0:
        logger.error(f"Don't find host api WASAPI")
        return
    for dev_idx in range(pa.get_device_count()):
        dev_info = pa.get_device_info_by_index(dev_idx)
        if dev_info.get("hostApi") != wasapi_idx:
            continue
        if dev_info.get('maxInputChannels') <= 0:
            continue
        dev_dict[dev_idx] = dev_info
    return dev_dict


class DeviceUsb(DeviceBase):

    def __init__(self, format_=None):
        super().__init__()
        self.pa = pyaudio.PyAudio()
        self.format_ = format_
        self.dev_idx = None
        self.dev_info = None
        self.rate = None
        self.chls = None
        self.bits = None
        self.stream = None
        self.save_file = None

    def _check_device_json(self, device_json) -> bool:
        connect_index = device_json.get("connect_index")
        if not (connect_index and connect_index.isdigit()):
            logger.error(f"connect_index is invalid")
            return False
        save_path = device_json.get("save_path")
        if not (save_path and OSFile.isabs(save_path)):
            logger.error(f"save_path is invalid")
            return False
        return True

    def _check_format(self) -> bool:
        rate = int(self.dev_info.get("defaultSampleRate"))
        chls = self.dev_info.get("maxInputChannels")
        bits = pyaudio.paInt16
        if self.format_:
            if self.format_.rate != rate:
                logger.error(f"config rate is {self.format_.rate} "
                             f"while dev_info rate is {rate}")
                return False
            if self.format_.chls != chls:
                logger.error(f"config channel is {self.format_.chls} "
                             f"while dev_info channel is {chls}")
                return False
            if self.format_.bits == 32:
                bits = pyaudio.paInt32
        self.rate = rate
        self.chls = chls
        self.bits = bits
        return True

    def prepare_record(self) -> bool:
        dev_idx = int(self.device_data.connect_index)
        dev_dict = get_wasapi_input_devs()
        if dev_idx not in dev_dict:
            logger.error(f"Can't find input device {dev_idx}")
            return False
        dev_info = dev_dict.get(dev_idx)
        self.dev_idx = dev_idx
        self.dev_info = dev_info
        if not self._check_format():
            return False
        return True

    def start_record(self) -> bool:
        try:
            save_file = open(self.device_data.save_path, 'wb')
        except Exception as exp:
            logger.error(exp)
            return False
        stream = self.pa.open(rate=self.rate, channels=self.chls,
                              format=self.bits, input=True,
                              input_device_index=self.dev_idx,
                              frames_per_buffer=self.rate, start=False,
                              stream_callback=self.stream_to_file)
        stream.start_stream()
        self.save_file = save_file
        self.stream = stream
        return True

    def stream_to_file(self, in_data, frame_count, time_info, status):
        self.save_file.write(in_data)
        return None, pyaudio.paContinue

    def check_data(self) -> bool:
        return OSFile.check_file(self.device_data.save_path)

    def stop_record(self):
        self.stream.stop_stream()
        self.stream.close()
        self.pa.terminate()
        self.save_file.close()
        return

    def pull_data(self, local_path):
        OSFile.rename(self.device_data.save_path, local_path)
