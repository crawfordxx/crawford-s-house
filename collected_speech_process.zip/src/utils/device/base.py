#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Dict, Optional
from pydantic import BaseModel
from utils.comm.log import logger


class DeviceData(BaseModel):
    connect_type: str = None  # 连接类型
    connect_index: str = None  # 设备连接索引，配合连接类型需要的设备访问参数。ssh就是user@IP
    save_flag: str = None  # 设备保存的录音文件的路径
    save_path: str = None  # 设备保存的录音文件匹配字符串


class DeviceBase:

    def __init__(self):
        self.device_data = None

    def _check_device_json(self, device_json) -> bool:
        return True

    def set_device_json(self, device_json) -> bool:
        if not device_json:
            logger.error(f"device_data is None")
            return False
        if not self._check_device_json(device_json):
            logger.error(f"device_data is invalid")
            return False
        device_data = DeviceData(**device_json)
        self.device_data = device_data
        return True

    def get_device_json(self) -> Optional[Dict]:
        if not self.device_data:
            logger.error(f"device_data is None")
            return None
        device_json = self.device_data.dict()
        device_keys = list(device_json.keys())
        for key in device_keys:
            if not device_json[key]:
                del device_json[key]
        return device_json
