#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
目的：    用于统计所有信息
类：      StatBatch
成员变量：stat_audio是StatAudio类的对象
          stat_scene是StatScene类的对象
          stat_speaker是StatSpeaker类的对象
          stat_sentence是StatSentence类的对象
方法：    set_stat_data，传入desc_json的列表，生成dataframe，统计所有信息
          get_stat_json，将统计数据转化为json格式输出
"""

from pandas.io.json import json_normalize
from utils.stat.stat_audio import StatAudio
from utils.stat.stat_scene import StatScene
from utils.stat.stat_speaker import StatSpeaker
from utils.stat.stat_sentence import StatSentence
from utils.comm.log import logger


class StatBatch():

    def __init__(self):
        self.stat_audio = None
        self.stat_scene = None
        self.stat_speaker = None
        self.stat_sentence = None

    def set_stat_data(self, desc_json_list):
        """
        目的：  设置统计信息
        参数：  desc_json列表
        返回值：设置成功返回True，设置失败返回False
        """
        if not desc_json_list:
            logger.error("desc_json_list is None")
            return False

        desc_dataframe = json_normalize(desc_json_list)

        # audio
        stat_audio = StatAudio()
        if stat_audio.set_audio_data(desc_dataframe):
            self.stat_audio = stat_audio
        else:
            logger.error("set audio data failed")
            return False

        # scene
        stat_scene = StatScene()
        if stat_scene.set_scene_data(desc_dataframe):
            self.stat_scene = stat_scene

        # speaker
        stat_speaker = StatSpeaker()
        if stat_speaker.set_speaker_data(desc_dataframe):
            self.stat_speaker = stat_speaker

        # sentence
        stat_sentence = StatSentence()
        if stat_sentence.set_sentence_data(desc_dataframe):
            self.stat_sentence = stat_sentence

        return True

    def get_stat_json(self):
        """
        目的：  将统计数据转化为json格式
        返回值：统计信息的json格式
        """
        if self.stat_audio:
            audio_json = self.stat_audio.get_audio_json()
        else:
            logger.error(f"get audio json failed")
            return None

        if self.stat_scene:
            scene_json = self.stat_scene.get_scene_json()
        else:
            scene_json = None

        if self.stat_speaker:
            speaker_json = self.stat_speaker.get_speaker_json()
        else:
            speaker_json = None

        if self.stat_sentence:
            sentence_json = self.stat_sentence.get_sentence_json()
        else:
            sentence_json = None

        stat_json = {
            "audio": audio_json,
            "scene": scene_json,
            "speaker": speaker_json,
            "sentence": sentence_json
        }

        stat_keys = list(stat_json.keys())
        for key in stat_keys:
            if not stat_json[key]:
                del stat_json[key]
        return stat_json
