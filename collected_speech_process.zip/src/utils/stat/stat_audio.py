#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
目的：    用于统计音频信息
类：      StatAudio
成员变量：audio_data是StatAudioData类的对象
方法：    set_audio_data，传入desc_json的dataframe，统计音频信息，设置成员变量audio_data
          get_audio_json，将audio_data中的统计数据转化为json格式输出
"""

from utils.stat.stat_data import StatAudioHardwareData
from utils.stat.stat_data import StatAudioDeviceData
from utils.stat.stat_data import StatAudioDurationData
from utils.stat.stat_data import StatAudioData
from utils.comm.log import logger


class StatAudio():

    def __init__(self):
        self.audio_data = None

    def set_audio_data(self, desc_dataframe):
        """
        目的：  设置成员变量audio_data
        参数：  desc的dataframe
        返回值：设置成功返回True，设置失败返回False
        """
        # count
        if "basic.wav_name" in desc_dataframe.columns:
            wav_cnt = int(desc_dataframe["basic.wav_name"].count())
        else:
            logger.error(f"Basic.wav_name is None")
            return False

        # hardware
        if "audio.hardware" in desc_dataframe.columns:
            hardware_series = desc_dataframe["audio.hardware"].value_counts()
            hardware_data = StatAudioHardwareData()
            hardware_data.uniq_cnt = int(hardware_series.count())
            hardware_data.sum_cnt = int(hardware_series.sum())
            hardware_data.mean_cnt = round(hardware_series.mean(), 2)
            hardware_data.median_cnt = int(hardware_series.median())
            hardware_data.whole_dist = dict(sorted(hardware_series.items()))
        else:
            hardware_data = None

        # device
        if "audio.device" in desc_dataframe.columns:
            device_series = desc_dataframe["audio.device"].value_counts()
            device_data = StatAudioDeviceData()
            device_data.uniq_cnt = int(device_series.count())
            device_data.sum_cnt = int(device_series.sum())
            device_data.mean_cnt = round(device_series.mean(), 2)
            device_data.median_cnt = int(device_series.median())
            value_sorted = sorted(device_series.items(), key=lambda d: d[1],
                                  reverse=True)
            device_data.head_dist = dict(value_sorted[:10])
        else:
            device_data = None

        # duration
        if "audio.duration" in desc_dataframe.columns:
            duration_series = desc_dataframe["audio.duration"]
            duration_data = StatAudioDurationData()
            duration_data.sum_hour = round(duration_series.sum() / 3600, 2)
            duration_data.mean_sec = round(duration_series.mean(), 2)
            duration_data.median_sec = round(duration_series.median(), 2)
        else:
            logger.error(f"Audio.duration is None")
            duration_data = None

        # audio
        self.audio_data = StatAudioData()
        self.audio_data.count = wav_cnt
        self.audio_data.hardware = hardware_data
        self.audio_data.device = device_data
        self.audio_data.duration = duration_data
        return True

    def get_audio_json(self):
        """
        目的：  将audio_data中的统计数据转化为json格式输出
        返回值：音频统计信息的json格式输出
        """
        if not self.audio_data:
            logger.warning(f"audio_data is empty")
            return
        audio_json = self.audio_data.dict()
        audio_keys = list(audio_json.keys())
        for key in audio_keys:
            if not audio_json[key]:
                del audio_json[key]
        return audio_json
