#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
目的：    用于统计场景信息
类：      StatScene
成员变量：scene_data是StatAudioData类的对象
方法：    set_scene_data，传入desc_json的dataframe，统计场景信息，设置成员变量scene_data
          get_scene_json，将scene_data中的统计数据转化为json格式输出
"""

from utils.stat.stat_data import StatSceneScidData
from utils.stat.stat_data import StatSceneData
from utils.comm.log import logger


class StatScene():

    def __init__(self):
        self.scene_data = None

    def set_scene_data(self, desc_dataframe):
        """
        目的：  设置成员变量scene_data
        参数：  desc的dataframe
        返回值：若成功设置成员变量则返回True，否则返回False
        """
        # scid
        if "scene.scid" in desc_dataframe.columns:
            scid_series = desc_dataframe["scene.scid"].value_counts()
            scid_data = StatSceneScidData()
            scid_data.uniq_cnt = int(scid_series.count())
            scid_data.sum_cnt = int(scid_series.sum())
            scid_data.mean_cnt = round(scid_series.mean(), 2)
            scid_data.median_cnt = int(scid_series.median())
            scid_data.whole_dist = dict(sorted(scid_series.items()))
        else:
            logger.info(f"Scene.scid is None")
            return False

        # scene
        self.scene_data = StatSceneData()
        self.scene_data.scid = scid_data
        return True

    def get_scene_json(self):
        """
        目的：  将scene_data的统计数据转化为json格式
        返回值：scene统计信息的json格式数据
        """
        if not self.scene_data:
            logger.info(f"scene_data is empty")
            return
        scene_json = self.scene_data.dict()
        scene_keys = list(scene_json.keys())
        for key in scene_keys:
            if not scene_json[key]:
                del scene_json[key]
        return scene_json
