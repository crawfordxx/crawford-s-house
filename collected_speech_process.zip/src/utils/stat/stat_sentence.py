#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
目的：    用于统计文本信息
类：      StatSentence
成员变量：sentence_data是StatSentenceData类的对象
方法：    set_sentence_data，传入desc_json的dataframe，统计文本信息，设置成员变量sentence_data
          get_sentence_json，将sentence_data中的统计数据转化为json格式输出
"""

import pandas
from utils.stat.stat_data import StatSentenceVadData
from utils.stat.stat_data import StatSentenceTextData
from utils.stat.stat_data import StatSentenceEmotionData
from utils.stat.stat_data import StatSentenceData
from utils.comm.log import logger


class StatSentence():

    def __init__(self):
        self.sentence_data = None

    def set_sentence_data(self, desc_dataframe):
        """
        目的：  设置成员变量sentence_data
        参数：  desc的dataframe
        返回值: 设置成功返回True，设置失败返回False
        """
        # desc
        if "sentence" not in desc_dataframe.columns:
            logger.info(f"Sentence is None")
            return False
        nested_list = desc_dataframe["sentence"].tolist()
        sentence_list = [item for sublist in nested_list for item in sublist]
        sentence_dataframe = pandas.DataFrame(sentence_list)

        # vad
        if "vad_beg" in sentence_dataframe.columns and \
                "vad_end" in sentence_dataframe.columns:
            vad_series = sentence_dataframe["vad_end"] - \
                    sentence_dataframe["vad_beg"]
            vad_data = StatSentenceVadData()
            vad_data.sum_hour = round(vad_series.sum() / 3600, 2)
            vad_data.mean_sec = round(vad_series.mean(), 3)
            vad_data.median_sec = round(vad_series.median(), 3)
        else:
            vad_data = None

        # text
        if "text" in sentence_dataframe.columns:
            text_series = sentence_dataframe["text"].value_counts()
            text_data = StatSentenceTextData()
            text_data.uniq_cnt = int(text_series.count())
            text_data.sum_cnt = int(text_series.sum())
            text_data.mean_cnt = round(text_series.mean(), 2)
            text_data.median_cnt = int(text_series.median())
            value_sorted = sorted(text_series.items(), key=lambda d: d[1],
                                  reverse=True)
            text_data.head_dist = dict(value_sorted[:10])
        else:
            text_data = None

        # emotion
        if "emotion" in sentence_dataframe.columns:
            emotion_series = sentence_dataframe["emotion"].value_counts()
            emotion_data = StatSentenceEmotionData()
            emotion_data.uniq_cnt = int(emotion_series.count())
            emotion_data.sum_cnt = int(emotion_series.sum())
            emotion_data.mean_cnt = round(emotion_series.mean(), 2)
            emotion_data.median_cnt = int(emotion_series.median())
            emotion_data.whole_dist = dict(sorted(
                emotion_series.items(), key=lambda d: d[1], reverse=True))
        else:
            emotion_data = None

        # sentence
        self.sentence_data = StatSentenceData()
        self.sentence_data.vad = vad_data
        self.sentence_data.text = text_data
        self.sentence_data.emotion = emotion_data
        return True

    def get_sentence_json(self):
        """
        目的：  将sentence_data中的统计数据转化为json格式
        返回值：文本统计信息的json格式
        """
        if not self.sentence_data:
            logger.error(f"sentence_data is empty")
            return
        sentence_json = self.sentence_data.dict()
        sentence_keys = list(sentence_json.keys())
        for key in sentence_keys:
            if not sentence_json[key]:
                del sentence_json[key]
        return sentence_json
