#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
目的：    用于统计说话人信息
类：      StatSpeaker
成员变量：speaker_data是StatSpeakerData类的对象
方法：    set_speaker_data，传入desc_json的dataframe，统计说话人信息，设置成员变量speaker_data
          get_speaker_json，将speaker_data中的统计数据转化为json格式输出
"""

from utils.stat.stat_data import StatSpeakerSpkidData
from utils.stat.stat_data import StatSpeakerGenderData
from utils.stat.stat_data import StatSpeakerAgeData
from utils.stat.stat_data import StatSpeakerRegionData
from utils.stat.stat_data import StatSpeakerAccentData
from utils.stat.stat_data import StatSpeakerData
from utils.comm.log import logger


def update_age(age_str):
    if isinstance(age_str, str) and age_str.isdigit():
        age = int(age_str)
        if age <= 12:
            return "child"
        elif age > 12 and age <= 18:
            return "young"
        elif age > 18 and age <= 55:
            return "adult"
        else:
            return "older"
    else:
        return age_str


class StatSpeaker():

    def __init__(self):
        self.speaker_data = None

    def set_speaker_data(self, desc_dataframe):
        """
        目的：  设置成员变量speaker_data
        参数：  desc的dataframe
        返回值：若成功设置成员变量则返回True，否则返回False
        """
        # spkid
        if "speaker.spkid" in desc_dataframe.columns:
            spkid_series = desc_dataframe["speaker.spkid"].value_counts()
            spkid_data = StatSpeakerSpkidData()
            spkid_data.uniq_cnt = int(spkid_series.count())
            spkid_data.sum_cnt = int(spkid_series.sum())
            spkid_data.mean_cnt = round(spkid_series.mean(), 2)
            spkid_data.median_cnt = int(spkid_series.median())
            value_sorted = sorted(spkid_series.items(), key=lambda d: d[1],
                                  reverse=True)
            spkid_data.head_dist = dict(value_sorted[:100])
        else:
            logger.info(f"Speaker.spkid is None")
            return False

        uniq_dataframe = desc_dataframe.drop_duplicates(['speaker.spkid'])

        # gender
        if "speaker.gender" in uniq_dataframe.columns:
            gender_series = uniq_dataframe["speaker.gender"].value_counts()
            gender_data = StatSpeakerGenderData()
            if "female" in gender_series:
                gender_data.female_cnt = int(gender_series["female"])
                gender_data.female_pct = round(
                        gender_data.female_cnt / spkid_data.uniq_cnt, 2)
            if "male" in gender_series:
                gender_data.male_cnt = int(gender_series["male"])
                gender_data.male_pct = round(
                        gender_data.male_cnt / spkid_data.uniq_cnt, 2)
        else:
            gender_data = None

        # age
        if "speaker.age" in uniq_dataframe.columns:
            tmp_series = uniq_dataframe["speaker.age"].apply(update_age)
            age_series = tmp_series.value_counts()
            age_data = StatSpeakerAgeData()
            if "child" in age_series:
                age_data.child_cnt = int(age_series["child"])
                age_data.child_pct = round(
                        age_data.child_cnt / spkid_data.uniq_cnt, 2)
            if "young" in age_series:
                age_data.young_cnt = int(age_series["young"])
                age_data.young_pct = round(
                        age_data.young_cnt / spkid_data.uniq_cnt, 2)
            if "adult" in age_series:
                age_data.adult_cnt = int(age_series["adult"])
                age_data.adult_pct = round(
                        age_data.adult_cnt / spkid_data.uniq_cnt, 2)
            if "older" in age_series:
                age_data.older_cnt = int(age_series["older"])
                age_data.older_pct = round(
                        age_data.older_cnt / spkid_data.uniq_cnt, 2)
        else:
            age_data = None

        # region

        # accent
        if "speaker.accent" in uniq_dataframe.columns:
            accent_series = uniq_dataframe["speaker.accent"].value_counts()
            accent_data = StatSpeakerAccentData()
            if "mandarin" in accent_series:
                accent_data.mandarin_cnt = int(accent_series["mandarin"])
                accent_data.mandarin_pct = round(
                        accent_data.mandarin_cnt / spkid_data.uniq_cnt, 2)
            if "accent" in accent_series:
                accent_data.accent_cnt = int(accent_series["accent"])
                accent_data.accent_pct = round(
                        accent_data.accent_cnt / spkid_data.uniq_cnt, 2)
            if "dialect" in accent_series:
                accent_data.dialect_cnt = int(accent_series["dialect"])
                accent_data.dialect_pct = round(
                        accent_data.dialect_cnt / spkid_data.uniq_cnt, 2)
        else:
            accent_data = None

        # speaker
        self.speaker_data = StatSpeakerData()
        self.speaker_data.spkid = spkid_data
        self.speaker_data.gender = gender_data
        self.speaker_data.age = age_data
        self.speaker_data.accent = accent_data
        return True

    def get_speaker_json(self):
        """
        目的：  将speaker_data的统计数据转化为json格式
        返回值：speaker统计信息的json格式数据
        """
        if not self.speaker_data:
            logger.error(f"speaker_data is empty")
            return
        speaker_json = self.speaker_data.dict()
        speaker_keys = list(speaker_json.keys())
        for key in speaker_keys:
            if not speaker_json[key]:
                del speaker_json[key]
        return speaker_json
