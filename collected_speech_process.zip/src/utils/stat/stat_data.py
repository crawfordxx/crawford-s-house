#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pydantic import BaseModel


""" audio """
class StatAudioHardwareData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    whole_dist: dict = None

class StatAudioDeviceData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    head_dist: dict = None

class StatAudioDurationData(BaseModel):
    sum_hour: float = None
    mean_sec: float = None
    median_sec: float = None

class StatAudioData(BaseModel):
    count: int = None
    hardware: StatAudioHardwareData = None
    device: StatAudioDeviceData = None
    duration: StatAudioDurationData = None


""" scene """
class StatSceneScidData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    whole_dist: dict = None

class StatSceneData(BaseModel):
    scid: StatSceneScidData = None


""" speaker """
class StatSpeakerSpkidData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    head_dist: dict = None

class StatSpeakerGenderData(BaseModel):
    female_cnt: int = None
    male_cnt: int = None
    female_pct: float = None
    male_pct: float = None

class StatSpeakerAgeData(BaseModel):
    child_cnt: int = None
    young_cnt: int = None
    adult_cnt: int = None
    older_cnt: int = None
    child_pct: float = None
    young_pct: float = None
    adult_pct: float = None
    older_pct: float = None

class StatSpeakerRegionData(BaseModel):
    whole_dist: dict = None

class StatSpeakerAccentData(BaseModel):
    mandarin_cnt: int = None
    accent_cnt: int = None
    dialect_cnt: int = None
    mandarin_pct: float = None
    accent_pct: float = None
    dialect_pct: float = None

class StatSpeakerData(BaseModel):
    spkid: StatSpeakerSpkidData = None
    gender: StatSpeakerGenderData = None
    age: StatSpeakerAgeData = None
    region: StatSpeakerRegionData = None
    accent: StatSpeakerAccentData = None


"""sentence"""
class StatSentenceVadData(BaseModel):
    sum_hour: float = None
    mean_sec: float = None
    median_sec: float = None

class StatSentenceTextData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    head_dist: dict = None

class StatSentenceEmotionData(BaseModel):
    uniq_cnt: int = None
    sum_cnt: int = None
    mean_cnt: float = None
    median_cnt: int = None
    whole_dist: dict = None

class StatSentenceData(BaseModel):
    vad: StatSentenceVadData = None
    text: StatSentenceTextData = None
    emotion: StatSentenceEmotionData = None
