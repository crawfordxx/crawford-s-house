#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import List, Optional
from utils.desc.desc_sentence_item import DescSentenceItem
from utils.comm.log import logger


class DescSentenceBatch():

    def __init__(self):
        self.sentence_dict = {}

    def set_sentence_batch(self, sentence_list) -> bool:
        for snt_json in sentence_list:
            wav_name = snt_json.get("wav_name")
            if not wav_name:
                logger.warning(f"{snt_json} get wav_name failed")
                continue
            sentence_json = snt_json.get("sentence")
            if not sentence_json:
                logger.warning(f"{wav_name} get sentence_json failed")
                continue
            sentence_item = DescSentenceItem()
            if not sentence_item.set_sentence_json(sentence_json):
                logger.warning(f"{wav_name} set sentence json failed")
                continue
            if wav_name not in self.sentence_dict:
                self.sentence_dict[wav_name] = [sentence_item]
            else:
                self.sentence_dict[wav_name].append(sentence_item)
        if not self.sentence_dict:
            logger.error(f"sentence dict is empty")
            return False
        else:
            return True

    def set_batch_json_list(self, json_list) -> bool:
        if not json_list:
            logger.error(f"json_list is None")
            return False

        for json_item in json_list:
            # wav_name
            if not (json_item.get('basic') and
                    json_item.get('basic').get('wav_name')):
                logger.error(f"{json_item} get wav_name failed")
                continue
            wav_name = json_item.get('basic').get('wav_name')
            if wav_name in self.sentence_dict:
                logger.error(f"{wav_name} is already exist")
                continue
            # sentence_json_list
            sentence_json_list = json_item.get('sentence')
            if not sentence_json_list:
                logger.error(f"{wav_name} get sentence_json_list failed")
                continue
            # sentence_item_list
            sentence_item_list = []
            for sentence_json in sentence_json_list:
                sentence_item = DescSentenceItem()
                if not sentence_item.set_sentence_json(sentence_json):
                    logger.error(f"{wav_name} set sentence json failed")
                    continue
                sentence_item_list.append(sentence_item)
            # dict
            self.sentence_dict[wav_name] = sentence_item_list

        if not self.sentence_dict:
            logger.error(f"sentence_dict is empty")
            return False
        else:
            return True

    def get_batch_json_list(self) -> Optional[List]:
        json_list = []
        for wav_name, sentence_item_list in self.sentence_dict.items():
            sentence_json_list = []
            for sentence_item in sentence_item_list:
                sentence_json = sentence_item.get_sentence_json()
                if not sentence_json:
                    logger.warning(f"get sentence json failed")
                    continue
                sentence_json_list.append(sentence_json)
            if not sentence_json_list:
                logger.warning(f"{wav_name} get sentence json failed")
                continue
            json_item = {
                "basic": {"wav_name": wav_name},
                "sentence": sentence_json_list
            }
            json_list.append(json_item)
        return json_list
