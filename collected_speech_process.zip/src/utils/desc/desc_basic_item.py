#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from typing import Dict, Optional
from utils.desc.desc_data import DescBasicData
from utils.comm.log import logger


class DescBasicItem():

    def __init__(self):
        self.basic_data = None

    def check_basic_data(self, basic_data) -> bool:
        wav_name = basic_data.wav_name
        wav_path = basic_data.wav_path
        if not wav_name or not wav_path:
            logger.error(f"wav_name or wav_path is None")
            return False
        if not os.path.isfile(wav_path):
            logger.error(f"wav_path {wav_path} is invalid")
            return False
        if wav_name != os.path.basename(wav_path).split('.')[0]:
            logger.error(f"{wav_name} and {wav_path} isn't match")
            return False
        return True

    def set_basic_item(self, batch_name, wav_path) -> bool:
        if not batch_name or not wav_path:
            logger.error(f"batch_name or wav_path is None")
            return False

        basic_data = DescBasicData()
        basic_data.wav_name = os.path.basename(wav_path).split(".")[0]
        basic_data.wav_path = wav_path
        basic_data.batch = batch_name
        basic_data.uttid = basic_data.batch + "-" + basic_data.wav_name
        if not self.check_basic_data(basic_data):
            logger.error(f"basic_data is invalid")
            return False

        self.basic_data = basic_data
        return True

    def set_basic_json(self, basic_json) -> bool:
        if not basic_json:
            logger.error(f"basic_json is None")
            return False

        basic_data = DescBasicData(**basic_json)
        if not self.check_basic_data(basic_data):
            logger.error(f"basic_data is invalid")
            return False

        self.basic_data = basic_data
        return True

    def get_basic_json(self) -> Optional[Dict]:
        if not self.basic_data:
            logger.error(f"basic_data is None")
            return None
        basic_json = self.basic_data.dict()
        basic_keys = list(basic_json.keys())
        for key in basic_keys:
            if not basic_json[key]:
                del basic_json[key]
        return basic_json
