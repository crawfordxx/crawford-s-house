#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import List, Optional
from utils.desc.desc_speaker_item import DescSpeakerItem
from utils.comm.log import logger


class DescSpeakerBatch():

    def __init__(self):
        self.speaker_dict = {}
        self.wav_spk_dict = {}

    def set_speaker_dict(self, speaker_list) -> bool:
        if not speaker_list:
            logger.error(f"speaker_list is None")
            return False

        for speaker_json in speaker_list:
            speaker_item = DescSpeakerItem()
            if not speaker_item.set_speaker_json(speaker_json):
                logger.warning(f"'{speaker_json}' set speaker json failed")
                continue
            spkid = speaker_item.speaker_data.spkid
            if spkid in self.speaker_dict:
                logger.warning(f"{spkid} is already exist")
                continue
            self.speaker_dict[spkid] = speaker_item

        if not self.speaker_dict:
            logger.error(f"speaker_dict is empty")
            return False
        else:
            return True

    def set_wav_spk_dict(self, wav2spk_dict) -> bool:
        if not wav2spk_dict:
            logger.error(f"wav2spk_dict is None")
            return False
        if not self.speaker_dict:
            logger.error(f"speaker_dict is empty")
            return False

        for wav_name, spkid in wav2spk_dict.items():
            if spkid not in self.speaker_dict:
                logger.warning(f"{spkid} isn't in speaker_dict")
                continue
            self.wav_spk_dict[wav_name] = self.speaker_dict[spkid]

        if not self.wav_spk_dict:
            logger.error(f"wav_spk_dict is empty")
            return False
        else:
            return True

    def set_speaker_batch(self, speaker_list, wav2spk_dict) -> bool:
        if not self.set_speaker_dict(speaker_list):
            logger.error(f"set speaker dict failed")
            return False
        if not self.set_wav_spk_dict(wav2spk_dict):
            logger.error(f"set wav_spk dict failed")
            return False
        return True

    def set_batch_json_list(self, json_list) -> bool:
        if not json_list:
            logger.error(f"json_list is None")
            return False

        for json_item in json_list:
            # wav_name
            if not (json_item.get('basic') and
                    json_item.get('basic').get('wav_name')):
                logger.error(f"{json_item} get wav_name failed")
                continue
            wav_name = json_item.get('basic').get('wav_name')
            if wav_name in self.wav_spk_dict:
                logger.error(f"{wav_name} is already exist")
                continue
            # speaker_json
            speaker_json = json_item.get('speaker')
            if not speaker_json:
                logger.error(f"{wav_name} get speaker_json failed")
                continue
            # speaker_item
            speaker_item = DescSpeakerItem()
            if not speaker_item.set_speaker_json(speaker_json):
                logger.error(f"{wav_name} set speaker_item failed")
                continue
            # dict
            spkid = speaker_item.speaker_data.spkid
            if spkid not in self.speaker_dict:
                self.speaker_dict[spkid] = speaker_item
            self.wav_spk_dict[wav_name] = speaker_item

        if not self.speaker_dict or not self.wav_spk_dict:
            logger.error(f"speaker_dict or wav_spk_dict is empty")
            return False
        else:
            return True

    def get_batch_json_list(self) -> Optional[List]:
        json_list = []
        for wav_name, speaker_item in self.wav_spk_dict.items():
            speaker_json = speaker_item.get_speaker_json()
            if not speaker_json:
                logger.error(f"{wav_name} get speaker json failed")
                continue
            json_item = {
                "basic": {"wav_name": wav_name},
                "speaker": speaker_json
            }
            json_list.append(json_item)
        return json_list
