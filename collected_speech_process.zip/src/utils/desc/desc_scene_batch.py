#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import List, Optional
from utils.desc.desc_scene_item import DescSceneItem
from utils.comm.log import logger


class DescSceneBatch():

    def __init__(self):
        self.scene_dict = {}
        self.wav_sc_dict = {}

    def set_scene_dict(self, scene_list) -> bool:
        if not scene_list:
            logger.error(f"scene_list is None")
            return False

        for scene_json in scene_list:
            scene_item = DescSceneItem()
            if not scene_item.set_scene_json(scene_json):
                logger.warning(f"'{scene_json}' set scene json failed")
                continue
            scid = scene_item.scene_data.scid
            if scid in self.scene_dict:
                logger.warning(f"{scid} is already exist")
                continue
            self.scene_dict[scid] = scene_item

        if not self.scene_dict:
            logger.error(f"scene_dict is empty")
            return False
        else:
            return True

    def set_wav_sc_dict(self, wav2sc_dict) -> bool:
        if not wav2sc_dict:
            logger.error(f"wav2sc_dict is None")
            return False
        if not self.scene_dict:
            logger.error(f"scene_dict is empty")
            return False

        for wav_name, scid in wav2sc_dict.items():
            if scid not in self.scene_dict:
                logger.warning(f"{scid} isn't in scene_dict")
                continue
            self.wav_sc_dict[wav_name] = self.scene_dict[scid]

        if not self.wav_sc_dict:
            logger.error(f"wav_sc_dict is empty")
            return False
        else:
            return True

    def set_scene_batch(self, scene_list, wav2sc_dict) -> bool:
        if not self.set_scene_dict(scene_list):
            logger.error(f"set scene_dict failed")
            return False
        if not self.set_wav_sc_dict(wav2sc_dict):
            logger.error(f"set wav_sc_dict failed")
            return False
        return True

    def set_batch_json_list(self, json_list) -> bool:
        if not json_list:
            logger.error(f"json_list is None")
            return False

        for json_item in json_list:
            # wav_name
            if not (json_item.get('basic') and
                    json_item.get('basic').get('wav_name')):
                logger.error(f"{json_item} get wav_name failed")
                continue
            wav_name = json_item.get('basic').get('wav_name')
            if wav_name in self.wav_sc_dict:
                logger.error(f"{wav_name} is already exist")
                continue
            # scene_json
            scene_json = json_item.get('scene')
            if not scene_json:
                logger.error(f"{wav_name} get scene_json failed")
                continue
            # scene_item
            scene_item = DescSceneItem()
            if not scene_item.set_scene_json(scene_json):
                logger.error(f"{wav_name} set scene json failed")
                continue
            # dict
            scid = scene_item.scene_data.scid
            if scid not in self.scene_dict:
                self.scene_dict[scid] = scene_item
            self.wav_sc_dict[wav_name] = scene_item

        if not self.scene_dict or not self.wav_sc_dict:
            logger.error(f"scene_dict or wav_sc_dict is empty")
            return False
        else:
            return True

    def get_batch_json_list(self) -> Optional[List]:
        json_list = []
        for wav_name, scene_item in self.wav_sc_dict.items():
            scene_json = scene_item.get_scene_json()
            if not scene_json:
                logger.error(f"{wav_name} get scene json failed")
                continue
            json_item = {
                "basic": {"wav_name": wav_name},
                "scene": scene_json
            }
            json_list.append(json_item)
        return json_list
