#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import List, Optional
from utils.desc.desc_batch_item import DescBatchItem
from utils.comm.log import logger


class DescBatch():

    def __init__(self):
        self.batch_dict = {}

    def set_batch(self, audio_batch, scene_batch,
                  speaker_batch, sentence_batch) -> bool:
        if not audio_batch:
            logger.error(f"audio batch is None")
            return False

        for wav_name, basic_item in audio_batch.basic_dict.items():
            # audio
            audio_item = None
            if wav_name in audio_batch.audio_dict:
                audio_item = audio_batch.audio_dict[wav_name]
            else:
                logger.error(f"{wav_name} don't find audio_item")
                continue

            # scene
            scene_item = None
            if scene_batch:
                if wav_name in scene_batch.wav_sc_dict:
                    scene_item = scene_batch.wav_sc_dict[wav_name]
                else:
                    logger.error(f"{wav_name} don't find scene_item")
                    continue

            # speaker
            speaker_item = None
            if speaker_batch:
                if wav_name in speaker_batch.wav_spk_dict:
                    speaker_item = speaker_batch.wav_spk_dict[wav_name]
                else:
                    logger.error(f"{wav_name} don't find speaker_item")
                    continue

            # sentence
            sentence_item_list = None
            if sentence_batch:
                if wav_name in sentence_batch.sentence_dict:
                    sentence_item_list = sentence_batch.sentence_dict[wav_name]
                else:
                    logger.error(f"{wav_name} don't find sentence_item_list")
                    continue

            # batch
            batch_item = DescBatchItem()
            if batch_item.set_batch_item(basic_item, audio_item, scene_item,
                                         speaker_item, sentence_item_list):
                self.batch_dict[wav_name] = batch_item
            else:
                logger.error(f"{wav_name} set batch item failed")

        if not self.batch_dict:
            logger.error(f"batch_dict is empty")
            return False
        else:
            return True

    def set_batch_json_list(self, json_list) -> bool:
        if not json_list:
            logger.error(f"json_list is None")
            return False

        for json_item in json_list:
            batch_item = DescBatchItem()
            if not batch_item.set_batch_json(json_item):
                logger.warning(f"{json_item} set batch json failed")
                continue
            wav_name = batch_item.basic_item.basic_data.wav_name
            if wav_name in self.batch_dict:
                logger.warning(f"{wav_name} is already exist")
                continue
            self.batch_dict[wav_name] = batch_item

        if not self.batch_dict:
            logger.error(f"batch_dict is empty")
            return False
        else:
            return True

    def get_batch_json_list(self) -> Optional[List]:
        json_list = []
        for batch_item in self.batch_dict.values():
            json_list.append(batch_item.get_batch_json())
        return json_list

    def update_speaker(self, speaker_batch, intersection_only=True) -> bool:
        if not speaker_batch:
            logger.error(f"speaker_batch is None")
            return False
        if not self.batch_dict:
            logger.error(f"batch_dict is empty")
            return False
        wav_spk_dict = speaker_batch.wav_spk_dict
        for wav_name, batch_item in self.batch_dict.items():
            if wav_name in wav_spk_dict:
                batch_item.speaker_item = wav_spk_dict[wav_name]
        if intersection_only:
            desc_batch_keys = list(self.batch_dict.keys())
            for wav_name in desc_batch_keys:
                if wav_name not in wav_spk_dict.keys():
                    del self.batch_dict[wav_name]
        return True

    def update_sentence(self, sentence_batch, intersection_only=True) -> bool:
        if not sentence_batch:
            logger.error(f"sentence_batch is None")
            return False
        if not self.batch_dict:
            logger.error(f"batch_dict is empty")
            return False
        sentence_dict = sentence_batch.sentence_dict
        for wav_name, batch_item in self.batch_dict.items():
            if wav_name in sentence_dict:
                batch_item.sentence_item_list = sentence_dict[wav_name]
        if intersection_only:
            desc_batch_keys = list(self.batch_dict.keys())
            for wav_name in desc_batch_keys:
                if wav_name not in sentence_dict.keys():
                    del self.batch_dict[wav_name]
        return True
