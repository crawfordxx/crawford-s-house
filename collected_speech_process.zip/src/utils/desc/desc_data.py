#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pydantic import BaseModel
from typing import Any


""" basic """
class DescBasicData(BaseModel):
    wav_name: str = None
    wav_path: str = None
    batch: str = None
    spkid: str = None
    uttid: str = None


""" audio """
class DescAudioFormatData(BaseModel):
    rate: int = None
    bits: int = None
    chls: int = None

class DescAudioSignalData(BaseModel):
    real_rate: int = None
    clipping: int = None
    hopping: int = None

class DescAudioData(BaseModel):
    hardware: str = None
    device: str = None
    duration: float = None
    format_: DescAudioFormatData = None
    signal_: DescAudioSignalData = None


""" scene """
class DescSceneHomeAttrs(BaseModel):
    location: str = None
    direction: str = None
    distance: str = None
    noise: str = None
    snr: str = None
    echo: str = None
    ser: str = None

class DescSceneCarAttrs(BaseModel):
    model: str = None
    dev_pos: str = None
    spk_pos: str = None
    speed: str = None
    window: str = None
    air_con: str = None
    FM: str = None
    #wiper: str = None
    location: str = None
    datetime: str = None

class DescSceneData(BaseModel):
    scid: str = None
    domain: str = None
    attrs: Any = None 


""" speaker """
class DescSpeakerData(BaseModel):
    spkid: str = None
    gender: str = None
    age: str = None
    region: str = None
    accent: str = None


""" sentence """
class DescSentenceNLUData(BaseModel):
    domain: str = None

class DescSentenceData(BaseModel):
    source: str = None
    text: str = None
    vad_beg: float = None
    vad_end: float = None
    emotion: str = None
    phones: str = None
    speed: float = None
    NLU: DescSentenceNLUData = None
