#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
from typing import Dict, Optional
from utils.desc.desc_data import DescSentenceNLUData
from utils.desc.desc_data import DescSentenceData
from utils.comm.log import logger


class DescSentenceItem():

    def __init__(self):
        self.sentence_data = None

    def check_sentence_data(self, sentence_data) -> bool:
        vad_beg = sentence_data.vad_beg
        vad_end = sentence_data.vad_end
        if vad_beg and vad_end:
            if (vad_beg < 0) or (vad_end <= 0) or (vad_end-vad_beg < 0.4):
                logger.error(f"{vad_beg} or {vad_end} is value invalid")
                return False
        return True

    def set_sentence_json(self, sentence_json) -> bool:
        if not sentence_json:
            logger.error("sentence_json is None")
            return False
        sentence_data = DescSentenceData(**sentence_json)
        # if not self.check_sentence_data(sentence_data):
        #     logger.error(f"sentence_data is invalid")
        #     return False
        self.sentence_data = sentence_data
        return True

    def get_sentence_json(self) -> Optional[Dict]:
        if not self.sentence_data:
            logger.error(f"sentence_data is None")
            return None
        sentence_json = self.sentence_data.dict()
        sentence_keys = list(sentence_json.keys())
        for key in sentence_keys:
            if key == "vad_beg":
                if sentence_json[key] is None:
                    del sentence_json[key]
            elif not sentence_json[key]:
                del sentence_json[key]
        return sentence_json
