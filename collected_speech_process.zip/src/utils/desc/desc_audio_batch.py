#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from typing import List, Optional
from utils.desc.desc_audio_item import DescAudioItem
from utils.desc.desc_basic_item import DescBasicItem
from utils.comm.log import logger


class DescAudioBatch():

    def __init__(self):
        self.audio_dict = {}
        self.basic_dict = {}

    def set_audio_batch(self, batch_name, wav_path_list,
                        hardware, wav2dev_dict, detect_signal) -> bool:
        if not batch_name or not wav_path_list:
            logger.error(f"batch_name or wav_path_list is None")
            return False

        for wav_path in wav_path_list:
            # wav_name
            wav_name = os.path.basename(wav_path).split(".")[0]
            if not wav_name:
                logger.error(f"wav_name is None")
                continue
            # device
            if wav2dev_dict and (wav_name in wav2dev_dict):
                device = wav2dev_dict[wav_name]
            else:
                device = None
            # audio item
            audio_item = DescAudioItem()
            if not audio_item.set_audio_item(wav_path, hardware,
                                             device, detect_signal):
                logger.error(f"{wav_path} set audio item failed")
                continue
            # basic item
            basic_item = DescBasicItem()
            if not basic_item.set_basic_item(batch_name, wav_path):
                logger.error(f"{wav_path} set basic item failed")
                continue
            # dict
            wav_name = basic_item.basic_data.wav_name
            if wav_name in self.audio_dict:
                logger.error(f"{wav_name} is already exist")
                continue
            self.audio_dict[wav_name] = audio_item
            self.basic_dict[wav_name] = basic_item

        if not self.audio_dict and not self.basic_dict:
            logger.error(f"audio_dict or basic_dict is empty")
            return False
        else:
            return True

    def set_batch_json_list(self, json_list) -> bool:
        if not json_list:
            logger.error(f"json_list is None")
            return False

        for json_item in json_list:
            audio_json = json_item.get('audio')
            basic_json = json_item.get('basic')
            if not audio_json or not basic_json:
                logger.error(f"{json_item} get audio_json or "
                              "basic_json failed")
                continue
            # audio item
            audio_item = DescAudioItem()
            if not audio_item.set_audio_json(audio_json):
                logger.error(f"{json_item} set audio json failed")
                continue
            # basic item
            basic_item = DescBasicItem()
            if not basic_item.set_basic_json(basic_json):
                logger.error(f"{json_item} set basic json failed")
                continue
            # dict
            wav_name = basic_item.basic_data.wav_name
            if wav_name in self.audio_dict:
                logger.error(f"{wav_name} is already exist")
                continue
            self.audio_dict[wav_name] = audio_item
            self.basic_dict[wav_name] = basic_item

        if not self.audio_dict and not self.basic_dict:
            logger.error(f"audio_dict or basic_dict is empty")
            return False
        else:
            return True

    def get_batch_json_list(self) -> Optional[List]:
        json_list = []
        for wav_name in self.audio_dict.keys():
            audio_json = self.audio_dict[wav_name].get_audio_json()
            basic_json = self.basic_dict[wav_name].get_basic_json()
            if not audio_json or not basic_json:
                logger.error(f"{wav_name} get audio_json or basic_json failed")
                continue
            json_item = {
                "basic": basic_json,
                "audio": audio_json
            }
            json_list.append(json_item)
        return json_list
