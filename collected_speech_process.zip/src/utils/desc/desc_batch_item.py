#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Dict, Optional
from utils.desc.desc_basic_item import DescBasicItem
from utils.desc.desc_audio_item import DescAudioItem
from utils.desc.desc_scene_item import DescSceneItem
from utils.desc.desc_speaker_item import DescSpeakerItem
from utils.desc.desc_sentence_item import DescSentenceItem
from utils.comm.log import logger


class DescBatchItem():

    def __init__(self):
        self.basic_item = None
        self.audio_item = None
        self.scene_item = None
        self.speaker_item = None
        self.sentence_item_list = None

    def set_batch_item(self, basic_item, audio_item, scene_item=None,
                       speaker_item=None, sentence_item_list=None) -> bool:
        if not basic_item or not audio_item:
            logger.error(f"basic_item or audio_item is None")
            return False
        if speaker_item:
            basic_data = basic_item.basic_data
            spkid = speaker_item.speaker_data.spkid
            basic_data.spkid = basic_data.batch + "-" + spkid
        self.basic_item = basic_item
        self.audio_item = audio_item
        self.scene_item = scene_item
        self.speaker_item = speaker_item
        self.sentence_item_list = sentence_item_list
        return True

    def set_batch_json(self, batch_json) -> bool:
        basic_json = batch_json.get("basic")
        audio_json = batch_json.get("audio")
        scene_json = batch_json.get("scene")
        speaker_json = batch_json.get("speaker")
        sentence_json_list = batch_json.get("sentence")

        # basic
        basic_item = DescBasicItem()
        if not basic_item.set_basic_json(basic_json):
            logger.error(f"set basic json failed")
            return False
        self.basic_item = basic_item

        # audio
        audio_item = DescAudioItem()
        if not audio_item.set_audio_json(audio_json):
            logger.error(f"set audio json failed")
            return False
        self.audio_item = audio_item

        # scene
        if scene_json:
            scene_item = DescSceneItem()
            if not scene_item.set_scene_json(scene_json):
                logger.error(f"set scene json failed")
                return False
            self.scene_item = scene_item

        # speaker
        if speaker_json:
            speaker_item = DescSpeakerItem()
            if not speaker_item.set_speaker_json(speaker_json):
                logger.error(f"set speaker json failed")
                return False
            self.speaker_item = speaker_item

        # sentence
        if sentence_json_list:
            sentence_item_list = []
            for sentence_json in sentence_json_list:
                sentence_item = DescSentenceItem()
                if not sentence_item.set_sentence_json(sentence_json):
                    logger.error(f"set sentence item failed")
                    return False
                sentence_item_list.append(sentence_item)
            self.sentence_item_list = sentence_item_list

        return True

    def get_batch_json(self) -> Optional[Dict]:
        if self.basic_item:
            basic_json = self.basic_item.get_basic_json()
        else:
            logger.error(f"get basic json failed")
            return None

        if self.audio_item:
            audio_json = self.audio_item.get_audio_json()
        else:
            logger.error(f"get audio json failed")
            return None

        if self.scene_item:
            scene_json = self.scene_item.get_scene_json()
        else:
            scene_json = None

        if self.speaker_item:
            speaker_json = self.speaker_item.get_speaker_json()
        else:
            speaker_json = None

        if self.sentence_item_list:
            sentence_json_list = []
            for sentence_item in self.sentence_item_list:
                sentence_json = sentence_item.get_sentence_json()
                sentence_json_list.append(sentence_json)
        else:
            sentence_json_list = None

        batch_json = {
                "basic": basic_json,
                "audio": audio_json,
                "scene": scene_json,
                "speaker": speaker_json,
                "sentence": sentence_json_list
                }
        batch_keys = list(batch_json.keys())
        for key in batch_keys:
            if not batch_json[key]:
                del batch_json[key]
        return batch_json
