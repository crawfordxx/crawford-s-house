#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Dict, Optional
from utils.desc.desc_data import DescSceneHomeAttrs
from utils.desc.desc_data import DescSceneCarAttrs
from utils.desc.desc_data import DescSceneData
from utils.comm.log import logger


class DescSceneItem():

    def __init__(self):
        self.scene_data = None

    def check_scene_data(self, scene_data) -> bool:
        if not scene_data:
            logger.error("scene_data is None")
            return False
        return True

    def set_scene_json(self, scene_json) -> bool:
        if not scene_json:
            logger.error("scene_json is None")
            return False
        scid = scene_json.get("scid")
        domain = scene_json.get("domain")
        attrs_json = scene_json.get("attrs")
        if not scid or not domain:
            logger.error("scid or domain is None")
            return False
        if domain == 'home' and attrs_json:
            attrs = DescSceneHomeAttrs(**attrs_json)
        elif domain == 'car' and attrs_json:
            attrs = DescSceneCarAttrs(**attrs_json)
        else:
            attrs = None

        scene_data = DescSceneData()
        scene_data.scid = scid
        scene_data.domain = domain
        scene_data.attrs = attrs
        if not self.check_scene_data(scene_data):
            logger.error(f"scene_data is invalid")
            return False
        self.scene_data = scene_data
        return True

    def get_scene_json(self) -> Optional[Dict]:
        if not self.scene_data:
            logger.error(f"scene_data is None")
            return None
        scene_json = self.scene_data.dict()
        attrs_json = scene_json.get("attrs")
        if not attrs_json:
            del scene_json["attrs"]
        else:
            attrs_keys = list(attrs_json.keys())
            for key in attrs_keys:
                if not attrs_json[key]:
                    del attrs_json[key]
        return scene_json
