#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import wave
import numpy as np
from scipy.signal import spectrogram
from typing import Dict, Optional
from utils.desc.desc_data import DescAudioFormatData
from utils.desc.desc_data import DescAudioSignalData
from utils.desc.desc_data import DescAudioData
from utils.comm.log import logger


FORMAT_RATE = [8000, 16000, 32000, 44100, 48000]
FORMAT_BITS = [16, 32]
FORMAT_CHLS = [1, 2, 3, 4, 5, 6, 7, 8]
SIGNAL_CLIPPING = 0.9
SIGNAL_RATE_RATIO = 5e3
SIGNAL_HOPPING_RATIO = 30


class DescAudioItem():

    def __init__(self):
        self.audio_data = None

    def get_signal_data(self, wav_mono, sample_rate):
        signal_data = DescAudioSignalData()
        # clipping
        clipping_thrd = 32768 * SIGNAL_CLIPPING
        # clipping_thrd = max(np.abs(wav_mono)) * SIGNAL_CLIPPING
        signal_data.clipping = sum([int(abs(value) > clipping_thrd)
                                    for value in wav_mono])
        # real rate
        """
        freq_energy = np.square(np.abs(np.fft.rfft(wav_mono)))
        freq_bound = round(len(freq_energy) / 2)
        freq_low = np.sum(freq_energy[:freq_bound])
        freq_high = np.sum(freq_energy[freq_bound+1:])
        if freq_low > (freq_high * SIGNAL_RATE_RATIO):
            signal_data.real_rate = int(sample_rate/2)
        else:
            signal_data.real_rate = sample_rate
        # hopping
        _, _, spec = spectrogram(wav_mono, fs=sample_rate,
                                 noverlap=128, window="hann")
        # the timeseries of the highest frequency
        spec_f = ([spec[-1, t] for t in range(np.shape(spec)[1])])
        mean_val = np.mean(spec_f)
        hopping_cnt = 0
        for point in spec_f:
            if point > (mean_val * SIGNAL_HOPPING_RATIO):
                hopping_cnt += 1
        signal_data.hopping = hopping_cnt
        """
        return signal_data

    def check_audio_data(self, audio_data) -> bool:
        if not audio_data.format_:
            logger.error(f"audio format is None")
            return False

        duration = audio_data.duration
        if duration < 0.4:
            logger.error(f"duration {duration} is less than 400ms")
            return False

        format_data = audio_data.format_
        if format_data.rate not in FORMAT_RATE:
            logger.error(f"format rate {format_data.rate} is invalid")
            return False
        if format_data.bits not in FORMAT_BITS:
            logger.error(f"format bits {format_data.bits} is invalid")
            return False
        if format_data.chls not in FORMAT_CHLS:
            logger.error(f"format chls {format_data.chls} is invalid")
            return False
        return True

    def set_audio_item(self, wav_path, hardware=None,
                       device=None, detect_signal=False) -> bool:
        # read wave file
        try:
            with wave.open(wav_path, 'rb') as wave_file:
                wav_chls, wav_width, wav_rate, wav_nfrm, \
                        _, _ = wave_file.getparams()
                duration = int(1000*wav_nfrm/wav_rate)/1000
                wav_bits = wav_width*8
                wav_str = wave_file.readframes(wav_nfrm)
        except Exception as excp:
            logger.error(excp)
            return False

        # audio
        audio_data = DescAudioData()
        audio_data.hardware = hardware
        audio_data.device = device
        audio_data.duration = duration
        # format
        format_data = DescAudioFormatData()
        format_data.rate = wav_rate
        format_data.bits = wav_bits
        format_data.chls = wav_chls
        audio_data.format_ = format_data
        # signal
        if detect_signal and (wav_bits == 16) and (duration > 0.1):
            wav_np = np.fromstring(wav_str, dtype=np.int16)
            wav_data = np.reshape(wav_np, [wav_nfrm, wav_chls])
            wav_mono = wav_data[:, 0]
            audio_data.signal_ = self.get_signal_data(wav_mono, wav_rate)

        # check
        if not self.check_audio_data(audio_data):
            logger.error(f"audio_data is invalid")
            return False

        # return
        self.audio_data = audio_data
        return True

    def set_audio_json(self, audio_json) -> bool:
        if not audio_json:
            logger.error("audio_json is None")
            return False
        audio_data = DescAudioData(**audio_json)
        if not self.check_audio_data(audio_data):
            logger.error(f"audio_data is invalid")
            return False
        self.audio_data = audio_data
        return True

    def get_audio_json(self) -> Optional[Dict]:
        if not self.audio_data:
            logger.error(f"audio_data is None")
            return None
        audio_json = self.audio_data.dict()
        audio_keys = list(audio_json.keys())
        for key in audio_keys:
            if not audio_json[key]:
                del audio_json[key]
        return audio_json
