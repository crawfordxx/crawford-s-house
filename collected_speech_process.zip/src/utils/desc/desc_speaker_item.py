#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from typing import Dict, Optional
from utils.desc.desc_data import DescSpeakerData
from utils.comm.log import logger


SPEAKER_GENDER = ['male', 'female']
SPEAKER_AGE = ['child', 'young', 'adult', 'older']
SPEAKER_ACCENT = ['mandarin', 'accent', 'dialect']


class DescSpeakerItem():

    def __init__(self):
        self.speaker_data = None

    def check_speaker_data(self, speaker_data) -> bool:
        if not speaker_data:
            logger.error("speaker_data is None")
            return False
        # gender
        gender = speaker_data.gender
        if gender and gender not in SPEAKER_GENDER:
            logger.error(f"gender {gender} is invalid")
            return False
        # age
        age = speaker_data.age
        if ((age and age.isdigit() and int(age) not in range(100)) or
                (age and not age.isdigit() and age not in SPEAKER_AGE)):
            logger.error(f"age {age} is invalid")
            return False
        # region
        # speaker_data.region
        # accent
        accent = speaker_data.accent
        if accent and accent not in SPEAKER_ACCENT:
            logger.error(f"accent {accent} is invalid")
            return False
        # return
        return True

    def set_speaker_json(self, speaker_json) -> bool:
        if not speaker_json:
            logger.error("speaker_json is None")
            return False
        speaker_data = DescSpeakerData(**speaker_json)
        if not self.check_speaker_data(speaker_data):
            logger.error(f"speaker_data is invalid")
            return False
        self.speaker_data = speaker_data
        return True

    def get_speaker_json(self) -> Optional[Dict]:
        if not self.speaker_data:
            logger.error(f"speaker_data is None")
            return None
        speaker_json = self.speaker_data.dict()
        speaker_keys = list(speaker_json.keys())
        for key in speaker_keys:
            if not speaker_json[key]:
                del speaker_json[key]
        return speaker_json
