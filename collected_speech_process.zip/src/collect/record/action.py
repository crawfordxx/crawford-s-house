#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter.messagebox import askyesno
from tkinter.messagebox import showinfo


class RecordAction:

    def __init__(self, root, manager):
        self.start_button = None
        self.stop_button = None
        self.restart_button = None
        self.manager = manager
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root, pady=10)
        self.start_button = tk.Button(frame, text="开始录制",
                                      command=self.start_record)
        self.stop_button = tk.Button(frame, text="停止录制", state=tk.DISABLED,
                                     command=self.stop_record)
        self.restart_button = tk.Button(frame, text="重新录制",
                                        command=self.restart_record)
        frame.pack()

    def layout(self):
        self.start_button.grid(row=0, column=1)
        self.stop_button.grid(row=1, column=1)
        self.restart_button.grid(row=2, column=1)

    def disable(self):
        self.start_button.config(state=tk.DISABLED)
        self.restart_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.ACTIVE)
        self.manager.ui_disable()

    def enable(self):
        self.start_button.config(state=tk.ACTIVE)
        self.restart_button.config(state=tk.ACTIVE)
        self.stop_button.config(state=tk.DISABLED)
        self.manager.ui_enable()

    def start_record(self):
        if not askyesno("提示", "确定开始录音？"):
            return
        if not self.manager.read_data():
            return
        if not self.manager.check_data():
            return
        if not self.manager.start_record():
            return
        self.disable()

    def stop_record(self):
        if not askyesno("提示", "确定停止录音？"):
            return
        self.manager.stop_record()
        self.manager.write_data()
        self.enable()
        showinfo("提示", "录音完成")

    def restart_record(self):
        if not askyesno("提示", "确定重新录音？"):
            return
        if not self.manager.read_data():
            return
        if not self.manager.check_data(restart=True):
            return
        if not self.manager.start_record():
            return
        self.disable()
