#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from tkinter.messagebox import showerror
from utils.device.group import DeviceGroup
from utils.desc.desc_speaker_batch import DescSpeakerBatch
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.desc.desc_scene_batch import DescSceneBatch
from utils.io.config import read_config_file
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.io.stdio import append_list_file
from utils.comm.os import OSDir
from utils.comm.os import OSFile

accent_dict = {"普通话": "mandarin", "口音": "accent", "方言": "dialect"}
gender_dict = {"男": "male", "女": "female"}


class RecordManager:

    def __init__(self, config, speaker, sentence):
        self.config = config
        self.basic_info = None
        self.device_grp = None
        self.output_dir = None

        self.speaker_batch = DescSpeakerBatch()
        self.sentence_batch = DescSentenceBatch()
        self.scene_batch = DescSceneBatch()

        self.speaker = speaker
        self.sentence = sentence
        self.speaker_json = None
        self.sentence_json = None
        self.wav_name_dict = {}

    def read_config(self):
        config_json_path = self.config.get_data()
        config_info = read_config_file(config_json_path)
        if not config_info:
            return False
        self.basic_info = config_info.get("basic")
        self.device_grp = DeviceGroup(config_info.get("mics"))
        self.output_dir = OSDir.dir_name(config_json_path)
        if not (self.device_grp and self.output_dir):
            return False
        return True

    def read_history(self):
        speaker_json_path = f"{self.output_dir}/doc/speaker.json"
        sentence_json_path = f"{self.output_dir}/doc/sentence.json"
        scene_json_path = f"{self.output_dir}/doc/scene.json"
        if OSFile.check_file(speaker_json_path):
            self.speaker_batch = read_desc_file(speaker_json_path,
                                                desc_type="speaker")
        if OSFile.check_file(sentence_json_path):
            self.sentence_batch = read_desc_file(sentence_json_path,
                                                 desc_type="sentence")
        if OSFile.check_file(scene_json_path):
            self.scene_batch = read_desc_file(scene_json_path,
                                              desc_type="scene")

    def read_data(self):
        if not self.read_config():
            showerror("错误", "配置文件有误")
            return False
        self.read_history()
        return True

    def check_data_valid(self):
        if not self.speaker.check_data(self.basic_info):
            return False
        if not self.sentence.check_data(self.basic_info):
            return False
        self.speaker_json = self.speaker.get_data()
        self.sentence_json = self.sentence.get_data()
        spkid = self.speaker_json.get("spkid")
        sntid = self.sentence_json.get("sntid")
        for mic in self.device_grp.mic_list:
            if mic.scene:
                scid = mic.scene.scene_data.scid
                wav_name = f"{spkid}_{scid}_{sntid}_{mic.index}"
            else:
                wav_name = f"{spkid}_{sntid}_{mic.index}"
            self.wav_name_dict[mic.index] = wav_name
        return True

    def remove_current(self):
        spkid = self.speaker_json.get("spkid")
        speaker_dict = self.speaker_batch.speaker_dict
        wav_spk_dict = self.speaker_batch.wav_spk_dict
        sentence_dict = self.sentence_batch.sentence_dict
        scene_dict = self.scene_batch.scene_dict
        wav_sc_dict = self.scene_batch.wav_sc_dict
        for mic in self.device_grp.mic_list:
            if spkid in list(speaker_dict.keys()):
                del self.speaker_batch.speaker_dict[spkid]
            if mic.scene:
                scid = mic.scene.scene_data.scid
                if scid in list(scene_dict.keys()):
                    del self.scene_batch.scene_dict[scid]
            wav_name = self.wav_name_dict[mic.index]
            if wav_name in list(wav_spk_dict.keys()):
                del self.speaker_batch.wav_spk_dict[wav_name]
            if wav_name in list(sentence_dict.keys()):
                del self.sentence_batch.sentence_dict[wav_name]
            if wav_name in list(wav_sc_dict.keys()):
                del self.scene_batch.wav_sc_dict[wav_name]

    def check_data_repeat(self):
        wav_name_set = set(list(self.speaker_batch.wav_spk_dict.keys()) +
                           list(self.sentence_batch.sentence_dict.keys()) +
                           list(self.scene_batch.scene_dict.keys()))
        for mic in self.device_grp.mic_list:
            wav_name = self.wav_name_dict[mic.index]
            if wav_name in wav_name_set:
                return False
        return True

    def check_data(self, restart=False):
        if not self.check_data_valid():
            return False
        if restart:
            self.remove_current()
        if not self.check_data_repeat():
            showerror("错误", "本条数据已录制")
            return False
        return True

    def start_record(self):
        if not self.device_grp.prepare_record():
            showerror("错误", "准备失败")
            return False
        self.device_grp.stop_record()
        if not self.device_grp.start_record():
            showerror("错误", "录音失败")
            return False
        return True

    def stop_record(self):
        self.device_grp.stop_record()

    def pull_data(self):
        spkid = self.speaker_json.get("spkid")
        sntid = self.sentence_json.get("sntid")
        output_dir = f"{self.output_dir}/data/SPEAKER{spkid}_SNT{sntid}/"
        if not OSDir.check_dir(output_dir):
            OSDir.init_dir(output_dir)
        self.device_grp.pull_data(data_dir=output_dir,
                                  spkid=spkid, sntid=sntid)

    def update_desc(self):
        speaker_info = self.speaker_json.copy()
        speaker_info["accent"] = accent_dict.get(speaker_info.get("accent"))
        speaker_info["gender"] = gender_dict.get(speaker_info.get("gender"))
        speaker_json_list, sentence_json_list, scene_json_list = [], [], []
        for mic in self.device_grp.mic_list:
            wav_name = self.wav_name_dict[mic.index]
            speaker_json = {
                "basic": {"wav_name": wav_name},
                "speaker": speaker_info
            }
            sentence_json = {
                "basic": {"wav_name": wav_name},
                "sentence": [{"text": self.sentence_json.get("text")}]
            }
            scene_json = {
                "basic": {"wav_name": wav_name},
                "scene": mic.scene.get_scene_json()
            }
            speaker_json_list.append(speaker_json)
            sentence_json_list.append(sentence_json)
            scene_json_list.append(scene_json)
        self.speaker_batch.set_batch_json_list(speaker_json_list)
        self.sentence_batch.set_batch_json_list(sentence_json_list)
        self.scene_batch.set_batch_json_list(scene_json_list)

    def write_desc(self):
        doc_dir = f"{self.output_dir}/doc"
        if not OSDir.check_dir(doc_dir):
            OSDir.init_dir(doc_dir)

        speaker_json_path = f"{doc_dir}/speaker.json"
        sentence_json_path = f"{doc_dir}/sentence.json"
        scene_json_path = f"{doc_dir}/scene.json"
        write_desc_file(self.speaker_batch, speaker_json_path)
        write_desc_file(self.sentence_batch, sentence_json_path)
        write_desc_file(self.scene_batch, scene_json_path)

        speaker_txt_path = f"{doc_dir}/speaker.txt"
        speaker_txt_line = '\t'.join(list(self.speaker_json.values()))
        append_list_file([speaker_txt_line], speaker_txt_path)

    def write_data(self):
        self.pull_data()
        self.update_desc()
        self.write_desc()

    def ui_disable(self):
        self.config.disable()
        self.speaker.disable()
        self.sentence.disable()

    def ui_enable(self):
        self.config.enable()
        self.speaker.enable()
        self.sentence.enable()
