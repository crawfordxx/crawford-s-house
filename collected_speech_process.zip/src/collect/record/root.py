#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import tkinter as tk
from utils.ui.line import UILine
from utils.ui.config import UIConfig
from utils.ui.speaker import UISpeaker
from utils.ui.sentence import UISentence
from collect.record.manager import RecordManager
from collect.record.action import RecordAction


if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("350x450")
    root.title("录音界面")

    config = UIConfig(root)
    config_line = UILine(root)
    speaker = UISpeaker(root)
    speaker_line = UILine(root)
    sentence = UISentence(root)
    sentence_line = UILine(root)
    manager = RecordManager(config, speaker, sentence)
    action = RecordAction(root, manager)

    root.mainloop()
