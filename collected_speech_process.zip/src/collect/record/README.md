# RecordManager

## Field
#### widget
    config: 管理配置文件UI控件的对象
    speaker: 管理说话人UI控件的对象
    sentence：管理句子UI控件的对象
#### summary
    basic_info：配置文件中的基本信息
    device_grp：设备管理对象
    output_dir：音频和配置输出的目录
    speaker_batch: 说话人批次对象
    sentence_batch: 句子批次对象
    scene_batch: 场景批次对象
#### current
    speaker_json: 说话人数据json
    sentence_json: 句子数据json
    wav_name_dict: key为麦克风编号，value为wav_name

## Method

### read_data 
读取数据，调用以下两个方法读取配置文件和历史信息
    
    read_config
    读取配置文件中的信息，成功读取返回True，否则返回False
    read_history
    读取配置文件对应的历史数据，并赋值给说话人批次对象、句子批次对象和场景批次对象

### check_data
调用以下三个方法检查输入信息

    check_data_valid
    检查输入信息是否合格，合格则保存到说话人数据json、句子数据json和音频文件名字典中
    remove_current
    用于重新录制数据时删除上次录制的同名数据
    check_data_repeat
    用于开始新的音频录制时检查编号是否与过去的重复

### start_record
开始录音

### stop_record
停止录音

### write_data 
调用以下三个方法写入音频数据和信息记录

    pull_data
    拉取录音数据并保存到输出文件夹
    update_desc
    将当前录音的信息加入录音历史信息记录
    write_desc
    写入更新过的录音历史信息记录

### ui_disable
在开始录音后禁用界面控件来阻止信息输入

### ui_enable
在录音结束后重新开启界面控件来恢复信息输入


