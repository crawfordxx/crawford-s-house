#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import argparse
from utils.ts.group import TsGroup
from utils.ts.mic import TsMic
from utils.ts.cam import TsCam
from utils.ts.sync import TsSync
from utils.io.stdio import read_list_file
from utils.comm.os import OSFile
from utils.comm.os import OSDir
from utils.comm.log import ts_logger


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("in_list_path", type=str)
    parser.add_argument("out_dir", type=str)
    parser.add_argument("--flipped_cams", type=str)
    return parser.parse_args()


def ts_sync(args):
    # get args
    in_list_path = args.in_list_path
    out_dir = args.out_dir.rstrip('/')
    if args.flipped_cams:
        flipped_cams = args.flipped_cams.split('|')
    else:
        flipped_cams = []

    # read input list file
    if not in_list_path:
        return
    file_list = read_list_file(in_list_path)
    if not file_list:
        return

    # sort into pack and wav list, set up ts_group obj
    pack_list = [file_path for file_path in file_list
                 if OSFile.name_suffix(file_path) == ".pack"]
    wav_list = [file_path for file_path in file_list
                if OSFile.name_suffix(file_path) == ".wav"]

    ts_group = TsGroup(pack_list, wav_list, flipped_cams, out_dir)

    # if no valid file found
    if not pack_list and not wav_list:
        ts_logger.error(f"No valid files found in {in_list_path}")
        return

    # if only .pack files present
    if pack_list and not wav_list:
        OSDir.init_dir(ts_group.cam_img_dir)
        ts_group.cam_prep_data()
        ts_group.cam_inter_frm()
        ts_group.sync_cams = TsSync.get_sync_ts(ts_group.inter_cams)
        OSDir.init_dir(ts_group.cam_tar_dir)
        # ts_group.img_to_tar()
        OSDir.init_dir(ts_group.cam_mp4_dir)
        # ts_group.img_to_mp4()
        ts_group.cam_sync_img()
        ts_logger.info("\n======================")

    # if only .wav files present
    if wav_list and not pack_list:
        ts_group.mic_prep_data()
        ts_group.sync_mics = TsSync.get_sync_ts(ts_group.mic_list)
        OSDir.init_dir(ts_group.mic_wav_dir)
        ts_group.mic_sync_wav()
        ts_logger.info("\n======================")

    # if both .wav and .pack files present
    if wav_list and pack_list:
        OSDir.init_dir(ts_group.cam_img_dir)
        ts_group.cam_prep_data()
        ts_group.cam_inter_frm()
        ts_group.mic_prep_data()

        sync_list = TsSync.get_sync_ts(ts_group.mic_list + ts_group.inter_cams)
        ts_group.sync_mics = [media for media in sync_list
                              if isinstance(media, TsMic)]
        ts_group.sync_cams = [media for media in sync_list
                              if isinstance(media, TsCam)]

        OSDir.init_dir(ts_group.mic_wav_dir)
        ts_group.mic_sync_wav()

        OSDir.init_dir(ts_group.cam_tar_dir)
        # ts_group.img_to_tar()
        OSDir.init_dir(ts_group.cam_mp4_dir)
        # ts_group.img_to_mp4()
        ts_group.cam_sync_img()

        OSDir.init_dir(ts_group.mix_mp4_dir)
        ts_group.mm_merge_mp4()
        ts_logger.info("\n======================")


if __name__ == "__main__":
    args = parse_args()
    ts_sync(args)
