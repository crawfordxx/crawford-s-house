#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter.messagebox import askyesno


class DeviceAction:

    def __init__(self, root, manager):
        self.load_button = None
        self.save_button = None
        self.manager = manager
        self.pack(root)
        self.layout()

    def pack(self, root):
        frame = tk.Frame(root, pady=10)
        self.load_button = tk.Button(frame, text="加载配置文件",
                                     command=self.load_config)
        self.save_button = tk.Button(frame, text="保存当前配置",
                                     command=self.save_config)
        frame.pack()

    def layout(self):
        self.load_button.grid(row=0, column=0)
        self.save_button.grid(row=0, column=1)

    def load_config(self):
        self.manager.load_config()

    def save_config(self):
        if not askyesno("提示", "确定保存当前配置？"):
            return
        self.manager.save_config()
