#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import tkinter as tk
from utils.ui.dev_list import UIDevList
from utils.ui.config import UIConfig
from collect.device.action import DeviceAction
from collect.device.manager import DeviceManager


if __name__ == '__main__':
    root = tk.Tk()
    root.geometry('700x250')
    root.title("调整配置")

    dev_list = UIDevList(root)
    config = UIConfig(root)
    manager = DeviceManager(config, dev_list)
    action = DeviceAction(root, manager)

    root.mainloop()
