#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from utils.io.config import read_config_file
from utils.io.config import write_config_file
from tkinter.messagebox import showerror
from tkinter.messagebox import showinfo


class DeviceManager:

    def __init__(self, config, dev_list):
        self.config = config
        self.dev_list = dev_list
        self.config_path = None
        self.config_info = None

    def load_config(self):
        self.config_path = self.config.get_data()
        self.config_info = read_config_file(self.config_path)
        if not self.config_info:
            showerror("错误", "配置文件有误")
            return
        dev_mic_dict = {0: ""}
        for mic in self.config_info.get('mics'):
            connect_type = mic.device.device_data.connect_type
            if connect_type == "usb":
                dev_idx = int(mic.device.device_data.connect_index)
                dev_mic_dict[dev_idx] = mic.index
        self.dev_list.set_idx_dict(dev_mic_dict)
        showinfo('提示', '加载配置成功')
        return

    def save_config(self):
        mic_dev_dict = self.dev_list.get_idx_dict()
        if not mic_dev_dict:
            showerror('错误', 'mic编号配置错误')
            return
        for mic in self.config_info.get('mics'):
            device_data = mic.device.device_data
            if device_data.connect_type == "usb":
                dev_idx = mic_dev_dict.get(mic.index)
                if not dev_idx:
                    showerror('错误', f"{mic.index}未找到设备编号")
                    return
                device_data.connect_index = str(dev_idx)
        write_config_file(self.config_info, self.config_path)
        showinfo('提示', '保存配置成功')
