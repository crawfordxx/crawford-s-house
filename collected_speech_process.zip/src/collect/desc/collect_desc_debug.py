#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from memory_profiler import profile
from utils.desc.desc_batch import DescBatch
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger
logger.setLevel(20)


def parse_args():
    parser = argparse.ArgumentParser(description="make batch description")
    parser.add_argument("audio_json", type=str, help="input audio json")
    parser.add_argument("desc_json", type=str, help="output desc json")
    parser.add_argument("--scene_json", type=str, help="input scene json")
    parser.add_argument("--speaker_json", type=str, help="input speaker json")
    parser.add_argument("--sentence_json", type=str,
                        help="input sentence json")
    args = parser.parse_args()
    return args


@profile
def collect_desc_batch(audio_json, scene_json, speaker_json,
                       sentence_json, desc_json):
    # import pdb; pdb.set_trace()

    logger.info("start")
    audio_batch = read_desc_file(audio_json, "audio")
    logger.info("read_audio_json")
    scene_batch = read_desc_file(scene_json, "scene")
    logger.info("read_scene_json")
    speaker_batch = read_desc_file(speaker_json, "speaker")
    logger.info("read_speaker_json")
    sentence_batch = read_desc_file(sentence_json, "sentence")
    logger.info("read_sentence_json")
    if not audio_batch:
        logger.error(f"audio_batch is None")
        return
    logger.info("set_batch")
    desc_batch = DescBatch()
    if not desc_batch.set_batch(audio_batch, scene_batch,
                                speaker_batch, sentence_batch):
        logger.error(f"set desc batch failed")
        return
    logger.info("get_batch_json_list")
    write_desc_file(desc_batch, desc_json)
    logger.info("write_json_file")
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_batch(args.audio_json, args.scene_json, args.speaker_json,
                       args.sentence_json, args.desc_json)
