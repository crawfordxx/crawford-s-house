#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.desc.desc_scene_batch import DescSceneBatch
from utils.io.record import read_scene_lst
from utils.io.stdio import read_dict_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make scene description")
    parser.add_argument("scene_lst", help="input list for scene", type=str)
    parser.add_argument("wav2sc_lst", help="input list for wav2sc", type=str)
    parser.add_argument("scene_json", help="output json for scene", type=str)
    args = parser.parse_args()
    return args


def collect_desc_scene(scene_lst, wav2sc_lst, scene_json):
    scene_list = read_scene_lst(scene_lst)
    wav2sc_dict = read_dict_file(wav2sc_lst)
    if not scene_list or not wav2sc_dict:
        logger.error(f"scene_list or wav2sc_dict is None")
        return
    scene_batch = DescSceneBatch()
    if not scene_batch.set_scene_batch(scene_list, wav2sc_dict):
        logger.error(f"set scene batch failed")
        return
    write_desc_file(scene_batch, scene_json)
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_scene(args.scene_lst, args.wav2sc_lst, args.scene_json)
