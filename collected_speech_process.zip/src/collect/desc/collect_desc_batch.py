#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.desc.desc_batch import DescBatch
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make batch description")
    parser.add_argument("audio_json", type=str, help="input audio json")
    parser.add_argument("desc_json", type=str, help="output desc json")
    parser.add_argument("--scene_json", type=str, help="input scene json")
    parser.add_argument("--speaker_json", type=str, help="input speaker json")
    parser.add_argument("--sentence_json", type=str,
                        help="input sentence json")
    args = parser.parse_args()
    return args


def collect_desc_batch(audio_json, scene_json, speaker_json,
                       sentence_json, desc_json):
    audio_batch = read_desc_file(audio_json, "audio")
    scene_batch = read_desc_file(scene_json, "scene")
    speaker_batch = read_desc_file(speaker_json, "speaker")
    sentence_batch = read_desc_file(sentence_json, "sentence")
    if not audio_batch:
        logger.error(f"audio_batch is None")
        return
    desc_batch = DescBatch()
    if not desc_batch.set_batch(audio_batch, scene_batch,
                                speaker_batch, sentence_batch):
        logger.error(f"set desc batch failed")
        return
    write_desc_file(desc_batch, desc_json)
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_batch(args.audio_json, args.scene_json, args.speaker_json,
                       args.sentence_json, args.desc_json)
