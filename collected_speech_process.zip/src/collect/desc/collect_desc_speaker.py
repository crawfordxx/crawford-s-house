#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.desc.desc_speaker_batch import DescSpeakerBatch
from utils.io.record import read_speaker_lst
from utils.io.stdio import read_dict_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make speaker description")
    parser.add_argument("speaker_lst", type=str, help="input speaker list")
    parser.add_argument("wav2spk_lst", type=str, help="input wav2spk list")
    parser.add_argument("speaker_json", type=str, help="output speaker json")
    args = parser.parse_args()
    return args


def collect_desc_speaker(speaker_lst, wav2spk_lst, speaker_json):
    speaker_list = read_speaker_lst(speaker_lst)
    wav2spk_dict = read_dict_file(wav2spk_lst)
    if not speaker_list or not wav2spk_dict:
        logger.error(f"speaker_list or wav2spk_dict is None")
        return
    speaker_batch = DescSpeakerBatch()
    if not speaker_batch.set_speaker_batch(speaker_list, wav2spk_dict):
        logger.error(f"set speaker batch failed")
        return
    write_desc_file(speaker_batch, speaker_json)
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_speaker(args.speaker_lst, args.wav2spk_lst, args.speaker_json)
