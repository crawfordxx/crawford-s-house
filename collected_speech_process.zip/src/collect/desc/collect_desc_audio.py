#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.desc.desc_audio_batch import DescAudioBatch
from utils.io.stdio import read_list_file
from utils.io.stdio import read_dict_file
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make audio description")
    parser.add_argument("batch_name", type=str,
                        help="input batch name")
    parser.add_argument("wav_path_lst", type=str,
                        help="input list for wav relative path")
    parser.add_argument("audio_json", type=str,
                        help="output json for audio")
    parser.add_argument("--hardware", type=str,
                        help="hardware type string")
    parser.add_argument("--wav2dev_lst", type=str,
                        help="input list for wav2dev")
    parser.add_argument("--detect_signal", action="store_true", default=False,
                        help="whether to detect signal")
    args = parser.parse_args()
    return args


def collect_desc_audio(batch_name, wav_path_lst, audio_json,
                       hardware=None, wav2dev_lst=None, detect_signal=None):
    if not batch_name:
        logger.error(f"batch_name is invalid")
        return
    wav_path_list = read_list_file(wav_path_lst)
    if not wav_path_list:
        logger.error(f"{wav_path_lst} read failed")
        return
    wav2dev_dict = read_dict_file(wav2dev_lst)
    audio_batch = DescAudioBatch()
    if not audio_batch.set_audio_batch(batch_name, wav_path_list,
                                       hardware, wav2dev_dict, detect_signal):
        logger.error(f"set audio batch failed")
        return
    write_desc_file(audio_batch, audio_json)
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_audio(args.batch_name, args.wav_path_lst, args.audio_json,
                       args.hardware, args.wav2dev_lst, args.detect_signal)
