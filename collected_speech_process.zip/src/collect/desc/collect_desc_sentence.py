#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.desc.desc_sentence_batch import DescSentenceBatch
from utils.io.record import read_sentence_lst
from utils.io.stdio import write_desc_file
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="make sentence description")
    parser.add_argument("--wav2txt_lst", type=str, help="input text list")
    parser.add_argument("--wav2emt_lst", type=str, help="input emotion list")
    parser.add_argument("--wav2NLU_lst", type=str, help="input NLU list")
    parser.add_argument("sentence_json", type=str, help="output sentence json")
    args = parser.parse_args()
    return args


def collect_desc_sentence(wav2txt_lst, wav2emt_lst, wav2NLU_lst,
                          sentence_json):
    sentence_list = read_sentence_lst(wav2txt_lst, wav2emt_lst, wav2NLU_lst)
    if not sentence_list:
        logger.error(f"sentence list is empty")
        return
    sentence_batch = DescSentenceBatch()
    if not sentence_batch.set_sentence_batch(sentence_list):
        logger.error(f"set sentence batch failed")
        return
    write_desc_file(sentence_batch, sentence_json)
    return


if __name__ == '__main__':
    args = parse_args()
    collect_desc_sentence(args.wav2txt_lst, args.wav2emt_lst,
                          args.wav2NLU_lst, args.sentence_json)
