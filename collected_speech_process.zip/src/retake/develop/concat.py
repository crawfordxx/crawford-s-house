#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.wav.concat import WavConcat
from utils.comm.os import OSDir


def parse_args():
    parser = argparse.ArgumentParser(description="concat wav with desc")
    parser.add_argument("--tip_desc_path", type=str, help="tip desc path")
    parser.add_argument("wav_desc_path", type=str, help="wav desc path")
    parser.add_argument("--wav_interval", type=float, default=0,
                        help="wav interval")
    parser.add_argument("--max_duration", type=float, default=0,
                        help="max duration")
    parser.add_argument("--name_prefix", type=str, default="",
                        help="name prefix")
    parser.add_argument("concat_data_dir", type=str, help="concat data dir")
    args = parser.parse_args()
    return args


def develop_concat(args):
    # args
    tip_desc_item = None
    if args.tip_desc_path:
        tip_desc_batch = read_desc_file(args.tip_desc_path)
        if not tip_desc_batch:
            return
        tip_desc_item = list(tip_desc_batch.batch_dict.values())[0]

    wav_desc_batch = read_desc_file(args.wav_desc_path)
    if not wav_desc_batch:
        return
    wav_desc_dict = wav_desc_batch.batch_dict

    wav_interval = args.wav_interval
    max_duration = args.max_duration
    name_prefix = args.name_prefix

    concat_data_dir = args.concat_data_dir.rstrip('/')
    concat_batch = concat_data_dir.split('/')[-1]
    concat_wav_dir = f"{concat_data_dir}/wav"
    concat_desc_path = f"{concat_data_dir}/desc.json"
    OSDir.init_dir(concat_wav_dir)

    # data check
    wav_concat = WavConcat()
    wav_concat.merge_src_desc(tip_desc_item, None, wav_desc_dict)
    if not wav_concat.check_wav_format():
        return

    # concat strategy
    if tip_desc_item:
        wav_concat.set_head_tail(tip_desc_item, 1, 1, 1)
    wav_concat.set_body_list(wav_desc_dict, wav_interval)
    if not wav_concat.set_max_duration(max_duration):
        return
    wav_concat.set_wav_chunk()

    # output wav
    wav_concat.set_concat_name(name_prefix)
    wav_concat.concat_wav_data(concat_wav_dir)

    # output desc
    wav_concat.concat_wav_snt()
    wav_concat.concat_wav_desc(concat_batch, concat_desc_path)


if __name__ == '__main__':
    args = parse_args()
    develop_concat(args)
