#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from itertools import product
from utils.comm.os import OSDir
from utils.io.stdio import read_desc_file
from utils.io.stdio import write_desc_file
from utils.io.config import read_config_file
from utils.desc.desc_batch import DescBatch
from utils.wav.sync import WavSync


def parse_args():
    parser = argparse.ArgumentParser(description="wav synchronization")
    parser.add_argument("concat_desc_path", help="concat_desc.json", type=str)
    parser.add_argument("config_json_path", help="config.json", type=str)
    parser.add_argument("record_wav_dir", help="record_wav_dir", type=str)
    parser.add_argument("record_mono_dir", help="record_mono_dir", type=str)
    parser.add_argument("sync_wav_dir", help="sync_wav_dir", type=str)
    parser.add_argument("sync_desc_path", help="sync_desc.json", type=str)
    parser.add_argument("--sync_thres", help="synchronized threshold",
                        type=float, default=0.05)
    parser.add_argument("--tip_sil_sec", help="tip silence second",
                        type=float, default=1)
    return parser.parse_args()


def develop_sync(concat_desc_path, config_json_path, record_wav_dir,
                 record_mono_dir, sync_wav_dir, sync_desc_path,
                 sync_thres, tip_sil_sec):
    # read files
    concat_desc_batch = read_desc_file(concat_desc_path)
    if not concat_desc_batch:
        return
    concat_desc_list = concat_desc_batch.batch_dict.values()
    cfg_info = read_config_file(config_json_path)
    if not cfg_info:
        return
    dev_mic_list = cfg_info.get("mics")

    # check dirs
    if not OSDir.check_dir(record_mono_dir):
        OSDir.init_dir(record_mono_dir)
    if not OSDir.check_dir(sync_wav_dir):
        OSDir.init_dir(sync_wav_dir)

    # synchronize wav
    sync_desc_dict = {}
    for desc_item, dev_mic in product(concat_desc_list, dev_mic_list):
        wav_sync = WavSync(desc_item, dev_mic, record_wav_dir,
                           record_mono_dir, sync_wav_dir,
                           sync_thres, tip_sil_sec)
        if not wav_sync.check_exist():
            continue
        if not wav_sync.detect_tips():
            continue
        if not wav_sync.check_sync():
            continue
        wav_sync.trim_wav_data()
        sync_desc_item = wav_sync.get_desc_item()
        wav_name = sync_desc_item.basic_item.basic_data.wav_name
        sync_desc_dict[wav_name] = sync_desc_item

    # write desc
    sync_desc_batch = DescBatch()
    sync_desc_batch.batch_dict = sync_desc_dict
    write_desc_file(sync_desc_batch, sync_desc_path)


if __name__ == "__main__":
    args = parse_args()
    develop_sync(args.concat_desc_path, args.config_json_path,
                 args.record_wav_dir, args.record_mono_dir,
                 args.sync_wav_dir, args.sync_desc_path,
                 args.sync_thres, args.tip_sil_sec)
