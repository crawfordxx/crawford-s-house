#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from playsound import playsound
from utils.io.config import read_config_file
from utils.io.stdio import read_desc_file
from utils.device.group import DeviceGroup
from utils.comm.log import logger


def parse_args():
    parser = argparse.ArgumentParser(description="retake record")
    parser.add_argument("concat_desc_path", help="concat.json", type=str)
    parser.add_argument("config_json_path", help="config.json", type=str)
    parser.add_argument("record_wav_dir", help="output_dir", type=str)
    return parser.parse_args()


def retake_record(config_json_path, concat_desc_path, record_wav_dir):
    # read desc
    desc_batch = read_desc_file(concat_desc_path)
    if not desc_batch:
        return
    desc_dict = desc_batch.batch_dict

    # read config
    cfg_info = read_config_file(config_json_path)
    mic_list = cfg_info.get("mics")
    if not mic_list:
        return
    device_group = DeviceGroup(mic_list)

    # prepare
    if not device_group.prepare_record():
        return
    device_group.stop_record()

    # info
    record_sec = sum([desc_item.audio_item.audio_data.duration
                      for desc_item in desc_dict.values()])
    logger.info(f"The retake will cost {round(record_sec/3600,2)} hours")
    record_cnt, record_num = 0, len(desc_dict)

    # record
    for wav_name, desc_item in desc_dict.items():
        play_wav_path = desc_item.basic_item.basic_data.wav_path
        if not device_group.start_record():
            return
        if not device_group.check_data():
            return
        playsound(play_wav_path, block=True)
        device_group.stop_record()
        device_group.pull_data(data_dir=record_wav_dir, spkid=wav_name)

        # info
        record_cnt += 1
        logger.info(f"{wav_name}.wav record finished with "
                    f"procedure {round(100*record_cnt/record_num, 2)}%")


if __name__ == "__main__":
    args = parse_args()
    retake_record(args.config_json_path, args.concat_desc_path,
                  args.record_wav_dir)
