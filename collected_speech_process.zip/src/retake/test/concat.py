#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from utils.io.stdio import read_desc_file
from utils.wav.concat import WavConcat


"""
## head ##
[one_sec_sil - tip_wav - one_sec_sil]

## body and max_duration ##
[[wkp_wav - [wkp_sil]] - qry_wav - [qry_sil]] -
[[wkp_wav - [wkp_sil]] - qry_wav - [qry_sil]] -
......

## tail ##
[one_sec_sil - tip_wav - one_sec_sil]
"""


def parse_args():
    parser = argparse.ArgumentParser(description="concat wav with desc")
    parser.add_argument("--tip_desc_path", type=str, help="tip desc path")
    parser.add_argument("--wkp_desc_path", type=str, help="wkp desc path")
    parser.add_argument("--wkp_sil_sec", type=float, default=0,
                        help="silence between wkp and query")
    parser.add_argument("--sil_dist_path", type=str,
                        help="silence between wkp and query")
    parser.add_argument("qry_desc_path", type=str, help="query desc path")
    parser.add_argument("--qry_sil_sec", type=float, default=0,
                        help="silence between query")
    parser.add_argument("--max_duration", type=float,
                        help="max duration for wav")
    parser.add_argument("concat_data_dir", type=str,
                        help="concat output directory")
    args = parser.parse_args()
    return args


def retake_concat(args):
    # args
    tip_desc_item = None
    if args.tip_desc_path:
        tip_desc_batch = read_desc_file(args.tip_desc_path)
        if not tip_desc_batch:
            return
        tip_desc_item = list(tip_desc_batch.batch_dict.values())[0]

    wkp_desc_item = None
    if args.wkp_desc_path:
        wkp_desc_batch = read_desc_file(args.wkp_desc_path)
        if not wkp_desc_batch:
            return
        wkp_desc_item = list(wkp_desc_batch.batch_dict.values())[0]

    qry_desc_batch = read_desc_file(args.qry_desc_path)
    if not qry_desc_batch:
        return
    qry_desc_dict = qry_desc_batch.batch_dict

    wkp_sil_sec = args.wkp_sil_sec
    qry_sil_sec = args.qry_sil_sec

    max_duration = None
    if args.max_duration and args.max_duration > 10:
        max_duration = args.max_duration

    concat_data_dir = args.concat_data_dir.rstrip('/')
    concat_batch = concat_data_dir.split('/')[-1]
    concat_desc_path = f"{concat_data_dir}/desc.json"

    # input check
    wav_concat = WavConcat()
    wav_concat.merge_src_desc(tip_desc_item, wkp_desc_item, qry_desc_dict)
    if not wav_concat.check_wav_format():
        return

    # concat strategy
    if tip_desc_item:
        wav_concat.set_head_tail(tip_desc_item, 1, 1, 1)
    wav_concat.set_body_list(qry_desc_dict, qry_sil_sec,
                             wkp_desc_item, wkp_sil_sec)
    if max_duration:
        wav_concat.set_max_duration(max_duration)
    wav_concat.set_wav_chunk()

    # output wav
    wav_concat.set_concat_name()
    wav_concat.concat_wav_data(concat_data_dir)

    # output desc
    wav_concat.concat_wav_snt()
    wav_concat.concat_wav_desc(concat_batch, concat_desc_path)


if __name__ == '__main__':
    args = parse_args()
    retake_concat(args)
